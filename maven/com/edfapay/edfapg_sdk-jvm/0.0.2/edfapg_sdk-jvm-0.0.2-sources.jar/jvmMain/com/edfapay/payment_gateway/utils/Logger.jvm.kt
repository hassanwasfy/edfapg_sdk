package com.edfapay.payment_gateway.utils

actual object KmpLogger {
    actual fun log(
        level: KMP_LEVEL,
        message: String,
        throwable: Throwable?
    ) {
        println("$tag: $message")
    }
}