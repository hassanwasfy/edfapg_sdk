package com.edfapay.payment_gateway.app.toolbox

internal actual class EdfaPgAmountFormatter actual constructor() {
    actual fun amountFormat(amount: Double): String {
        TODO("Not yet implemented")
    }
}