package com.edfapay.payment_gateway.utils

import androidx.compose.runtime.Composable

@Composable
internal actual fun rememberSizeClass(): SizeClass {
    return SizeClass(w = WClass.Expanded, h = HClass.Expanded)
}