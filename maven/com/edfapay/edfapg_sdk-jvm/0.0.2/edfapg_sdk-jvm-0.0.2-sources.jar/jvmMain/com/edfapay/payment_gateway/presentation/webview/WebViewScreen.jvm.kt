package com.edfapay.payment_gateway.presentation.webview

import androidx.compose.runtime.Composable

@Composable
internal actual fun PaymentWebView(
    htmlContent: String,
    onClose: () -> Unit,
    onSuccess: (finalUrl: String) -> Unit,
    onFailure: (finalUrl: String) -> Unit
) {
}