package com.edfapay.payment_gateway.presentation.payment.compose

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.edfapay.library.generated.resources.Res
import com.edfapay.library.generated.resources.debit
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp
import org.jetbrains.compose.resources.painterResource


@Composable
internal fun CreditCardShadows() {
    val dimens = LocalAppDp.current

    CreditCard(
        modifier = Modifier.padding(horizontal = dimens.dp32).offset(x = dimens.dp180, y = dimens.dp24),
    ) {
        Column(modifier = Modifier.fillMaxSize().background(Color.Blue)) {}
    }

    CreditCard(
        modifier = Modifier.padding(horizontal = dimens.dp32).offset(x = dimens.dp160, y = dimens.dp16),
    ) {
        Column(modifier = Modifier.fillMaxSize().background(Color.Red)) {}
    }
}

@Composable
internal fun CreditCard(
    modifier: Modifier = Modifier,
    elevation: Dp = 0.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val dp = LocalAppDp.current

    Card(
        modifier = modifier.aspectRatio(5 / 3f),
        shape = RoundedCornerShape(dp.dp8),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        content = content
    )
}


@Composable
internal fun FullCreditCard(
    numberDisplay: String,
    holderDisplay: String,
    expDisplay: String,
    cvvDisplay: String,
    elevation: Dp = 0.dp,
    modifier: Modifier = Modifier,
) {
    val sp = LocalAppSp.current
    val dp = LocalAppDp.current

    CreditCard(
        modifier = modifier.padding(horizontal = dp.dp32).fillMaxWidth(),
        elevation = elevation,
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(
                brush = Brush.linearGradient(
                    listOf(
                        Color(0xFF028D63),
                        Color(0xFF00E6A0),
                    )
                )
            ),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                "This card is issued by Swedbank pursuant to licence by Mastercard International.",
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = sp.sp8,
                modifier = Modifier.fillMaxWidth().padding(horizontal = dp.dp16, vertical = dp.dp8),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(dp.dp48).fillMaxWidth().background(Color.Black))

            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = dp.dp16, vertical = dp.dp8),
                verticalArrangement = Arrangement.spacedBy(dp.dp8),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    numberDisplay,
                    fontSize = sp.sp16,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )

                Text(
                    holderDisplay,
                    fontSize = sp.sp14,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(start = dp.dp56, end = dp.dp16),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(
                        "VALID\nTHRU",
                        fontSize = sp.sp6,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                    LabelData(
                        "MONTH/YEAR",
                        expDisplay
                    )
                }

                Spacer(modifier = Modifier.width(dp.dp48))

                LabelData(
                    "CVV",
                    cvvDisplay,
                    sp.sp6
                )
                Spacer(modifier = Modifier.weight(1f))


                Image(
                    painter = painterResource(Res.drawable.debit), contentDescription = null,
                    modifier = Modifier.aspectRatio(1f)
                )
            }
        }
    }
}

@Composable
fun LabelData(
    label: String,
    value: String,
    labelSize: TextUnit = 5.sp,
) {
    val sp = LocalAppSp.current
    Column(
        modifier = Modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            label,
            fontSize = labelSize,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.End,
            modifier = Modifier.padding(end = 2.dp)
        )
        Text(
            value,
            fontSize = sp.sp14,
            fontWeight = FontWeight.Bold,
            color = Color.White,
        )
    }
}


/*
@Composable
internal fun FullCreditCard(
    dimens: DpDimens,
    sp: SpDimens,
    numberDisplay: String,
    holderDisplay: String,
    expDisplay: String,
    cvvDisplay: String,
) {
    Box(
        modifier = Modifier
            .wrapContentHeight()
            .padding(horizontal = dimens.dp64)
            .shadow(dimens.dp8)
            .drawBehind {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(
                            Color(0xFF208151),
                            Color(0xFF2FBD74)
                        ),
                        end = Offset(size.width / 2f, size.height),
                    ),
                    cornerRadius = CornerRadius(24f, 24f)
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Text(
                stringResource(Res.string.label_card_state_title),
                fontSize = sp.sp8,
                fontFamily = poppinsFontFamily(),
                color = Color(0xFFFFFFFF),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )

            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(dimens.dp48)
                    .background(
                        Color(0xFF000000)
                    )
                    .padding(bottom = dimens.dp16)
            )

            Text(
                numberDisplay,
                fontSize = sp.sp14,
                fontFamily = poppinsFontFamily(),
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFFFFF),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = dimens.dp16, vertical = dimens.dp8),
                textAlign = TextAlign.Start
            )

            Text(
                holderDisplay,
                fontSize = sp.sp14,
                fontFamily = poppinsFontFamily(),
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFFFFF),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = dimens.dp16, vertical = dimens.dp8),
                textAlign = TextAlign.Start
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth().padding(bottom = dimens.dp16),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        stringResource(Res.string.label_month_year),
                        fontSize = sp.sp8,
                        fontFamily = poppinsFontFamily(),
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFFFFFFFF),
                        modifier = Modifier
                    )

                    Text(
                        expDisplay,
                        fontSize = sp.sp10,
                        fontFamily = poppinsFontFamily(),
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFFFFF),
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        stringResource(Res.string.label_cvv),
                        fontSize = sp.sp8,
                        fontFamily = poppinsFontFamily(),
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFFFFFFFF),
                        modifier = Modifier
                    )

                    Text(
                        cvvDisplay,
                        fontSize = sp.sp10,
                        fontFamily = poppinsFontFamily(),
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFFFFF),
                    )
                }
            }
        }
    }
}
*/