package com.edfapay.payment_gateway.presentation.payment.designs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import com.edfapay.library.generated.resources.Res
import com.edfapay.library.generated.resources.hint_card_number
import com.edfapay.library.generated.resources.hint_cardholder_name
import com.edfapay.library.generated.resources.label_total_amount
import com.edfapay.payment_gateway.presentation.payment.compose.CvvFieldV2
import com.edfapay.payment_gateway.presentation.payment.compose.ExpireFieldV2
import com.edfapay.payment_gateway.presentation.payment.compose.FullCreditCard
import com.edfapay.payment_gateway.presentation.payment.compose.PgEditTextOutLine
import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState
import com.edfapay.payment_gateway.presentation.payment.utils.CardNumberVisualTransformation
import com.edfapay.payment_gateway.presentation.payment.utils.digitsOnly
import com.edfapay.payment_gateway.presentation.payment.utils.formatMoney
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp
import org.jetbrains.compose.resources.stringResource


@Composable
internal fun DesignOneScreen(
    cardState: CardBackState,
    focusManager: FocusManager,
    holderFocus: FocusRequester,
    numberFocus: FocusRequester,
    cvvFocus: FocusRequester,
    expFocus: FocusRequester,
    panLen: Int,
    cvvTargetLen: Int,
    expDisplay: String,
    cvvDisplay: String,
    holderDisplay: String,
    numberDisplay: String,
    footer: @Composable () -> Unit,
    onStateChange: (CardBackState) -> Unit,
) {
    val dimens = LocalAppDp.current
    val sp = LocalAppSp.current

    LazyColumn(
        Modifier.background(color = Color.White).padding(horizontal = dimens.dp16),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(dimens.dp16)
    ) {
        item {
            Column(
                modifier = Modifier.fillMaxWidth().padding(bottom = dimens.dp8, top = dimens.dp12),
                verticalArrangement = Arrangement.spacedBy(dimens.dp8),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    stringResource(Res.string.label_total_amount),
                    fontWeight = FontWeight.Normal,
                    fontSize = sp.sp16,
                )
                val amount =
                    if (cardState.amount.isEmpty()) "0.00" else cardState.amount.toDouble().formatMoney()

                Text(
                    amount + " " + cardState.currency,
                    fontWeight = FontWeight.Bold,
                    fontSize = sp.sp28,
                )
            }

        }

        item {
            FullCreditCard(
                numberDisplay,
                holderDisplay,
                expDisplay,
                cvvDisplay,
                dimens.dp8
            )
        }

        /* ---------------- Inputs ---------------- */

        item {
            PgEditTextOutLine(
                cardState.holderName,
                stringResource(Res.string.hint_cardholder_name),
                onValueChange = { new: String ->
                    val filtered = new
                        .filter { it.isLetter() || it == ' ' || it == '\'' || it == '-' }
                        .replace(Regex("\\s+"), " ")
                        .take(26)
                    onStateChange(cardState.copy(holderName = filtered))
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next,
                    capitalization = KeyboardCapitalization.Words
                ),
                keyboardActions = KeyboardActions(
                    onNext = { numberFocus.requestFocus() }
                ),
                modifier = Modifier
                    .focusRequester(holderFocus).padding(top = dimens.dp16)
            )
        }


        item {
            PgEditTextOutLine(
                cardState.cardNumber,
                stringResource(Res.string.hint_card_number),
                onValueChange = { input ->
                    val digits = input.filter(Char::isDigit).take(16)
                    onStateChange(cardState.copy(cardNumber = digits))
                    if (digitsOnly(input).length == panLen) cvvFocus.requestFocus()
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(onNext = { cvvFocus.requestFocus() }),
                visualTransformation = CardNumberVisualTransformation(),
                modifier = Modifier
                    .focusRequester(numberFocus)

            )
        }

        item {
            Row(
                modifier = Modifier,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CvvFieldV2(
                    cardState.cvv,
                    onValueChange = {
                        onStateChange(cardState.copy(cvv = it))
                        if (it.length == cvvTargetLen) {
                            expFocus.requestFocus()
                        }
                    },
                    cvvTargetLen = cvvTargetLen,
                    onDone = {
                        expFocus.requestFocus()
                    },
                    focus = cvvFocus,
                )
                Spacer(modifier = Modifier.width(dimens.dp16))
                ExpireFieldV2(
                    cardState.expiry,
                    onValueChange = { onStateChange(cardState.copy(expiry = it)) },
                    onDone = { focusManager.clearFocus() },
                    focus = expFocus,
                )
            }
        }

        /* ---------------- PCI + cards row ---------------- */

        item {
            footer()
        }
    }
}

