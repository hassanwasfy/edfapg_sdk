package com.edfapay.payment_gateway.presentation.payment.designs

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import com.edfapay.library.generated.resources.*
import com.edfapay.payment_gateway.presentation.payment.compose.CreditCard
import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState
import com.edfapay.payment_gateway.presentation.payment.utils.digitsOnly
import com.edfapay.payment_gateway.presentation.payment.utils.formatMoney
import com.edfapay.payment_gateway.presentation.payment.utils.poppinsFontFamily
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun DesignThreeScreen(
    cardState: CardBackState,
    focusManager: FocusManager,
    holderFocus: FocusRequester,
    numberFocus: FocusRequester,
    cvvFocus: FocusRequester,
    expFocus: FocusRequester,
    panLen: Int,
    cvvTargetLen: Int,
    holderDisplay: String,
    numberDisplay: String,
    footer: @Composable () -> Unit,
    onStateChange: (CardBackState) -> Unit,
) {
    val dimens = LocalAppDp.current
    val sp = LocalAppSp.current

    LazyColumn(
        Modifier.background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(dimens.dp8),
        contentPadding = PaddingValues(top = dimens.dp16)
    ) {
        item {
            CreditCard(
                modifier = Modifier.padding(horizontal = dimens.dp32),
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().background(
                        brush = Brush.linearGradient(
                            listOf(
                                Color(0xFF028D63),
                                Color(0xFF00E6A0),
                            )
                        )
                    ).padding(dimens.dp16),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {

                    Text(
                        stringResource(Res.string.label_total_amount),
                        fontSize = sp.sp16,
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth().padding(top = dimens.dp16),
                        textAlign = TextAlign.Start
                    )
                    val amount =
                        if (cardState.amount.isEmpty()) "0.00" else cardState.amount.toDouble().formatMoney()

                    Text(
                        amount + " " + cardState.currency,
                        fontSize = sp.sp28,
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth().padding(top = dimens.dp8),
                        textAlign = TextAlign.Start
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    val s = RoundedCornerShape(topStart = dimens.dp8, topEnd = dimens.dp8)

                    Spacer(
                        Modifier
                            .clip(s)
                            .height(dimens.dp10)
                            .fillMaxWidth(0.90f)
                            .background(Color(0xFF028D63))
                    )
                    Spacer(
                        Modifier
                            .clip(s)
                            .height(dimens.dp8)
                            .fillMaxWidth(0.95f)
                            .background(Color(0xFF22BB8D))
                    )

                    Surface(
                        shape = RoundedCornerShape(dimens.dp8),
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = dimens.dp12, vertical = dimens.dp12),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(dimens.dp8)
                        ) {
                            Spacer(Modifier.width(dimens.dp4))
                            Column(
                                modifier = Modifier.weight(0.15f),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val icon = detectCardNetwork(cardState.cardNumber)
                                Image(
                                    painterResource(icon),
                                    contentDescription = null,
                                    modifier = Modifier.size(dimens.dp48)
                                )
                            }

                            Column(
                                modifier = Modifier.weight(0.85f)
                            ) {
                                Text(
                                    holderDisplay,
                                    fontSize = sp.sp14,
                                    fontFamily = poppinsFontFamily()
                                )
                                Text(
                                    numberDisplay,
                                    fontSize = sp.sp14,
                                    fontFamily = poppinsFontFamily()
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Screen(
                cardState.holderName,
                cardState.cardNumber,
                cardState.cvv,
                cardState.expiry,
                cvvTargetLen = cvvTargetLen,
                focusManager = focusManager,
                onNameChange = { new: String ->
                    val filtered = new
                        .filter { it.isLetter() || it == ' ' || it == '\'' || it == '-' }
                        .replace(Regex("\\s+"), " ")
                        .take(26)
                    onStateChange(cardState.copy(holderName = filtered))
                },
                onNumberChange = {
                    onStateChange(cardState.copy(cardNumber = it))
                    if (digitsOnly(it).length == panLen) cvvFocus.requestFocus()
                },
                onCvvChange = {
                    onStateChange(cardState.copy(cvv = it))
                    if (it.length == cvvTargetLen) {
                        expFocus.requestFocus()
                    }
                },
                onExpChange = { onStateChange(cardState.copy(expiry = it)) },
                numberFocus = numberFocus,
                holderFocus = holderFocus,
                cvvFocus = cvvFocus,
                expFocus = expFocus,
                footer = footer,
            )
        }
    }
}

internal fun detectCardNetwork(pan: String): DrawableResource {
    return when {
        pan.startsWith("4") -> Res.drawable.icon_visa
        pan.matches(Regex("^5[1-5].*")) -> Res.drawable.icon_master_card
        pan.matches(Regex("^2(2[2-9]|[3-6]|7[01]).*")) -> Res.drawable.icon_master_card
        pan.startsWith("34") || pan.startsWith("37") -> Res.drawable.icon_amex
        else -> Res.drawable.icon_visa
    }
}