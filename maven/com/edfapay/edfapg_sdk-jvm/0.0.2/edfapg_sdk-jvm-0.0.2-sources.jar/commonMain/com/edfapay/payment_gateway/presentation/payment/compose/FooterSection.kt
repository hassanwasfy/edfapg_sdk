package com.edfapay.payment_gateway.presentation.payment.compose

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.edfapay.library.generated.resources.*
import com.edfapay.payment_gateway.presentation.payment.utils.poppinsFontFamily
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun FooterSection(
    isEnabled: Boolean,
    onPayButtonCLick: () -> Unit
) {
    val dimens = LocalAppDp.current
    val sp = LocalAppSp.current

    Column(
        modifier = Modifier.fillMaxWidth().padding(top = dimens.dp24),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            enabled = isEnabled,
            onClick = onPayButtonCLick,
            modifier = Modifier,
            color = if (isEnabled) Color(0xFF00E6A0) else Color(0xFFC4C4C4),
            shape = RoundedCornerShape(dimens.dp8)
        ) {
            Text(
                text = stringResource(Res.string.action_pay),
                fontFamily = poppinsFontFamily(),
                fontWeight = FontWeight.Medium,
                fontSize = sp.sp16,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = dimens.dp12),
                textAlign = TextAlign.Center,
                color = Color.White
            )
        }

        Image(
            painterResource(Res.drawable.icon_pci),
            contentDescription = null,
            modifier = Modifier.padding(top = dimens.dp16),
            contentScale = ContentScale.Fit
        )

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = dimens.dp12),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(dimens.dp12)
        ) {
            Spacer(Modifier.weight(1f))
            Image(
                painterResource(Res.drawable.icon_mada),
                contentDescription = null,
                modifier = Modifier,
                contentScale = ContentScale.Fit
            )

            Image(
                painterResource(Res.drawable.icon_master_card),
                contentDescription = null,
                modifier = Modifier,
                contentScale = ContentScale.Fit
            )

            Image(
                painterResource(Res.drawable.icon_visa),
                contentDescription = null,
                modifier = Modifier,
                contentScale = ContentScale.Fit
            )

            Image(
                painterResource(Res.drawable.icon_amex),
                contentDescription = null,
                modifier = Modifier,
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.weight(1f))
        }

        Image(
            painterResource(Res.drawable.icon_powered_by),
            contentDescription = null,
            modifier = Modifier.padding(vertical = dimens.dp8),
            contentScale = ContentScale.Fit
        )
    }

}