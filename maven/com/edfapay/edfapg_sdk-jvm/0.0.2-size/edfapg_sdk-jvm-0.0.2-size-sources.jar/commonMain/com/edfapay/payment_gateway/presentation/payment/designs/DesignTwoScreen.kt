package com.edfapay.payment_gateway.presentation.payment.designs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.edfapay.library.generated.resources.Res
import com.edfapay.library.generated.resources.hint_cardholder_name
import com.edfapay.library.generated.resources.label_total_amount
import com.edfapay.payment_gateway.presentation.payment.compose.*
import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState
import com.edfapay.payment_gateway.presentation.payment.utils.digitsOnly
import com.edfapay.payment_gateway.presentation.payment.utils.formatMoney
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun DesignTwoScreen(
    cardState: CardBackState,
    focusManager: FocusManager,
    holderFocus: FocusRequester,
    numberFocus: FocusRequester,
    cvvFocus: FocusRequester,
    expFocus: FocusRequester,
    panLen: Int,
    cvvTargetLen: Int,
    holderDisplay: String,
    numberDisplay: String,
    expDisplay: String,
    cvvDisplay: String,
    footer: @Composable () -> Unit,
    onStateChange: (CardBackState) -> Unit,
) {
    val dimens = LocalAppDp.current
    val sp = LocalAppSp.current

    LazyColumn(
        Modifier.background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom
    ) {

        item {
            Box(
                modifier = Modifier.fillMaxWidth().padding(top = dimens.dp8),
            ) {
                Column(
                    Modifier.padding(start = dimens.dp16).align(Alignment.CenterStart),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        stringResource(Res.string.label_total_amount),
                        fontWeight = FontWeight.Medium,
                        fontSize = sp.sp16,
                        modifier = Modifier.padding(bottom = dimens.dp8)
                    )
                    val amount =
                        if (cardState.amount.isEmpty()) "0.00" else cardState.amount.toDouble().formatMoney()
                    Text(
                        amount + "\n" + cardState.currency,
                        fontWeight = FontWeight.Bold,
                        fontSize = sp.sp28,
                    )
                }//left

                Box {
                    CreditCardShadows()
                    FullCreditCard(
                        holderDisplay = holderDisplay,
                        numberDisplay = numberDisplay,
                        expDisplay = expDisplay,
                        cvvDisplay = cvvDisplay,
                        elevation = 0.dp,
                        modifier = Modifier.offset(x = dimens.dp120)
                    )
                }
            }
        }

        item {
            Screen(
                cardState.holderName,
                cardState.cardNumber,
                cardState.cvv,
                cardState.expiry,
                cvvTargetLen = cvvTargetLen,
                focusManager = focusManager,
                onNameChange = { new: String ->
                    val filtered = new
                        .filter { it.isLetter() || it == ' ' || it == '\'' || it == '-' }
                        .replace(Regex("\\s+"), " ")
                        .take(26)
                    onStateChange(cardState.copy(holderName = filtered))
                },
                onNumberChange = {
                    onStateChange(cardState.copy(cardNumber = it))
                    if (digitsOnly(it).length == panLen) cvvFocus.requestFocus()
                },
                onCvvChange = {
                    onStateChange(cardState.copy(cvv = it))
                    if (it.length == cvvTargetLen) {
                        expFocus.requestFocus()
                    }
                },
                onExpChange = { onStateChange(cardState.copy(expiry = it)) },
                numberFocus = numberFocus,
                holderFocus = holderFocus,
                cvvFocus = cvvFocus,
                expFocus = expFocus,
                footer = footer,
            )
        }
    }
}

@Composable
fun Screen(
    holderName: String,
    cardNumber: String,
    cvv: String,
    expiry: String,
    cvvTargetLen: Int,
    focusManager: FocusManager,
    onNameChange: (String) -> Unit,
    onNumberChange: (String) -> Unit,
    onCvvChange: (String) -> Unit,
    onExpChange: (String) -> Unit,
    numberFocus: FocusRequester,
    holderFocus: FocusRequester,
    cvvFocus: FocusRequester,
    expFocus: FocusRequester,
    footer: @Composable () -> Unit,
) {
    val dimens = LocalAppDp.current
    Column(
        modifier = Modifier.padding(top = dimens.dp16),
        verticalArrangement = Arrangement.spacedBy(dimens.dp12)
    ) {
        PgEditText(
            holderName,
            stringResource(Res.string.hint_cardholder_name),
            onValueChange = onNameChange,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Next,
                capitalization = KeyboardCapitalization.Words
            ),
            keyboardActions = KeyboardActions(
                onNext = {
                    numberFocus.requestFocus()
                }
            ),
            modifier = Modifier
                .padding(top = dimens.dp24)
                .focusRequester(holderFocus)
        )

        NumberFieldV1(
            cardNumber,
            onValueChange = onNumberChange,
            onDone = { cvvFocus.requestFocus() },
            focus = numberFocus,
        )

        CvvFieldV1(
            cvv,
            onValueChange = onCvvChange,
            cvvTargetLen = cvvTargetLen,
            onDone = {
                expFocus.requestFocus()
            },
            focus = cvvFocus,
        )



        ExpireFieldV1(
            expiry,
            onValueChange = onExpChange,
            onDone = { focusManager.clearFocus() },
            focus = expFocus,
        )


        Column(modifier = Modifier.padding(horizontal = dimens.dp16)) {
            footer()
        }

    }
}