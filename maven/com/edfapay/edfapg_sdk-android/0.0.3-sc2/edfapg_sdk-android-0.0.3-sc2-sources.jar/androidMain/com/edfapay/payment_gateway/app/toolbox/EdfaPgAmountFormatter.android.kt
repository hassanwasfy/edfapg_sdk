package com.edfapay.payment_gateway.app.toolbox

import java.text.NumberFormat
import java.util.Locale

internal actual class EdfaPgAmountFormatter actual constructor() {

    private companion object {
        private const val INTEGER_DIGITS_MIN = 1
        private const val FRACTION_DIGITS = 2
    }

    private val amountFormat = NumberFormat.getNumberInstance(Locale.US).apply {
        isGroupingUsed = false
        isParseIntegerOnly = false
        minimumFractionDigits = FRACTION_DIGITS
        maximumFractionDigits = FRACTION_DIGITS
        minimumIntegerDigits = INTEGER_DIGITS_MIN
    }

    actual fun amountFormat(amount: Double): String = amountFormat.format(amount)
}