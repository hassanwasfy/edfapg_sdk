package com.edfapay.payment_gateway.utils

import android.util.Log

actual object KmpLogger {
    actual fun log(level: KMP_LEVEL, message: String, throwable: Throwable?) {
        when (level) {
            KMP_LEVEL.DEBUG -> Log.d(tag, message)
            KMP_LEVEL.INFO -> Log.i(tag, message)
            KMP_LEVEL.WARN -> Log.w(tag, message, throwable)
            KMP_LEVEL.ERROR -> Log.e(tag, message, throwable)
        }
    }

}
