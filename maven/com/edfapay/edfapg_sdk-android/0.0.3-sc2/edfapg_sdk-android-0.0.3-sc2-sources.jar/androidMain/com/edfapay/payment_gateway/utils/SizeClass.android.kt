package com.edfapay.payment_gateway.utils

import androidx.activity.compose.LocalActivity
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowHeightSizeClass
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.Composable

@OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
@Composable
internal actual fun rememberSizeClass(): SizeClass {
    val activity = LocalActivity.current
        ?: return SizeClass(WClass.Compact, HClass.Medium)

    val wsc = calculateWindowSizeClass(activity)

    fun mapW(w: WindowWidthSizeClass) = when (w) {
        WindowWidthSizeClass.Compact -> WClass.Compact
        WindowWidthSizeClass.Medium -> WClass.Medium
        WindowWidthSizeClass.Expanded -> WClass.Expanded
        else -> WClass.Medium
    }

    fun mapH(h: WindowHeightSizeClass) = when (h) {
        WindowHeightSizeClass.Compact -> HClass.Compact
        WindowHeightSizeClass.Medium -> HClass.Medium
        WindowHeightSizeClass.Expanded -> HClass.Expanded
        else -> HClass.Medium
    }

    return SizeClass(
        w = mapW(wsc.widthSizeClass),
        h = mapH(wsc.heightSizeClass)
    )
}
