package com.edfapay.payment_gateway.presentation.webview

import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.viewinterop.AndroidView
import com.edfapay.payment_gateway.app.core.EdfaPgCredential
import com.edfapay.payment_gateway.presentation.payment.models.EdfaCardPay

@Composable
internal actual fun PaymentWebView(
    htmlContent: String,
    onClose: () -> Unit,
    onSuccess: (String) -> Unit,
    onFailure: (String) -> Unit,
) {
    AndroidView(factory = { context ->
        WebView(context).apply {
            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            cm.setAcceptThirdPartyCookies(this, true)

            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val nextUrl = request.url.toString()
                    return when {
                        nextUrl.startsWith("https://edfapay.com/process-completed") -> { onSuccess(nextUrl); true }
                        nextUrl.startsWith("https://edfapay.com/process-failed") -> { onFailure(nextUrl); true }
                        else -> false
                    }
                }
            }

            loadDataWithBaseURL(EdfaPgCredential.getPaymentUrl(), htmlContent, "text/html", "utf-8", null)
        }
    })
}

