package com.edfapay.payment_gateway.presentation

import androidx.compose.runtime.Composable
import com.edfapay.payment_gateway.app.PaymentScreen
import com.edfapay.payment_gateway.app.WebViewScreen

@Composable
fun EdfaPayUi(openWebView: () -> Unit) {
    PaymentScreen(openWebView = openWebView)
}

@Composable
fun EdfaWebView(
    onClose: () -> Unit,
    onSuccess : () -> Unit,
    onFailure : () -> Unit,
) {
    WebViewScreen(
        onClose = onClose,
        onSuccess = onSuccess,
        onFailure = onFailure,
    )
}