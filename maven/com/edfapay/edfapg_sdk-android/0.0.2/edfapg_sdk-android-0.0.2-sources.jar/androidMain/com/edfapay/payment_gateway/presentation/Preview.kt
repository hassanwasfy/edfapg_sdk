package com.edfapay.payment_gateway.presentation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.edfapay.payment_gateway.app.toolbox.EdfaPayDesignType
import com.edfapay.payment_gateway.presentation.payment.designs.HolderScreen
import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState
import com.edfapay.payment_gateway.presentation.payment.utils.Dimens
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp

@Preview()
@Composable
fun TestUiScreen() {
    SdkPreview {
        SdkPreview {
            Scaffold { scaffoldPadding ->
                Column(
                    modifier = Modifier.fillMaxSize().padding(scaffoldPadding),
                ) {
                    HolderScreen(
                        EdfaPayDesignType.THREE,
                        CardBackState(
                            "5123450000000008",
                            "Hassan Wasfy",
                            "0129",
                            "100",
                            "5000",
                            "SAR"
                        ),
                        {},
                        {}
                    )
                }
            }
        }
    }
}


@Composable
internal fun SdkPreview(
    content: @Composable () -> Unit
) {
    val d = Dimens.expanded
    val s = Dimens.expandedSp
    CompositionLocalProvider(LocalAppDp provides d, LocalAppSp provides s) {
        content()
    }
}