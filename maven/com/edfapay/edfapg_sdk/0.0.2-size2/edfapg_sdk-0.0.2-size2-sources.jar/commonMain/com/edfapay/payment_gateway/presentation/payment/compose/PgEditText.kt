package com.edfapay.payment_gateway.presentation.payment.compose

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.edfapay.library.generated.resources.Res
import com.edfapay.library.generated.resources.icon_clear
import com.edfapay.payment_gateway.presentation.payment.utils.poppinsFontFamily
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp
import org.jetbrains.compose.resources.painterResource

@Composable
internal fun PgEditText(
    value: String,
    title: String,
    onValueChange: (String) -> Unit,
    keyboardOptions: KeyboardOptions,
    keyboardActions: KeyboardActions,
    modifier: Modifier,
    visualTransformation: VisualTransformation = VisualTransformation.None,
) {
    val dimens = LocalAppDp.current
    val sp = LocalAppSp.current

    Surface(
        modifier = modifier.padding(
            horizontal = dimens.dp16,
        ),
        color = Color(0xFFF7F9FC),
        shape = RoundedCornerShape(dimens.dp12)
    ) {
        Column(
            modifier = Modifier
                .padding(
                    horizontal = dimens.dp16,
                    vertical = dimens.dp16
                )
        ) {
            Text(
                text = title,
                fontSize = sp.sp12,
                fontFamily = poppinsFontFamily(),
                color = Color(0xFF8F9BB3)
            )

            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle.Default.copy(
                    color = Color(0xFF2E3A59),
                    fontFamily = poppinsFontFamily(),
                    fontSize = sp.sp14,
                ),
                keyboardOptions = keyboardOptions,
                keyboardActions = keyboardActions,
                visualTransformation = visualTransformation,
                decorationBox = { inner ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                        ) {
                            inner()
                        }
                        AnimatedVisibility(value.isNotEmpty()) {
                            Icon(
                                painter = painterResource(Res.drawable.icon_clear),
                                contentDescription = null,
                                tint = Color(0xFF8F9BB3),
                                modifier = Modifier
                                    .padding(start = dimens.dp8)
                                    .size(dimens.dp16)
                                    .clickable {
                                        onValueChange("")
                                    }
                            )
                        }
                    }
                }
            )
        }
    }
}


@Composable
internal fun PgEditTextOutLine(
    value: String,
    title: String,
    onValueChange: (String) -> Unit,
    keyboardOptions: KeyboardOptions,
    keyboardActions: KeyboardActions,
    modifier: Modifier,
    visualTransformation: VisualTransformation = VisualTransformation.None,
) {
    val dp = LocalAppDp.current
    val sp = LocalAppSp.current
    Column(
        modifier = modifier
    ) {
        Text(
            text = title, fontSize = sp.sp14, color = Color.Black,
            modifier = Modifier.padding(bottom = dp.dp12)
        )
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color.Transparent,
            shape = RoundedCornerShape(dp.dp8),
            border = BorderStroke(1.dp, Color(0xFFD5E1EC))
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = dp.dp16, vertical = dp.dp16),
                textStyle = TextStyle.Default.copy(
                    color = Color(0xFF2E3A59),
                    fontFamily = poppinsFontFamily(),
                    fontWeight = FontWeight.Normal,
                    fontSize = sp.sp18
                ),
                keyboardOptions = keyboardOptions,
                keyboardActions = keyboardActions,
                visualTransformation = visualTransformation,
                decorationBox = { inner ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                        ) {
                            if (value.isEmpty()) {
                                Text(
                                    text = title,
                                    fontSize = sp.sp18,
                                    fontFamily = poppinsFontFamily(),
                                    color = Color(0xFF8F9BB3)
                                )
                            }
                            inner()
                        }
                        AnimatedVisibility(value.isNotEmpty()) {
                            Icon(
                                painter = painterResource(Res.drawable.icon_clear),
                                contentDescription = null,
                                tint = Color(0xFF8F9BB3),
                                modifier = Modifier
                                    .padding(start = dp.dp8)
                                    .size(dp.dp16)
                                    .clickable {
                                        onValueChange("")
                                    }
                            )
                        }
                    }
                },
            )
        }
    }
}