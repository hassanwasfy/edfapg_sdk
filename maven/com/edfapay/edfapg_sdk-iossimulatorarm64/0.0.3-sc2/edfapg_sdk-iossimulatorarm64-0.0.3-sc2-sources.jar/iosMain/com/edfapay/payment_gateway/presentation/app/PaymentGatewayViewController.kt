package com.edfapay.payment_gateway.presentation.app

import androidx.compose.ui.window.ComposeUIViewController
import com.edfapay.payment_gateway.app.PaymentScreen
import com.edfapay.payment_gateway.app.WebViewScreen
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ExportObjCClass
import platform.UIKit.UIViewController
import kotlin.experimental.ExperimentalObjCName

@OptIn(ExperimentalObjCName::class, BetaInteropApi::class)
@ExportObjCClass
@ObjCName("EdfaPayUi", exact = true)
class PaymentGatewayViewController {
    @OptIn(ExperimentalForeignApi::class)
    fun create(openWebView: () -> Unit): UIViewController {
        return ComposeUIViewController(
            configure = {
                enforceStrictPlistSanityCheck = false //disable strict safety check to avoid crashing
            }) {
            PaymentScreen(openWebView = openWebView)
        }
    }
}

@OptIn(ExperimentalObjCName::class, BetaInteropApi::class)
@ExportObjCClass
@ObjCName("EdfaWebView", exact = true)
class PaymentGatewayWebView {
    @OptIn(ExperimentalForeignApi::class)
    fun create(
        onClose: () -> Unit,
        onSuccess: () -> Unit,
        onFailure: () -> Unit,
    ): UIViewController {
        return ComposeUIViewController(
            configure = {
                enforceStrictPlistSanityCheck = false //disable strict safety check to avoid crashing
            }) {
            WebViewScreen(
                onClose = onClose,
                onFailure = onFailure,
                onSuccess = onSuccess,
            )
        }
    }
}