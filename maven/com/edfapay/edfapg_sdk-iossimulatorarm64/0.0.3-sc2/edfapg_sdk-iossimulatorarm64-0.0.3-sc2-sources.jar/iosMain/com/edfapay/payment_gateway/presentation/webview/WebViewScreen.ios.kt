package com.edfapay.payment_gateway.presentation.webview

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.interop.UIKitView
import com.edfapay.payment_gateway.app.core.EdfaPgCredential
import com.edfapay.payment_gateway.presentation.payment.models.EdfaCardPay
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.readValue
import platform.CoreGraphics.CGRectZero
import platform.Foundation.NSURL
import platform.WebKit.*
import platform.darwin.NSObject
import platform.WebKit.WKNavigationActionPolicy.WKNavigationActionPolicyCancel
import platform.WebKit.WKNavigationActionPolicy.WKNavigationActionPolicyAllow

@OptIn(ExperimentalForeignApi::class)
@Composable
actual fun PaymentWebView(
    htmlContent: String,
    onClose: () -> Unit,
    onSuccess: (String) -> Unit,
    onFailure: (String) -> Unit,
) {
    UIKitView(
        modifier = Modifier.fillMaxSize(),
        factory = {
            val config = WKWebViewConfiguration().apply {
                websiteDataStore = WKWebsiteDataStore.defaultDataStore()
                preferences.javaScriptEnabled = true
            }
            val webView = WKWebView(
                frame = CGRectZero.readValue(),
                configuration = config
            )

            webView.allowsBackForwardNavigationGestures = false
            webView.navigationDelegate = object : NSObject(), WKNavigationDelegateProtocol {
                override fun webView(
                    webView: WKWebView,
                    decidePolicyForNavigationAction: WKNavigationAction,
                    decisionHandler: (WKNavigationActionPolicy) -> Unit
                ) {
                    val nextUrl = decidePolicyForNavigationAction.request.URL?.absoluteString ?: ""
                    when {
                        nextUrl.startsWith("https://edfapay.com/process-completed") -> {
                            onSuccess(nextUrl)
                            decisionHandler(WKNavigationActionPolicyCancel)
                            return
                        }
                        nextUrl.startsWith("https://edfapay.com/process-failed") -> {
                            onFailure(nextUrl)
                            decisionHandler(WKNavigationActionPolicyCancel)
                            return
                        }
                        else -> {
                            decisionHandler(WKNavigationActionPolicyAllow)
                            return
                        }
                    }
                }
            }

            val nsBase = NSURL.URLWithString(EdfaPgCredential.getPaymentUrl())
            webView.loadHTMLString(htmlContent, baseURL = nsBase)
            webView
        }
    )
}
