package com.edfapay.payment_gateway.utils

import androidx.compose.runtime.Composable
import kotlinx.cinterop.ExperimentalForeignApi
import platform.CoreGraphics.CGRectGetHeight
import platform.CoreGraphics.CGRectGetWidth
import platform.UIKit.UIScreen

@OptIn(ExperimentalForeignApi::class)
@Composable
internal actual fun rememberSizeClass(): SizeClass {
    val bounds = UIScreen.mainScreen.bounds

    val w: Double = CGRectGetWidth(bounds)
    val h: Double = CGRectGetHeight(bounds)

    val wClass = when {
        w < 600.0 -> WClass.Compact
        w < 840.0 -> WClass.Medium
        else -> WClass.Expanded
    }

    val hClass = when {
        h < 480.0 -> HClass.Compact
        h < 900.0 -> HClass.Medium
        else -> HClass.Expanded
    }

    return SizeClass(w = wClass, h = hClass)
}

