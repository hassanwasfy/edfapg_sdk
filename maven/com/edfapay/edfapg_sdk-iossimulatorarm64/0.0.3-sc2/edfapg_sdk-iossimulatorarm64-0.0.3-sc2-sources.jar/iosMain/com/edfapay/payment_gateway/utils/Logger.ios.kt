package com.edfapay.payment_gateway.utils

actual object KmpLogger {
    actual fun log(level: KMP_LEVEL, message: String, throwable: Throwable?) {
        val prefix = when (level) {
            KMP_LEVEL.DEBUG -> "D"
            KMP_LEVEL.INFO -> "I"
            KMP_LEVEL.WARN -> "W"
            KMP_LEVEL.ERROR -> "E"
        }
        val safeErr = throwable?.message.orEmpty()
        val line = "$prefix [$tag] $message${if (safeErr.isNotEmpty()) " | error=$safeErr" else ""}"
        println(line)
    }
}
