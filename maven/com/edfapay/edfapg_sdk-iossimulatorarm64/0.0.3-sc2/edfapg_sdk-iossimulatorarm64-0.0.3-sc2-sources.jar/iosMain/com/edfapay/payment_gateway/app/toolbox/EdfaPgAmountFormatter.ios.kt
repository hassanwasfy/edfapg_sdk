package com.edfapay.payment_gateway.app.toolbox

import platform.Foundation.NSLocale
import platform.Foundation.NSNumber
import platform.Foundation.NSNumberFormatter
import platform.Foundation.NSNumberFormatterDecimalStyle
import platform.Foundation.localeWithLocaleIdentifier
import platform.Foundation.numberWithDouble

internal actual class EdfaPgAmountFormatter actual constructor() {

    private companion object {
        private const val INTEGER_DIGITS_MIN: ULong = 1u
        private const val FRACTION_DIGITS: ULong = 2u
        private const val LOCALE_US = "en_US_POSIX"
    }

    private val formatter: NSNumberFormatter = NSNumberFormatter().apply {
        // Decimal formatting (not currency)
        numberStyle = NSNumberFormatterDecimalStyle

        locale = NSLocale.localeWithLocaleIdentifier(LOCALE_US)

        // No grouping separators (e.g., 1,000 -> 1000)
        usesGroupingSeparator = false

        minimumFractionDigits = FRACTION_DIGITS
        maximumFractionDigits = FRACTION_DIGITS
        minimumIntegerDigits = INTEGER_DIGITS_MIN
    }

    actual fun amountFormat(amount: Double): String {
        val nsNumber = NSNumber.numberWithDouble(amount)
        // If formatting fails for any reason, return a stable fallback.
        return formatter.stringFromNumber(nsNumber) ?: amount.toString()
    }
}
