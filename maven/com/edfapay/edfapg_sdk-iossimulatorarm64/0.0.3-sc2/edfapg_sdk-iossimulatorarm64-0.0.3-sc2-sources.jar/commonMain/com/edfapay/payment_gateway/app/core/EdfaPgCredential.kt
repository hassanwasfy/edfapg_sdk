/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.app.core


/**
 * The [EdfaPgSdk] credentials holder.
 * It stores and retrieve it automatically after the first successful [init].
 * [EdfaPgCredential] stores values in the [EdfaPgStorage].
 * @throws EdfaPgSdkIsNotInitializedException if [EdfaPgSdk] is not initialized.
 */
object EdfaPgCredential {

    private var _paymentUrl: String? = null
    private var _apiKey: String? = null

    private var _isInitialized: Boolean? = null

    internal fun getApiKey(): String {
        return _apiKey ?: throw EdfaPgSdkIsNotInitializedException()
    }

    fun getPaymentUrl(): String {
        return _paymentUrl ?: throw EdfaPgSdkIsNotInitializedException()
    }


    /**
     * Initialize the [EdfaPgCredential] values.
     *
     * @param apiKey the [EdfaPgCredential.API_KEY] value.
     * @param paymentUrl the [EdfaPgCredential.PAYMENT_URL] value.
     */
    fun init(
        apiKey: String,
        paymentUrl: String,
    ) {
        this._paymentUrl = paymentUrl
        this._apiKey = apiKey
    }


    /**
     * Soft check of the [EdfaPgCredential] initialization status.
     * @return the true if all [EdfaPgCredential] values are provided.
     * @throws EdfaPgSdkIsNotInitializedException
     */
    fun isInitialized(): Boolean {
        if (_isInitialized == null) {
            _isInitialized =
                !_apiKey.isNullOrEmpty() && !_paymentUrl.isNullOrEmpty()
        }

        return _isInitialized ?: throw EdfaPgSdkIsNotInitializedException()
    }

    /**
     * Hard check of the [EdfaPgCredential] initialization status.
     * @throws EdfaPgSdkIsNotInitializedException
     */
    fun requireInit() {
        if (!isInitialized()) {
            throw EdfaPgSdkIsNotInitializedException()
        }
    }
}
