package com.edfapay.payment_gateway.presentation.payment.designs

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalFocusManager
import com.edfapay.library.generated.resources.*
import com.edfapay.payment_gateway.app.toolbox.EdfaPayDesignType
import com.edfapay.payment_gateway.presentation.payment.compose.FooterSection
import com.edfapay.payment_gateway.presentation.payment.utils.*
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun HolderScreen(
    screenCode: EdfaPayDesignType,
    cardState: CardBackState,
    executeSale: () -> Unit,
    onStateChange: (CardBackState) -> Unit,
) {
    val focusManager = LocalFocusManager.current
    val holderFocus = remember { FocusRequester() }
    val numberFocus = remember { FocusRequester() }
    val cvvFocus = remember { FocusRequester() }
    val expFocus = remember { FocusRequester() }

    val panDigits = remember(cardState.cardNumber) { digitsOnly(cardState.cardNumber) }
    val brand = remember(panDigits) { detectBrand(panDigits) }
    val panLen = brand.panLen
    val cvvTargetLen = brand.cvvLen

    val expiryPlaceholder = stringResource(Res.string.placeholder_expiry_format)
    val cvvPlaceholder3 = stringResource(Res.string.placeholder_cvv_3)
    val cvvPlaceholder4 = stringResource(Res.string.placeholder_cvv_4)
    val holderPlaceholder = stringResource(Res.string.hint_cardholder_name)
    val cardNumberPlaceholder = stringResource(Res.string.placeholder_card_number)

    val expDisplay = formatExpiry(cardState.expiry).ifBlank { expiryPlaceholder }
    val cvvDisplay = cardState.cvv.ifBlank {
        if (brand.cvvLen == 4) cvvPlaceholder4 else cvvPlaceholder3
    }


    val holderDisplay = remember(cardState.holderName, holderPlaceholder) {
        cardState.holderName.ifBlank { holderPlaceholder }
    }

    val numberDisplay = remember(cardState.cardNumber, cardNumberPlaceholder) {
        val digits = digitsOnly(cardState.cardNumber)
        if (digits.isBlank()) cardNumberPlaceholder
        else formatCardNumber(cardState.cardNumber)
    }

    val isNameValid = cardState.holderName.isNotEmpty()
    val isNumberValid = cardState.cardNumber.isNotEmpty() && cardState.cardNumber.length >= 10
    val isCvvValid = cardState.cvv.length == 3 || cardState.cvv.length == 4
    val isExpiryValid = cardState.expiry.length == 4

    val isEnabled = isNameValid && isNumberValid && isCvvValid && isExpiryValid

    when (screenCode) {
        EdfaPayDesignType.ONE -> {
            DesignOneScreen(
                cardState = cardState,
                focusManager = focusManager,
                holderFocus = holderFocus,
                numberFocus = numberFocus,
                cvvFocus = cvvFocus,
                expFocus = expFocus,
                panLen = panLen,
                cvvTargetLen = cvvTargetLen,
                expDisplay = expDisplay,
                cvvDisplay = cvvDisplay,
                holderDisplay = holderDisplay,
                numberDisplay = numberDisplay,
                footer = {
                    FooterSection(
                        isEnabled
                    ) {
                        executeSale()
                    }
                },
            ) { newData ->
                onStateChange(newData)
            }
        }

        EdfaPayDesignType.TWO -> {
            DesignTwoScreen(
                cardState = cardState,
                focusManager = focusManager,
                holderFocus = holderFocus,
                numberFocus = numberFocus,
                cvvFocus = cvvFocus,
                expFocus = expFocus,
                panLen = panLen,
                cvvTargetLen = cvvTargetLen,
                holderDisplay = holderDisplay,
                numberDisplay = numberDisplay,
                expDisplay = expDisplay,
                cvvDisplay = cvvDisplay,
                footer = {
                    FooterSection(
                        isEnabled
                    ) {
                        executeSale()
                    }
                },
            ) { newData ->
                onStateChange(newData)
            }
        }

        EdfaPayDesignType.THREE -> {
            DesignThreeScreen(
                cardState = cardState,
                focusManager = focusManager,
                holderFocus = holderFocus,
                numberFocus = numberFocus,
                cvvFocus = cvvFocus,
                expFocus = expFocus,
                panLen = panLen,
                cvvTargetLen = cvvTargetLen,
                holderDisplay = holderDisplay,
                numberDisplay = numberDisplay,
                footer = {
                    FooterSection(
                        isEnabled
                    ) {
                        executeSale()
                    }
                },
            ) { newData ->
                onStateChange(newData)
            }
        }
    }
}