package com.edfapay.payment_gateway.di

object Credentials {
    private var apiKey: String? = null

    fun setApiKey(apiKey: String) {
        this.apiKey = apiKey
    }

    fun getApiKey(): String {
        return apiKey ?: throw IllegalStateException("apiKey not set")
    }
}
