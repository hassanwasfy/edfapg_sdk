package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CustomerDto(
    @SerialName("name") val name: String,
    @SerialName("email") val email: String,
    @SerialName("phone") val phone: String,
    @SerialName("idNumber") val idNumber: String,
    @SerialName("idType") val idType: String,
    @SerialName("taxNumber") val taxNumber: String
)