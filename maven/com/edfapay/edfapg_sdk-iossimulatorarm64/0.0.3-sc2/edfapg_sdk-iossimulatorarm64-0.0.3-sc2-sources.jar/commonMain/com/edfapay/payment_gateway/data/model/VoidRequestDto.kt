package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class VoidRequestDto(
    @SerialName("transactionId")
    val transactionId: String
)