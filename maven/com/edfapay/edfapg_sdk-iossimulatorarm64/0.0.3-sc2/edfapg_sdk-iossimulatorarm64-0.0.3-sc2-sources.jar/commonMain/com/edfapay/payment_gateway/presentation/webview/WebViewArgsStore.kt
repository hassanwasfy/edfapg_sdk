package com.edfapay.payment_gateway.presentation.webview

internal object WebViewArgsStore {
    const val MISSING = "html is missing"

    private var htmlContent: String? = null

    fun set(url: String) {
        this.htmlContent = url
    }

    fun get(): String {
        return this.htmlContent ?: MISSING
    }

    fun clear() {
        htmlContent = null
    }
}
