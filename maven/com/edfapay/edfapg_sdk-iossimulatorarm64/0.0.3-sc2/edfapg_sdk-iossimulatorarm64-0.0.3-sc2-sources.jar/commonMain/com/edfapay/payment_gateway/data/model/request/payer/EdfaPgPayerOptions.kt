/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.data.model.request.payer

import kotlinx.datetime.LocalDate
import kotlinx.serialization.Serializable


/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 */
@Serializable
data class EdfaPgPayerOptions(
    val middleName: String? = "undefined",
    val birthdate: LocalDate? = null,
    val address2: String? = "undefined",
    val state: String? = "undefined",
)
