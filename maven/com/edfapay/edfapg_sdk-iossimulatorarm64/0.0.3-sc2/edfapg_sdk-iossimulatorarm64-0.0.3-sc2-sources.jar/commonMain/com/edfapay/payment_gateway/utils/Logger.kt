package com.edfapay.payment_gateway.utils

enum class KMP_LEVEL { DEBUG, INFO, WARN, ERROR }

const val tag = "EDFAPAY_LOGGER"

expect object KmpLogger {
    fun log(level: KMP_LEVEL, message: String, throwable: Throwable? = null)
}

