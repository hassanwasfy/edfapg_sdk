package com.edfapay.payment_gateway.presentation.payment.compose

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import com.edfapay.library.generated.resources.*
import com.edfapay.payment_gateway.presentation.payment.utils.CardNumberVisualTransformation
import com.edfapay.payment_gateway.presentation.payment.utils.ExpiryVisualTransformation
import com.edfapay.payment_gateway.presentation.payment.utils.digitsOnly
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun RowScope.ExpireFieldV2(
    value: String,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    focus: FocusRequester,
) {
    PgEditTextOutLine(
        value,
        stringResource(Res.string.hint_expiry_date),
        onValueChange = { input ->
            val digits = input.filter(Char::isDigit).take(4)
            onValueChange(digits)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Done
        ),
        keyboardActions = KeyboardActions(
            onDone = { onDone() }
        ),
        visualTransformation = ExpiryVisualTransformation(),
        modifier = Modifier
            .weight(1f)
            .focusRequester(focus)
    )
}

@Composable
internal fun RowScope.CvvFieldV2(
    value: String,
    onValueChange: (String) -> Unit,
    cvvTargetLen: Int,
    onDone: () -> Unit,
    focus: FocusRequester,
) {
    PgEditTextOutLine(
        value,
        stringResource(Res.string.hint_cvv_cvc),
        onValueChange = { input ->
            val digits = digitsOnly(input).take(cvvTargetLen)
            onValueChange(digits)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.NumberPassword,
            imeAction = ImeAction.Next
        ),
        keyboardActions = KeyboardActions(
            onNext = { onDone() }
        ),
        modifier = Modifier
            .weight(1f)
            .focusRequester(focus)
    )
}

@Composable
internal fun NameFieldV1(
    value: String,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    focus: FocusRequester,
) {
    PgEditText(
        value,
        stringResource(Res.string.hint_cardholder_name),
        onValueChange = { new: String ->
            val filtered = new
                .filter { it.isLetter() || it == ' ' || it == '\'' || it == '-' }
                .replace(Regex("\\s+"), " ")
                .take(26)
            onValueChange(filtered)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Text,
            imeAction = ImeAction.Next,
            capitalization = KeyboardCapitalization.Words
        ),
        keyboardActions = KeyboardActions(
            onNext = { onDone() }
        ),
        modifier = Modifier
            .focusRequester(focus)
    )
}


@Composable
internal fun NumberFieldV1(
    value: String,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    focus: FocusRequester,
) {
    PgEditText(
        value,
        stringResource(Res.string.hint_card_number),
        onValueChange = { input ->
            val digits = input.filter(Char::isDigit).take(16)
            onValueChange(digits)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Next
        ),
        keyboardActions = KeyboardActions(onNext = { onDone() }),
        visualTransformation = CardNumberVisualTransformation(),
        modifier = Modifier
            .focusRequester(focus)
    )
}


@Composable
internal fun ExpireFieldV1(
    value: String,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    focus: FocusRequester,
) {
    PgEditText(
        value,
        stringResource(Res.string.hint_expiry_date),
        onValueChange = { input ->
            val digits = input.filter(Char::isDigit).take(4)
            onValueChange(digits)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Done
        ),
        keyboardActions = KeyboardActions(
            onDone = { onDone() }
        ),
        visualTransformation = ExpiryVisualTransformation(),
        modifier = Modifier
            .focusRequester(focus)
    )
}


@Composable
internal fun CvvFieldV1(
    value: String,
    onValueChange: (String) -> Unit,
    cvvTargetLen: Int,
    onDone: () -> Unit,
    focus: FocusRequester,
) {
    PgEditText(
        value,
        stringResource(Res.string.hint_cvv_cvc),
        onValueChange = { input ->
            val digits = digitsOnly(input).take(cvvTargetLen)
            onValueChange(digits)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.NumberPassword,
            imeAction = ImeAction.Next
        ),
        keyboardActions = KeyboardActions(
            onNext = { onDone() }
        ),
        modifier = Modifier
            .focusRequester(focus)
    )
}
