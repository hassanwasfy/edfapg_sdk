package com.edfapay.payment_gateway.di

import com.edfapay.payment_gateway.data.providers.ProvidersImpl
import com.edfapay.payment_gateway.data.providers.TransactionProvider
import com.edfapay.payment_gateway.data.remote.KtorEdfaPayApiService
import com.edfapay.payment_gateway.data.service.EdfaPayApiService
import com.edfapay.payment_gateway.presentation.payment.PaymentViewModel
import io.ktor.client.*

internal object SdkContainer {
    private var dependencies: Dependencies? = null

    fun init(apiKey: String, baseUrl: String) {
        check(dependencies == null) { "SDK already initialized" }
        dependencies = Dependencies(apiKey, baseUrl)
    }

    fun get(): Dependencies =
        dependencies ?: error("SDK is not initialized. Call SDK.init() first.")

    fun isInitialized(): Boolean = dependencies != null
}


internal class Dependencies(apiKey: String, baseUrl: String) {
    private val httpClient: HttpClient = createHttpClient(apiKey)
    private val apiService: EdfaPayApiService = KtorEdfaPayApiService(httpClient, baseUrl)
    private val transactionProvider: TransactionProvider = ProvidersImpl(apiService)

    fun paymentViewModel(): PaymentViewModel = PaymentViewModel(transactionProvider)

    fun transactionProvider(): TransactionProvider = transactionProvider

}
