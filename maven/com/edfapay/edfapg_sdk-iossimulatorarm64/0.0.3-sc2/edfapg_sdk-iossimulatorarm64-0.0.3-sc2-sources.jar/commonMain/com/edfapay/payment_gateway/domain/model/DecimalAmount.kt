package com.edfapay.payment_gateway.domain.model

/**
 * KMP-safe representation of decimal money without floating-point.
 * - raw: original string from API
 * - minorUnits: parsed (optional) to allow arithmetic safely when scale is known
 * - scale: number of decimal digits used to compute minorUnits
 */
internal data class DecimalAmount(
    val raw: String,
    val minorUnits: Long?,
    val scale: Int
)
