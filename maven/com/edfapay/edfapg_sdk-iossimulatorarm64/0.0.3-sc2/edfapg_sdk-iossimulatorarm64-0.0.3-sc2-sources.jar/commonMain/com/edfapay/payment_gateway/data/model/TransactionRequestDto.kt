package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class TransactionRequestDto(
    @SerialName("amount")
    val amount: Double,
    @SerialName("transactionId")
    val transactionId: String
)