package com.edfapay.payment_gateway.app.toolbox

internal object CurrencyMeta {

    /**
     * ISO 4217 fraction digits (minor units).
     * Keep this list aligned with what your gateway accepts.
     * If code is missing: treat as unknown.
     */
    private val fractionDigits: Map<String, Int> = mapOf(
        // 2 digits (most)
        "USD" to 2, "EUR" to 2, "GBP" to 2, "EGP" to 2, "SAR" to 2, "AED" to 2,

        // 3 digits
        "KWD" to 3, "BHD" to 3, "JOD" to 3, "OMR" to 3, "TND" to 3,

        // 0 digits
        "JPY" to 0
    )

    fun isKnown(code: String): Boolean = fractionDigits.containsKey(code)

    fun defaultFractionDigits(code: String): Int =
        fractionDigits[code] ?: error("Unknown currency code: $code")
}
