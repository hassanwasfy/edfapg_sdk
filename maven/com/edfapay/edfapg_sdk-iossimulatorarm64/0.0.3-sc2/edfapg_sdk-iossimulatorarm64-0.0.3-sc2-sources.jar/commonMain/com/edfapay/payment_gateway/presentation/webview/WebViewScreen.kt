package com.edfapay.payment_gateway.presentation.webview

import androidx.compose.runtime.Composable
import com.edfapay.payment_gateway.app.WebViewScreen
import com.edfapay.payment_gateway.app.core.EdfaPgCredential
import com.edfapay.payment_gateway.utils.KMP_LEVEL
import com.edfapay.payment_gateway.utils.KmpLogger

@Composable
internal fun PaymentWebViewRoute(
    onClose: () -> Unit,
    onSuccess: (finalUrl: String) -> Unit,
    onFailure: (finalUrl: String) -> Unit,
) {
    val htmlContent = WebViewArgsStore.get()
    if (htmlContent == WebViewArgsStore.MISSING) {
        onClose()
        return
    }
    PaymentWebView(
        htmlContent = htmlContent,
        onClose = onClose,
        onSuccess = onSuccess,
        onFailure = onFailure
    )
}


@Composable
internal expect fun PaymentWebView(
    htmlContent: String,
    onClose: () -> Unit,
    onSuccess: (finalUrl: String) -> Unit,
    onFailure: (finalUrl: String) -> Unit,
)


