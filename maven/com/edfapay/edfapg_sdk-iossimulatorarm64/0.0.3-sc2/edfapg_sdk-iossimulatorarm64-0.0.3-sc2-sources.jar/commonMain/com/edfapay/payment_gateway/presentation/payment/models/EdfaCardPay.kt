package com.edfapay.payment_gateway.presentation.payment.models

import com.edfapay.library.generated.resources.Res
import com.edfapay.library.generated.resources.value_missing_id_number
import com.edfapay.library.generated.resources.value_missing_id_type
import com.edfapay.library.generated.resources.value_missing_state_name
import com.edfapay.library.generated.resources.value_missing_tax_number
import com.edfapay.library.generated.resources.value_missing_token
import com.edfapay.payment_gateway.app.core.EdfaPgCredential
import com.edfapay.payment_gateway.app.toolbox.EdfaPayDesignType
import com.edfapay.payment_gateway.app.toolbox.EdfaPayLanguage
import com.edfapay.payment_gateway.data.model.BillingAddressDto
import com.edfapay.payment_gateway.data.model.CardDto
import com.edfapay.payment_gateway.data.model.CustomerDto
import com.edfapay.payment_gateway.data.model.InvoiceDto
import com.edfapay.payment_gateway.data.model.SaleRequestDto
import com.edfapay.payment_gateway.data.model.request.Extra
import com.edfapay.payment_gateway.data.model.request.card.EdfaPgCard
import com.edfapay.payment_gateway.data.model.request.options.EdfaPgSaleOptions
import com.edfapay.payment_gateway.data.model.request.order.EdfaPgSaleOrder
import com.edfapay.payment_gateway.data.model.request.payer.EdfaPgPayer
import com.edfapay.payment_gateway.data.util.generateOperationHash
import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState
import org.jetbrains.compose.resources.getString
import kotlin.uuid.ExperimentalUuidApi

class EdfaCardPay {

    init {
        if (instance == null) {
            instance = this
        }
    }

    var isCalled = false
        private set

    var enableDebug: Boolean = false
        private set
    internal var enableDevDebug: Boolean = false
        private set

    var order: EdfaPgSaleOrder? = null
        private set

    var payer: EdfaPgPayer? = null
        private set

    var extras: List<Extra>? = null
        private set

    var card: EdfaPgCard? = null
        private set

    var designType: EdfaPayDesignType = EdfaPayDesignType.ONE
        private set

    var language: EdfaPayLanguage = EdfaPayLanguage.en
        private set

    var recurring: EdfaPgSaleOptions? = null
        private set

    var saleAuth = false
        private set

    var onTransactionFailure: ((String?) -> Unit)? = null
        private set

    var onTransactionSuccess: ((Any) -> Unit)? = null
        private set


    fun setOrder(order: EdfaPgSaleOrder): EdfaCardPay {
        this@EdfaCardPay.order = order
        return this
    }

    fun setPayer(payer: EdfaPgPayer): EdfaCardPay {
        this@EdfaCardPay.payer = payer
        return this
    }

    fun setExtras(extras: List<Extra>): EdfaCardPay {
        this@EdfaCardPay.extras = extras
        return this
    }

    fun setCard(card: EdfaPgCard?): EdfaCardPay {
        this@EdfaCardPay.card = card
        return this
    }

    fun setDebug(enable: Boolean): EdfaCardPay {
        this@EdfaCardPay.enableDebug = enable
        return this
    }

    fun setRecurring(channelId: String, recurring: Boolean): EdfaCardPay {
        this@EdfaCardPay.recurring = EdfaPgSaleOptions(channelId, recurring)
        return this
    }

    fun setAuth(auth: Boolean = true): EdfaCardPay {
        this@EdfaCardPay.saleAuth = auth
        return this
    }


    fun setDesignType(designType: EdfaPayDesignType): EdfaCardPay {
        this@EdfaCardPay.designType = designType
        return this
    }

    fun setLanguage(language: EdfaPayLanguage): EdfaCardPay {
        this@EdfaCardPay.language = language
        return this
    }

    fun onTransactionFailure(callback: (String?) -> Unit): EdfaCardPay {
        this@EdfaCardPay.onTransactionFailure = callback
        return this
    }

    fun onTransactionSuccess(callback: (Any) -> Unit): EdfaCardPay {
        this@EdfaCardPay.onTransactionSuccess = callback
        return this
    }

    fun isRecurring() = this@EdfaCardPay.recurring?.recurringInit ?: false

    fun isAuth() = this@EdfaCardPay.saleAuth

    internal fun setCalled(isCalled: Boolean): EdfaCardPay {
        this@EdfaCardPay.isCalled = isCalled
        return this
    }

    companion object {
        private var instance: EdfaCardPay? = null

        fun shared(): EdfaCardPay {
            return instance ?: EdfaCardPay().also { instance = it }
        }
    }


    @OptIn(ExperimentalUuidApi::class)
    suspend fun generateSaleRequest(cardData: CardBackState? = null): SaleRequestDto? {
        val order = order ?: return null
        val payer = payer ?: return null

        val cardNumber = card?.number ?: (cardData?.cardNumber ?: "")
        val cardExpiryMonth = validate(card?.expireMonth) ?: getMonthYear(cardData?.expiry ?: "").first
        val cardExpiryYear = card?.expireYear ?: getMonthYear(cardData?.expiry ?: "").second
        val cardCvv = card?.cvv ?: (cardData?.cvv ?: "")

        val missingToken = getString(Res.string.value_missing_token)
        val missingIdNumber = getString(Res.string.value_missing_id_number)
        val missingIdType = getString(Res.string.value_missing_id_type)
        val missingTaxNumber = getString(Res.string.value_missing_tax_number)
        val missingStateName = getString(Res.string.value_missing_state_name)

        val card = CardDto(
            initiateRequestId = order.id, // UUID string
            cardNumber = cardNumber,
            cardHolder = cardData?.holderName ?: "",
            cardExpiryMonth = cardExpiryMonth,
            cardExpiryYear = "$cardExpiryYear",
            cardScheme = "P1", // example "P1" from your curl
            cardCvv = cardCvv,
            token = missingToken
        )
        val customer = CustomerDto(
            name = payer.firstName + " " + payer.lastName,
            email = payer.email,
            phone = payer.phone,
            idNumber = missingIdNumber,
            idType = missingIdType,
            taxNumber = missingTaxNumber
        )
        val billingAddress = BillingAddressDto(
            country = payer.country,
            state = missingStateName,
            city = payer.city,
            address = payer.address,
            zip = payer.zip
        )
        val invoice = InvoiceDto(
            shippingCharges = 0.0, extraCharges = 0.0, extraDiscount = 0.0, total = 0.0, lineItems = emptyList()
        )
        val s = SaleRequestDto(
            orderId = order.id,
            amount = order.amount,
            currency = order.currency,
            paymentMethod = order.formattedCurrency(),
            auth = if (isAuth()) "Y" else "N",
            recurringInit = if (isRecurring()) "Y" else "N",
            customer = customer,
            billingAddress = billingAddress,
            invoice = invoice,
            successUrl = "https://edfapay.com/process-completed",
            failureUrl = "https://edfapay.com/process-failed",
            hash = generateOperationHash(
                EdfaPgCredential.getApiKey(), cardNumber, payer.email
            ),
            card = card
        )

        return s
    }

    private fun validate(expireMonth: Int?): String? {
        return if (expireMonth == null) null
        else {
            return if (expireMonth < 10) "0$expireMonth" else expireMonth.toString()
        }
    }

    private fun getMonthYear(date: String): Pair<String, String> {
        val month = date.take(2)
        val year = "20" + date.substring(2, 4)
        return month to year
    }
}