/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.app.core

import com.edfapay.payment_gateway.data.providers.TransactionProvider
import com.edfapay.payment_gateway.di.SdkContainer

/**
 *
 */

object EdfaPgSdk {

    /**
     * Initialize the [EdfaPgSdk] explicitly using the [EdfaPgCredential] values.
     *
     * @param context the app context.
     * @param apiKey the [EdfaPgCredential.API_KEY] value.
     * @param baseUrl the [EdfaPgCredential.PAYMENT_URL] value.
     * @throws EdfaPgSdkIsNotInitializedException
     */
    fun init(
        apiKey: String,
        baseUrl: String,
    ) {
        SdkContainer.init(apiKey, baseUrl)
        EdfaPgCredential.init(apiKey, baseUrl)
        EdfaPgCredential.requireInit()
    }

    fun transactionProvider(): TransactionProvider {
        return SdkContainer.get().transactionProvider()
    }
}
