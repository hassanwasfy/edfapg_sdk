/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.data.model.request.payer


/**
 * The [EdfaPgPayerOptions] values formatter.
 */
internal class EdfaPgPayerOptionsFormatter {

    /**
     * Format birthdate as yyyy-MM-dd (ISO-8601).
     */
    fun birthdateFormat(payerOptions: EdfaPgPayerOptions?): String? =
        payerOptions?.birthdate?.toString()
}

