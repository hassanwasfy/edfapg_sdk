package com.edfapay.payment_gateway.data.service

import com.edfapay.payment_gateway.data.model.*
import com.edfapay.payment_gateway.domain.model.TransactionFilter
import kotlinx.serialization.json.JsonObject

internal interface EdfaPayApiService {
    suspend fun sale(requestBody: SaleRequestDto): BaseResponse<SaleResponseDto>

    suspend fun void(requestBody: VoidRequestDto): BaseResponse<PaymentResultDto>
    suspend fun refund(requestBody: TransactionRequestDto): BaseResponse<RefundS2SResponse>
    suspend fun capture(requestBody: TransactionRequestDto): BaseResponse<PaymentResultDto>
    suspend fun getSale(transId: String): BaseResponse<TransactionContentDto>


    suspend fun filterTransaction(filter: TransactionFilter): BaseResponse<PageDto<TransactionContentDto>>
    suspend fun fetchExecuteHtml(url: String): String
    suspend fun executeSale(transactionId: String): String

    suspend fun recurring(recurringRequestBody: RecurringRequestBody): BaseResponse<PaymentResultDto>
}
