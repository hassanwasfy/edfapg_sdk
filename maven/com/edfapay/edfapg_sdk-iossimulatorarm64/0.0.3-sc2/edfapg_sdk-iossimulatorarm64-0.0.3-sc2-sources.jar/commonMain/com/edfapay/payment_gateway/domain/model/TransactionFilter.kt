package com.edfapay.payment_gateway.domain.model

data class TransactionFilter(
    val pageNumber: Int,
    val pageSize: Int,
    val rrn: String? = null,
    val status: String? = null
)
