package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class BillingAddressDto(
    @SerialName("country") val country: String,
    @SerialName("state") val state: String,
    @SerialName("city") val city: String,
    @SerialName("address") val address: String,
    @SerialName("zip") val zip: String
)