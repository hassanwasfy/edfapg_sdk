/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.data.model.request.card

import kotlinx.serialization.Serializable

/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 */
@Serializable
data class EdfaPgCard(
    val number: String,
    val expireMonth: Int,
    val expireYear: Int,
    val cvv: String,
)
