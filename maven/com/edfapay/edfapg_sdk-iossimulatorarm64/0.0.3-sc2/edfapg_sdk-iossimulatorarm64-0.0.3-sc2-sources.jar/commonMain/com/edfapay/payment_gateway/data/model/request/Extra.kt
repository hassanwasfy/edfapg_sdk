/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.data.model.request

import kotlinx.serialization.Serializable

/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 */
@Serializable
data class Extra(
    val type: String,
    val name: String,
    val value: String
)
