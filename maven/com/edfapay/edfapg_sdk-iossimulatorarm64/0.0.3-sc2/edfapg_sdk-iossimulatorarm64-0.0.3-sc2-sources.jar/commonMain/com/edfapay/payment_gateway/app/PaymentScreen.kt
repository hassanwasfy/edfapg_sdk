package com.edfapay.payment_gateway.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import com.edfapay.payment_gateway.presentation.payment.PaymentRoute
import com.edfapay.payment_gateway.presentation.webview.PaymentWebViewRoute
import com.edfapay.payment_gateway.presentation.webview.WebViewArgsStore
import com.edfapay.payment_gateway.utils.LocalAppDp
import com.edfapay.payment_gateway.utils.LocalAppSp
import com.edfapay.payment_gateway.utils.getDpDimens
import com.edfapay.payment_gateway.utils.getSpDimens

@Composable
internal fun PaymentScreen(
    openWebView: () -> Unit,
) {
    val dp = getDpDimens()
    val sp = getSpDimens()
    CompositionLocalProvider(LocalAppDp provides dp, LocalAppSp provides sp) {
        PaymentRoute(
            openWebView = {
                openWebView()
            }
        )
    }
}


@Composable
internal fun WebViewScreen(
    onClose: () -> Unit,
    onSuccess: () -> Unit,
    onFailure: () -> Unit,
) {
    val dp = getDpDimens()
    val sp = getSpDimens()
    CompositionLocalProvider(LocalAppDp provides dp, LocalAppSp provides sp) {
        PaymentWebViewRoute(
            onClose = {
                WebViewArgsStore.clear()
                onClose()
            },
            onSuccess = { finalUrl ->
                WebViewArgsStore.clear()
                onSuccess()
            },
            onFailure = { finalUrl ->
                WebViewArgsStore.clear()
                onFailure()
            }
        )
    }
}