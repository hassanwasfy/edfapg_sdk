package com.edfapay.payment_gateway.data.model


import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RecurringRequestBody(
    @SerialName("transactionId") val transactionId: String? = null,
    @SerialName("recurringToken") val recurringToken: String? = null,
    @SerialName("amount") val amount: Double? = null,
    @SerialName("order") val order: Order? = null
)