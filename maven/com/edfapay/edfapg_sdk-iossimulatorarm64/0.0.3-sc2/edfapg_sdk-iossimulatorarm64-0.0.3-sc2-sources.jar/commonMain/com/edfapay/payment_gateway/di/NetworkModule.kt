package com.edfapay.payment_gateway.di

import com.edfapay.payment_gateway.presentation.payment.models.EdfaCardPay
import com.edfapay.payment_gateway.utils.KMP_LEVEL
import com.edfapay.payment_gateway.utils.KmpLogger
import io.ktor.client.*
import io.ktor.client.plugins.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.logging.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
internal fun createHttpClient(apiKey: String): HttpClient =
    HttpClient {
        install(ContentNegotiation) {
            json(
                Json {
                    ignoreUnknownKeys = true
                    explicitNulls = false
                    isLenient = true
                }
            )
        }

        install(DefaultRequest) {
            header(HttpHeaders.Accept, "*/*")
            header(HttpHeaders.ContentType, "application/json")
            //header("authorization", token)
            header("X-API-KEY", apiKey)
        }

        install(HttpTimeout) {
            requestTimeoutMillis = 30_000
            connectTimeoutMillis = 15_000
            socketTimeoutMillis = 30_000
        }

        install(Logging) {
            logger = object : Logger {
                override fun log(message: String) {
                    val safe = message
                        .replace(
                            Regex("\"cardNumber\"\\s*:\\s*\"\\d+(\\d{4})\""),
                            "\"cardNumber\":\"****$1\""
                        )
                        .replace(
                            Regex("\"cardCvv\"\\s*:\\s*\"[^\"]+\""),
                            "\"cardCvv\":\"***\""
                        )

                    if (EdfaCardPay.shared().enableDevDebug) {
                        KmpLogger.log(KMP_LEVEL.WARN, message)
                    }

                    if (EdfaCardPay.shared().enableDebug) {
                        KmpLogger.log(KMP_LEVEL.DEBUG, safe)
                    }
                }
            }
            level = LogLevel.ALL
        }
        expectSuccess = false
    }
