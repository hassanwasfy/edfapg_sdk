package com.edfapay.payment_gateway.navigation

internal sealed class AppDestinations(val route: String) {
    data object Payment : AppDestinations("payment")
    data object WebView : AppDestinations("payment_webview")
}
