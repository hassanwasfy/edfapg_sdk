package com.edfapay.payment_gateway.app.toolbox

enum class EdfaPayDesignType {
    ONE,
    TWO,
    THREE
}