package com.edfapay.payment_gateway.app.toolbox

enum class EdfaPayLanguage(val value: String) {
    ar("ar"),
    en("en"),
}