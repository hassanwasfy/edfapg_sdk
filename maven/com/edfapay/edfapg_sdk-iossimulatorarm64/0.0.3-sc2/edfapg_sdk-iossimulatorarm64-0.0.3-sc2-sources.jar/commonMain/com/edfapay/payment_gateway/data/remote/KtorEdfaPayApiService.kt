package com.edfapay.payment_gateway.data.remote

import com.edfapay.payment_gateway.data.model.*
import com.edfapay.payment_gateway.data.service.EdfaPayApiService
import com.edfapay.payment_gateway.domain.model.TransactionFilter
import com.edfapay.payment_gateway.presentation.webview.Sha256
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import kotlinx.serialization.json.JsonObject
import kotlin.coroutines.cancellation.CancellationException

internal class KtorEdfaPayApiService(
    private val httpClient: HttpClient,
    private val baseUrl: String
) : EdfaPayApiService {

    val webLink = "$baseUrl/api/v1/payment-gateway/s2s"
    val signature = Sha256.hex("" + "9f3b8a7c6d2e4f8a9b1c3d5e7f8a0b2c")

    override suspend fun void(requestBody: VoidRequestDto): BaseResponse<PaymentResultDto> {
        return callApi {
            httpClient.post("$webLink/void") {
                setBody(requestBody)
            }.body()
        }
    }

    override suspend fun sale(requestBody: SaleRequestDto): BaseResponse<SaleResponseDto> {
        return callApi {
            httpClient.post("$webLink/sale") {
                setBody(requestBody)
            }.body()
        }
    }

    override suspend fun refund(requestBody: TransactionRequestDto): BaseResponse<RefundS2SResponse> {
        return callApi {
            httpClient.post("$webLink/refund") {
                setBody(requestBody)
            }.body()
        }
    }

    override suspend fun capture(requestBody: TransactionRequestDto): BaseResponse<PaymentResultDto> {
        return callApi {
            httpClient.post("$webLink/capture") {
                setBody(requestBody)
            }.body()
        }
    }

    override suspend fun getSale(transId: String): BaseResponse<TransactionContentDto> {
        return callApi {
            httpClient.get("$webLink/sale/$transId").body()
        }
    }

    override suspend fun filterTransaction(filter: TransactionFilter): BaseResponse<PageDto<TransactionContentDto>> {
        return callApi {
            httpClient.get("$baseUrl/api/v1/transactions/filterTransaction") {
                url {
                    parameters.append("pageNumber", filter.pageNumber.toString())
                    parameters.append("pageSize", filter.pageSize.toString())
                    parameters.append("rrn", filter.rrn.orEmpty())
                    parameters.append("status", filter.status.orEmpty())
                }
            }.body()
        }
    }

    override suspend fun fetchExecuteHtml(url: String): String {
        val res =  callApi<BaseResponse<ExecuteData>> {
            httpClient.get(url) {
                url {
                    header("X-Signature", signature)
                }
            }.body()
        }
        return res.data?.htmlContent ?: ""
    }

    override suspend fun executeSale(transactionId: String): String {
        val res =  callApi<BaseResponse<ExecuteData>> {
            httpClient.get("${webLink}/sale/$transactionId") {
                url {
                    header("X-Signature", signature)
                }
            }.body()
        }
        return res.data?.htmlContent ?: ""
    }

    override suspend fun recurring(recurringRequestBody: RecurringRequestBody): BaseResponse<PaymentResultDto> {
        return callApi<BaseResponse<PaymentResultDto>> {
            httpClient.get("${baseUrl}/api/v2/payment-gateway/recurring").body()
        }
    }

    private suspend inline fun <reified T> callApi(
        crossinline block: suspend () -> HttpResponse
    ): T {
        try {
            val response = block()
            val status = response.status.value

            if (response.status.isSuccess()) {
                return response.body()
            }

            val errorBody = runCatching { response.bodyAsText() }.getOrNull()
            throw ApiException(
                code = status,
                errorBody = errorBody,
                message = "HTTP $status error"
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            throw e
        } catch (e: Exception) {
            throw ApiException(
                message = "Network / client error: ${e.message}",
                cause = e
            )
        }
    }
}
