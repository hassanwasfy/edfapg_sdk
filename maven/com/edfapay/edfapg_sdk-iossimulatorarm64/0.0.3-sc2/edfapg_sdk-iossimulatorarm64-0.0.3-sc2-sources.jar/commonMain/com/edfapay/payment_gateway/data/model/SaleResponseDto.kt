package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class SaleResponseDto(
    @SerialName("acquirerPaymentId") val acquirerPaymentId: String,
    @SerialName("paymentId") val paymentId: String,
    @SerialName("redirectUrl") val redirectUrl: String,
    @SerialName("result") val result: String,
    @SerialName("status") val status: String
)
