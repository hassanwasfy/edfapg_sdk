package com.edfapay.payment_gateway.data.model


import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TransactionContentDto(
    @SerialName("transactionId") val transactionId: String? = null,
    @SerialName("orderId") val orderId: String? = null,
    @SerialName("amount") val amount: String? = null,
    @SerialName("currencyCode") val currencyCode: String? = null,
    @SerialName("transactionStatus") val transactionStatus: String? = null,
    @SerialName("paymentStatus") val paymentStatus: String? = null,
    @SerialName("businessUnitId") val businessUnitId: String? = null,
    @SerialName("channel") val channel: String? = null,
    @SerialName("rrn") val rrn: String? = null,
    @SerialName("transactionType") val transactionType: String? = null,
    @SerialName("reconciliationStatus") val reconciliationStatus: String? = null,
    @SerialName("reconciliationAt") val reconciliationAt: String? = null,
    @SerialName("acquirerBank") val acquirerBank: String? = null,
    @SerialName("providerTid") val providerTid: String? = null,
    @SerialName("holderAccount") val holderAccount: String? = null,
    @SerialName("cardScheme") val cardScheme: String? = null,
    @SerialName("cardChannel") val cardChannel: String? = null,
    @SerialName("cardSequenceNumber") val cardSequenceNumber: String? = null,
    @SerialName("pan") val pan: String? = null,
    @SerialName("cardExpiration") val cardExpiration: String? = null,
    @SerialName("cardHolderName") val cardHolderName: String? = null,
    @SerialName("createdAt") val createdAt: String? = null,
    @SerialName("finishedAt") val finishedAt: String? = null,
    @SerialName("createdBy") val createdBy: String? = null,
    @SerialName("createdByName") val createdByName: String? = null,
    @SerialName("totalRefundAmount") val totalRefundAmount: String? = null,
    @SerialName("refundStatus") val refundStatus: String? = null,
    @SerialName("merchantId") val merchantId: String? = null,
    @SerialName("recurringToken") val recurringToken: String? = null,
)
