package com.edfapay.payment_gateway.data.providers

import com.edfapay.payment_gateway.data.mapper.errorMessage
import com.edfapay.payment_gateway.data.mapper.toJson
import com.edfapay.payment_gateway.data.model.PageDto
import com.edfapay.payment_gateway.data.model.RecurringRequestBody
import com.edfapay.payment_gateway.data.model.SaleRequestDto
import com.edfapay.payment_gateway.data.model.TransactionRequestDto
import com.edfapay.payment_gateway.data.model.VoidRequestDto
import com.edfapay.payment_gateway.data.service.EdfaPayApiService
import com.edfapay.payment_gateway.domain.model.TransactionFilter
import com.edfapay.payment_gateway.presentation.webview.WebViewArgsStore
import kotlinx.serialization.json.JsonObject

internal class ProvidersImpl(
    private val api: EdfaPayApiService
) : TransactionProvider {

    override suspend fun fetchAll(
        pageNumber: Int,
        pageSize: Int,
        rrn: String?,
        status: String?
    ): PageDto<JsonObject>? {
        val filter = TransactionFilter(pageNumber = pageNumber, pageSize = pageSize, status = status)
        val result = api.filterTransaction(filter)
        return result.data?.toJson()
    }

    override suspend fun void(transactionId: String): JsonObject {
        return api.void(VoidRequestDto(transactionId)).toJson { it.toJson() }
    }

    override suspend fun capture(transactionId: String, amount: Double): JsonObject {
        return api.capture(TransactionRequestDto(amount, transactionId)).toJson { it.toJson() }
    }

    override suspend fun refund(transactionId: String, amount: Double): JsonObject {
        return api.refund(TransactionRequestDto(amount, transactionId)).toJson { it.toJson() }
    }

    override suspend fun sale(request: SaleRequestDto): JsonObject {
        val result = api.sale(request)
        return if (result.data != null) {
            val html = fetchRedirectHtml(result.data.redirectUrl)
            html?.let {
                WebViewArgsStore.set(html)
            }
            result.data.toJson()
        } else {
            errorMessage("${result.errorCode}", "${result.message}")
        }
    }

    override suspend fun fetchRedirectHtml(redirectUrl: String): String? {
        if (redirectUrl.isBlank()) return null
        return api.fetchExecuteHtml(redirectUrl).ifBlank { null }
    }

    override suspend fun getSaleDetails(transactionId: String): JsonObject {
        if (transactionId.isBlank()) return errorMessage("400", "Transaction id can not be blank")
        return api.getSale(transactionId).toJson { it.toJson() }
    }

    override suspend fun executeSale(transactionId: String): String {
        val result =  api.executeSale(transactionId)
        WebViewArgsStore.set(result)
        return result
    }

    override suspend fun recurring(recurringRequestBody: RecurringRequestBody): JsonObject {
        val result = api.recurring(recurringRequestBody)
        return result.data?.toJson() ?:
        errorMessage("${result.errorCode}", "${result.message}")
    }
}

//{
//    "code": 400,
//    "message": "Invalid request body",
//    "description": "The request body has multiple errors",
//    "errors": [
//    {
//        "code": "00001",
//        "message": "Invalid Payment Hash",
//        "description": "hash: should be valid hash genertaed with specific algo."
//    },
//    {
//        "code": "00002",
//        "message": "Invalid Payment Scheme",
//        "description": "cardScheme: should be one from [P1, MC, AX, DM, UP, VC, VD, DC, GN, JC, GV]"
//    },
//    {
//        "code": "00003",
//        "message": "Invalid or Missing Card Number",
//        "description": "cardNumber: should be 16 or 14 digits."
//    },
//    {
//        "code": "00004",
//        "message": "Invalid Card Expiry",
//        "description": "cardExpiryMonth/cardExpiryYear: Expiry date should valid future date"
//    },
//    {
//        "code": "00005",
//        "message": "Invalid CVV",
//        "description": "cardCvv: should not less then 3 and grerater then 4"
//    },
//    {
//        "code": "00006",
//        "message": "Invlaid Amount",
//        "description": "amount: should be greater then 0.1"
//    }
//    ],
//    "errorCode": "400",
//    "data": null
//}