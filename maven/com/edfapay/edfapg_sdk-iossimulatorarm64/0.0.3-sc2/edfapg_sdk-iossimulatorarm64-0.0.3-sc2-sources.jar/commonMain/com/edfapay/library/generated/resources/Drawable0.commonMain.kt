@file:OptIn(InternalResourceApi::class)

package com.edfapay.library.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DensityQualifier
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.edfapay.library.generated.resources/"

internal val Res.drawable.back_side: DrawableResource by lazy {
      DrawableResource("drawable:back_side", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/back_side.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/back_side.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/back_side.png", -1, -1),
      ))
    }

internal val Res.drawable.cart: DrawableResource by lazy {
      DrawableResource("drawable:cart", setOf(
        ResourceItem(setOf(), "${MD}drawable/cart.png", -1, -1),
      ))
    }

internal val Res.drawable.debit: DrawableResource by lazy {
      DrawableResource("drawable:debit", setOf(
        ResourceItem(setOf(), "${MD}drawable/debit.png", -1, -1),
      ))
    }

internal val Res.drawable.dollar: DrawableResource by lazy {
      DrawableResource("drawable:dollar", setOf(
        ResourceItem(setOf(), "${MD}drawable/dollar.png", -1, -1),
      ))
    }

internal val Res.drawable.frame_card: DrawableResource by lazy {
      DrawableResource("drawable:frame_card", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/frame_card.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/frame_card.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/frame_card.png", -1, -1),
      ))
    }

internal val Res.drawable.frame_card_holder: DrawableResource by lazy {
      DrawableResource("drawable:frame_card_holder", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/frame_card_holder.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/frame_card_holder.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/frame_card_holder.png", -1, -1),
      ))
    }

internal val Res.drawable.ic_launcher_background: DrawableResource by lazy {
      DrawableResource("drawable:ic_launcher_background", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_launcher_background.xml", -1, -1),
      ))
    }

internal val Res.drawable.ic_launcher_foreground: DrawableResource by lazy {
      DrawableResource("drawable:ic_launcher_foreground", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_launcher_foreground.xml", -1, -1),
      ))
    }

internal val Res.drawable.icon_amex: DrawableResource by lazy {
      DrawableResource("drawable:icon_amex", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/icon_amex.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/icon_amex.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/icon_amex.png", -1, -1),
      ))
    }

internal val Res.drawable.icon_clear: DrawableResource by lazy {
      DrawableResource("drawable:icon_clear", setOf(
        ResourceItem(setOf(DensityQualifier.HDPI, ), "${MD}drawable-hdpi/icon_clear.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.LDPI, ), "${MD}drawable-ldpi/icon_clear.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.MDPI, ), "${MD}drawable-mdpi/icon_clear.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/icon_clear.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/icon_clear.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/icon_clear.png", -1, -1),
      ))
    }

internal val Res.drawable.icon_mada: DrawableResource by lazy {
      DrawableResource("drawable:icon_mada", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/icon_mada.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/icon_mada.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/icon_mada.png", -1, -1),
      ))
    }

internal val Res.drawable.icon_master_card: DrawableResource by lazy {
      DrawableResource("drawable:icon_master_card", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/icon_master_card.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/icon_master_card.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/icon_master_card.png", -1, -1),
      ))
    }

internal val Res.drawable.icon_pci: DrawableResource by lazy {
      DrawableResource("drawable:icon_pci", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/icon_pci.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/icon_pci.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/icon_pci.png", -1, -1),
      ))
    }

internal val Res.drawable.icon_powered_by: DrawableResource by lazy {
      DrawableResource("drawable:icon_powered_by", setOf(
        ResourceItem(setOf(), "${MD}drawable/icon_powered_by.xml", -1, -1),
      ))
    }

internal val Res.drawable.icon_scheme: DrawableResource by lazy {
      DrawableResource("drawable:icon_scheme", setOf(
        ResourceItem(setOf(), "${MD}drawable/icon_scheme.png", -1, -1),
      ))
    }

internal val Res.drawable.icon_visa: DrawableResource by lazy {
      DrawableResource("drawable:icon_visa", setOf(
        ResourceItem(setOf(DensityQualifier.XHDPI, ), "${MD}drawable-xhdpi/icon_visa.png", -1, -1),
        ResourceItem(setOf(DensityQualifier.XXHDPI, ), "${MD}drawable-xxhdpi/icon_visa.png", -1, -1),
        ResourceItem(setOf(), "${MD}drawable/icon_visa.png", -1, -1),
      ))
    }

internal val Res.drawable.image_card_png: DrawableResource by lazy {
      DrawableResource("drawable:image_card_png", setOf(
        ResourceItem(setOf(), "${MD}drawable/image_card_png.png", -1, -1),
      ))
    }

internal val Res.drawable.image_card_visa: DrawableResource by lazy {
      DrawableResource("drawable:image_card_visa", setOf(
        ResourceItem(setOf(), "${MD}drawable/image_card_visa.xml", -1, -1),
      ))
    }

internal val Res.drawable.image_visa_card: DrawableResource by lazy {
      DrawableResource("drawable:image_visa_card", setOf(
        ResourceItem(setOf(), "${MD}drawable/image_visa_card.xml", -1, -1),
      ))
    }

internal val Res.drawable.no: DrawableResource by lazy {
      DrawableResource("drawable:no", setOf(
        ResourceItem(setOf(), "${MD}drawable/no.png", -1, -1),
      ))
    }

internal val Res.drawable.padlock: DrawableResource by lazy {
      DrawableResource("drawable:padlock", setOf(
        ResourceItem(setOf(), "${MD}drawable/padlock.png", -1, -1),
      ))
    }

internal val Res.drawable.refresh: DrawableResource by lazy {
      DrawableResource("drawable:refresh", setOf(
        ResourceItem(setOf(), "${MD}drawable/refresh.png", -1, -1),
      ))
    }

internal val Res.drawable.refund: DrawableResource by lazy {
      DrawableResource("drawable:refund", setOf(
        ResourceItem(setOf(), "${MD}drawable/refund.png", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("back_side", Res.drawable.back_side)
  map.put("cart", Res.drawable.cart)
  map.put("debit", Res.drawable.debit)
  map.put("dollar", Res.drawable.dollar)
  map.put("frame_card", Res.drawable.frame_card)
  map.put("frame_card_holder", Res.drawable.frame_card_holder)
  map.put("ic_launcher_background", Res.drawable.ic_launcher_background)
  map.put("ic_launcher_foreground", Res.drawable.ic_launcher_foreground)
  map.put("icon_amex", Res.drawable.icon_amex)
  map.put("icon_clear", Res.drawable.icon_clear)
  map.put("icon_mada", Res.drawable.icon_mada)
  map.put("icon_master_card", Res.drawable.icon_master_card)
  map.put("icon_pci", Res.drawable.icon_pci)
  map.put("icon_powered_by", Res.drawable.icon_powered_by)
  map.put("icon_scheme", Res.drawable.icon_scheme)
  map.put("icon_visa", Res.drawable.icon_visa)
  map.put("image_card_png", Res.drawable.image_card_png)
  map.put("image_card_visa", Res.drawable.image_card_visa)
  map.put("image_visa_card", Res.drawable.image_visa_card)
  map.put("no", Res.drawable.no)
  map.put("padlock", Res.drawable.padlock)
  map.put("refresh", Res.drawable.refresh)
  map.put("refund", Res.drawable.refund)
}
