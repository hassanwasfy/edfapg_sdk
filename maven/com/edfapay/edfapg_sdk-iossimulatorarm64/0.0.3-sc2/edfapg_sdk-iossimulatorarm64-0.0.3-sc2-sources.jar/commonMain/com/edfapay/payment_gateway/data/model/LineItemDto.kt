package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class LineItemDto(
    @SerialName("sku") val sku: String,
    @SerialName("description") val description: String,
    @SerialName("url") val url: String,
    @SerialName("unitCost") val unitCost: Double,
    @SerialName("quantity") val quantity: Int,
    @SerialName("netTotal") val netTotal: Double,
    @SerialName("discountRate") val discountRate: Double,
    @SerialName("discountAmount") val discountAmount: Double,
    @SerialName("taxRate") val taxRate: Double,
    @SerialName("taxTotal") val taxTotal: Double,
    @SerialName("total") val total: Double
)