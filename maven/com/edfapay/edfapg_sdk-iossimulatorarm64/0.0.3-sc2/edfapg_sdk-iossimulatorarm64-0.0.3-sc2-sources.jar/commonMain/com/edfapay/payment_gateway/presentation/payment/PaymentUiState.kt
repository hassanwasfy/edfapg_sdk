package com.edfapay.payment_gateway.presentation.payment

import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState

internal data class PaymentUiState(
    val isLoading: Boolean = false,
    val cardData: CardBackState = CardBackState(),
)
