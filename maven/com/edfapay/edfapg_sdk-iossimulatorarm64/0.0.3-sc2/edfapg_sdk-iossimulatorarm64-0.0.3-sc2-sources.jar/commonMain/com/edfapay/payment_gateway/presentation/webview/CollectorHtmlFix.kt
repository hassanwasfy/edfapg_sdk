package com.edfapay.payment_gateway.presentation.webview

internal object CollectorHtmlFix {

    fun sanitize(html: String): String {
        if (html.isBlank()) return html

        // 1) Remove external CSS link that Android refuses (bad/empty MIME type)
        val noCss = html.replace(
            Regex("""<link\s+rel=["']stylesheet["'][^>]*>""", RegexOption.IGNORE_CASE),
            ""
        )

        // 2) Optional: add tiny inline CSS so spinner/layout doesn't look broken
        val inlineCss = """
            <style>
              body { margin:0; font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Arial,sans-serif; }
              .center { height:100vh; display:flex; justify-content:center; align-items:center; }
              .spinner { width:64px; height:64px; border:6px solid rgba(0,0,0,.15); border-top-color: rgba(0,0,0,.65); border-radius:50%; animation: spin 1s linear infinite; }
              @keyframes spin { to { transform: rotate(360deg); } }
            </style>
        """.trimIndent()

        // Replace bootstrap-based spinner block with our own minimal markup (safe)
        val simplified = noCss.replace(
            Regex("""(?s)<div class="d-flex[^>]*>.*?</div>\s*<div id="logBodyContent"></div>"""),
            """<div class="center"><div class="spinner"></div></div><div id="logBodyContent"></div>"""
        )

        // Inject inline CSS right before </head>
        return if (simplified.contains("</head>", ignoreCase = true)) {
            simplified.replace("</head>", "$inlineCss\n</head>", ignoreCase = true)
        } else {
            inlineCss + "\n" + simplified
        }
    }
}
