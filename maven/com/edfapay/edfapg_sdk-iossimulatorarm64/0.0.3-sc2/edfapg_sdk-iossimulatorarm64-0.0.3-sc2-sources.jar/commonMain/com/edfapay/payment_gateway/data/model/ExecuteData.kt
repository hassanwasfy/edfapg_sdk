package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.Serializable

@Serializable
data class ExecuteData(
    val htmlContent: String? = null,
    val transactionId: String? = null,
    val orderId: String? = null,
    val transactionStatus: String? = null,
    val paymentStatus: String? = null,
    val message: String? = null
)
