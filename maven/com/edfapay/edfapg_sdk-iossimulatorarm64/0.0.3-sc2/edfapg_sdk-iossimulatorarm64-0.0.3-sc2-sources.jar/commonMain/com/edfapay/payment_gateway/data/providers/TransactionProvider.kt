package com.edfapay.payment_gateway.data.providers

import com.edfapay.payment_gateway.data.model.BaseResponse
import com.edfapay.payment_gateway.data.model.PageDto
import com.edfapay.payment_gateway.data.model.PaymentResultDto
import com.edfapay.payment_gateway.data.model.RecurringRequestBody
import com.edfapay.payment_gateway.data.model.SaleRequestDto
import kotlinx.serialization.json.JsonObject

interface TransactionProvider {

    /**
     * Fetches a paginated list of transactions from the payment backend.
     *
     * This method performs a network request and returns a page of raw
     * transaction data mapped to JSON objects. The SDK does not apply
     * any presentation logic, sorting, or filtering beyond the parameters
     * explicitly provided.
     *
     * The host application is responsible for:
     * - Triggering this call (e.g. via a button or user action)
     * - Handling loading and error states
     * - Mapping the returned JSON objects to UI or domain models
     * - Managing pagination and refresh behavior
     *
     * @param pageNumber
     * The page index to fetch (0-based).
     *
     * @param pageSize
     * The maximum number of transactions to return in a single page.
     *
     * @param rrn
     * Optional Retrieval Reference Number filter.
     * When provided, only transactions matching the given RRN are returned.
     * If `null`, no RRN-based filtering is applied.
     *
     * @param status
     * Optional transaction status filter (e.g. SUCCESS, FAILED, APPROVED).
     * The accepted values are backend-defined.
     * If `null`, no status-based filtering is applied.
     *
     * @return
     * A [PageDto] containing:
     * - A list of transactions as [JsonObject]
     * - Pagination metadata (page number, total pages, etc.)
     *
     * Returns `null` if the request fails or the backend returns no data.
     * Host applications should treat a `null` result as a failure case
     * and handle it accordingly.
     *
     */
    suspend fun fetchAll(
        pageNumber: Int = 0,
        pageSize: Int = 50,
        rrn: String? = null,
        status: String? = null
    ): PageDto<JsonObject>?

    suspend fun void(transactionId: String): JsonObject
    suspend fun capture(transactionId: String, amount: Double): JsonObject
    suspend fun refund(transactionId: String, amount: Double): JsonObject
    suspend fun sale(request: SaleRequestDto): JsonObject
    suspend fun fetchRedirectHtml(redirectUrl: String): String?
    suspend fun getSaleDetails(transactionId: String): JsonObject
    suspend fun executeSale(transactionId: String): String

    suspend fun recurring(recurringRequestBody: RecurringRequestBody): JsonObject
}
