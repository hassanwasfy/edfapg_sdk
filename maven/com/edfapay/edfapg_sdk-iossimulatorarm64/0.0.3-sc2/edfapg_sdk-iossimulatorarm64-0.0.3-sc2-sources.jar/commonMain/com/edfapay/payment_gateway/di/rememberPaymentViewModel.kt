package com.edfapay.payment_gateway.di

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.edfapay.payment_gateway.presentation.payment.PaymentViewModel

@Composable
internal fun rememberPaymentViewModel(): PaymentViewModel {
    val container = remember { SdkContainer.get() }
    return remember { container.paymentViewModel() }
}
