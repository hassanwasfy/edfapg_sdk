package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CardDto(
    @SerialName("initiateRequestId") val initiateRequestId: String,
    @SerialName("cardNumber") val cardNumber: String,
    @SerialName("cardHolder") val cardHolder: String,
    @SerialName("cardExpiryMonth") val cardExpiryMonth: String,
    @SerialName("cardExpiryYear") val cardExpiryYear: String,
    @SerialName("cardScheme") val cardScheme: String,
    @SerialName("cardCvv") val cardCvv: String,
    @SerialName("token") val token: String
)