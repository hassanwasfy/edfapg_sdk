package com.edfapay.payment_gateway.presentation.payment.utils

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

internal class CardNumberVisualTransformation(
    private val groupSize: Int = 4,
    private val separator: Char = ' '
) : VisualTransformation {

    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text

        val transformed = buildString {
            raw.forEachIndexed { index, c ->
                append(c)
                val isGroupEnd = (index + 1) % groupSize == 0
                val isNotLast = index != raw.lastIndex
                if (isGroupEnd && isNotLast) append(separator)
            }
        }

        val mapping = object : OffsetMapping {

            override fun originalToTransformed(offset: Int): Int {
                val groupsBefore = (offset / groupSize)
                val separatorsBefore = if (offset == 0) 0 else groupsBefore
                return (offset + separatorsBefore).coerceAtMost(transformed.length)
            }

            override fun transformedToOriginal(offset: Int): Int {
                // count separators actually present before this transformed offset
                val separatorsBefore = transformed.take(offset).count { it == separator }
                return (offset - separatorsBefore).coerceIn(0, raw.length)
            }
        }

        return TransformedText(AnnotatedString(transformed), mapping)
    }
}

internal class ExpiryVisualTransformation(
    private val separator: Char = '/'
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text.take(4) // MMYY

        val transformed = when {
            raw.length <= 2 -> raw
            else -> clampMonth(raw.take(2)) + separator + raw.substring(2)
        }

        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                // slash appears after 2 digits
                val add = if (offset > 2) 1 else 0
                return (offset + add).coerceAtMost(transformed.length)
            }

            override fun transformedToOriginal(offset: Int): Int {
                // if cursor is past the slash, subtract it
                val sub = if (offset > 2) 1 else 0
                return (offset - sub).coerceIn(0, raw.length)
            }
        }

        return TransformedText(AnnotatedString(transformed), mapping)
    }
}

