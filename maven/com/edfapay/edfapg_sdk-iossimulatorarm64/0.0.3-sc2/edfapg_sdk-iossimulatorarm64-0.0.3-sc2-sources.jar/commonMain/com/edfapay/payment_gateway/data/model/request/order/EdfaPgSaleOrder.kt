/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.data.model.request.order

import com.edfapay.payment_gateway.app.toolbox.CurrencyMeta
import com.edfapay.payment_gateway.app.toolbox.EdfaPgValidation
import kotlinx.serialization.Serializable
import kotlin.math.round

/**
 *
 * @property currency the currency. 3-letter code.
 */

@Serializable
data class EdfaPgSaleOrder(
    val id: String,
    val amount: Double,
    val currency: String,
    val description: String,
) {

    fun formattedAmount(): String {
        val code = currency.trim().uppercaseAscii()
        val digits = CurrencyMeta.defaultFractionDigits(code)
        return formatFixed(amount, digits)
    }

    fun formattedCurrency(): String =
        currency.trim().uppercaseAscii()

    fun validate(): List<String> {
        val errors = mutableListOf<String>()

        if (id.isBlank()) errors.add("id is empty")

        if (amount < EdfaPgValidation.Amount.VALUE_MIN) {
            errors.add("amount must be >= ${EdfaPgValidation.Amount.VALUE_MIN}")
        }

        val code = currency.trim().uppercaseAscii()
        if (code.length != 3) {
            errors.add("currency is invalid (must be a 3-character currency code)")
        } else if (!CurrencyMeta.isKnown(code)) {
            errors.add("currency code is not recognized")
        }

        if (description.isBlank()) errors.add("description is empty")
        return errors
    }
}

private fun String.uppercaseAscii(): String = buildString(length) {
    for (ch in this@uppercaseAscii) {
        append(if (ch in 'a'..'z') (ch.code - 32).toChar() else ch)
    }
}

private fun formatFixed(value: Double, fractionDigits: Int): String {
    require(fractionDigits >= 0)

    val factor = pow10(fractionDigits)
    val rounded = round(value * factor) / factor

    val s = rounded.toString()
    val parts = s.split('.', limit = 2)
    val intPart = parts[0]
    val frac = if (parts.size == 2) parts[1] else ""

    val normalized =
        if (fractionDigits == 0) "" else frac.padEnd(fractionDigits, '0').take(fractionDigits)
    return if (fractionDigits == 0) intPart else "$intPart.$normalized"
}

private fun pow10(exp: Int): Double {
    var r = 1.0
    repeat(exp) { r *= 10.0 }
    return r
}
