package com.edfapay.payment_gateway.domain.model

internal enum class PaymentResultCode {
    SUCCESS,
    FAILURE,
    REDIRECT,
    PENDING,
    UNKNOWN
}