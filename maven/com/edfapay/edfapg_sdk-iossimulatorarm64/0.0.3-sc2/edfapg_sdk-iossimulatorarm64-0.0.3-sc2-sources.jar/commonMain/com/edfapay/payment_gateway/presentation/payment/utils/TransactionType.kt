package com.edfapay.payment_gateway.presentation.payment.utils

object TransactionType {
    const val REFUND = "REFUND"
    const val AUTHORIZATION = "AUTHORIZATION"
    const val PURCHASE = "PURCHASE"
    const val CAPTURE = "CAPTURE"
    const val VOID = "VOID"
    const val REVERSE = "REVERSE"
    const val EXTENSION = "EXTENSION"
}

object RefundStatus {
    const val FULL = "FULL"
    const val NONE = "NONE"
    const val PARTIAL = "PARTIAL"
}