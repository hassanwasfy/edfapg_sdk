@file:OptIn(InternalResourceApi::class)

package com.edfapay.library.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.FontResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.edfapay.library.generated.resources/"

internal val Res.font.poppins: FontResource by lazy {
      FontResource("font:poppins", setOf(
        ResourceItem(setOf(), "${MD}font/poppins.ttf", -1, -1),
      ))
    }

internal val Res.font.poppins_bold: FontResource by lazy {
      FontResource("font:poppins_bold", setOf(
        ResourceItem(setOf(), "${MD}font/poppins_bold.ttf", -1, -1),
      ))
    }

internal val Res.font.poppins_light: FontResource by lazy {
      FontResource("font:poppins_light", setOf(
        ResourceItem(setOf(), "${MD}font/poppins_light.ttf", -1, -1),
      ))
    }

internal val Res.font.poppins_medium: FontResource by lazy {
      FontResource("font:poppins_medium", setOf(
        ResourceItem(setOf(), "${MD}font/poppins_medium.ttf", -1, -1),
      ))
    }

internal val Res.font.poppins_semibold: FontResource by lazy {
      FontResource("font:poppins_semibold", setOf(
        ResourceItem(setOf(), "${MD}font/poppins_semibold.ttf", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainFont0Resources(map: MutableMap<String, FontResource>) {
  map.put("poppins", Res.font.poppins)
  map.put("poppins_bold", Res.font.poppins_bold)
  map.put("poppins_light", Res.font.poppins_light)
  map.put("poppins_medium", Res.font.poppins_medium)
  map.put("poppins_semibold", Res.font.poppins_semibold)
}
