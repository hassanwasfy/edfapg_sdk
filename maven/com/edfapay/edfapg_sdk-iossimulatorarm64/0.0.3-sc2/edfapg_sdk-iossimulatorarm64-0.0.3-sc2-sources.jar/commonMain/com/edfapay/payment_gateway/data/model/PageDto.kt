package com.edfapay.payment_gateway.data.model


import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PageDto<T>(
    @SerialName("content") val content: List<T> = emptyList(),
    @SerialName("number") val number: Int = 0,
    @SerialName("size") val size: Int = 0,
    @SerialName("totalElements") val totalElements: Long = 0,
    @SerialName("numberOfElements") val numberOfElements: Int = 0,
    @SerialName("totalPages") val totalPages: Int = 0,
    @SerialName("hasContent") val hasContent: Boolean = false,
    @SerialName("first") val first: Boolean = false,
    @SerialName("last") val last: Boolean = false
)
