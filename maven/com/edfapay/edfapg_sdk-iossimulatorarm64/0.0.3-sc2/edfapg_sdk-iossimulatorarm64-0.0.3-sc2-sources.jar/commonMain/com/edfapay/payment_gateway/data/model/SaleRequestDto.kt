package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class SaleRequestDto(
    @SerialName("orderId") val orderId: String,
    @SerialName("amount") val amount: Double,
    @SerialName("currency") val currency: String,
    @SerialName("paymentMethod") val paymentMethod: String,
    @SerialName("auth") val auth: String,
    @SerialName("recurringInit") val recurringInit: String,
    @SerialName("customer") val customer: CustomerDto,
    @SerialName("billingAddress") val billingAddress: BillingAddressDto,
    @SerialName("invoice") val invoice: InvoiceDto,
    @SerialName("successUrl") val successUrl: String,
    @SerialName("failureUrl") val failureUrl: String,
    @SerialName("hash") val hash: String,
    @SerialName("card") val card: CardDto
)