package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class InvoiceDto(
    @SerialName("shippingCharges") val shippingCharges: Double,
    @SerialName("extraCharges") val extraCharges: Double,
    @SerialName("extraDiscount") val extraDiscount: Double,
    @SerialName("total") val total: Double,
    @SerialName("lineItems") val lineItems: List<LineItemDto>
)