package com.edfapay.payment_gateway.data.util

import okio.ByteString.Companion.encodeUtf8

internal fun generateOperationHash(
    secretKey: String,
    cardNumber: String,
    email: String
): String {
    val cleanCard = cardNumber.replace("\\s+".toRegex(), "")
    val cleanEmail = email.trim()

    require(cleanCard.length >= 10) { "Card number must be at least 10 digits" }

    val cardPart = cleanCard.take(6) + cleanCard.takeLast(4)

    val combined = cleanEmail.reversed() + secretKey + cardPart.reversed()
    val combinedUpper = uppercaseAscii(combined)

    return combinedUpper.encodeUtf8().md5().hex()
}


private fun uppercaseAscii(s: String): String =
    buildString(s.length) {
        for (c in s) {
            append(
                if (c in 'a'..'z') (c.code - 32).toChar() else c
            )
        }
    }
