package com.edfapay.payment_gateway.presentation.payment

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.edfapay.payment_gateway.di.rememberPaymentViewModel
import com.edfapay.payment_gateway.presentation.payment.designs.HolderScreen
import com.edfapay.payment_gateway.presentation.payment.models.EdfaCardPay
import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState

@Composable
internal fun PaymentRoute(
    openWebView: () -> Unit,
) {

    val viewModel = rememberPaymentViewModel()
    val state = viewModel.uiState.collectAsStateWithLifecycle()

    PaymentScreen(
        state.value,
        onStateChange = viewModel::onStateChange,
        executeSale = {
            viewModel.executeModernSale {
                openWebView()
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PaymentScreen(
    data: PaymentUiState,
    onStateChange: (CardBackState) -> Unit,
    executeSale: () -> Unit,
) {
    val state = data.cardData
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        HolderScreen(
            screenCode = EdfaCardPay.shared().designType,
            cardState = state,
            executeSale
        ) {
            onStateChange(it)
        }
    }
}
