package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResultDto(
    @SerialName("result") val result: String? = null,
    @SerialName("action") val action: String? = null,
    @SerialName("order_id") val orderId: String? = null,
    @SerialName("trans_id") val transId: String? = null,
    @SerialName("rrn") val rrn: String? = null,
    @SerialName("card_brand") val cardBrand: String? = null,
    @SerialName("merchant_name") val merchantName: String? = null,
    @SerialName("decline_reason") val declineReason: String? = null,
)