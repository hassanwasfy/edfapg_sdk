package com.edfapay.payment_gateway.presentation.payment.utils

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal object Dimens {
    val normal = DpDimens(
        dp4 = 4.dp,
        dp8 = 8.dp,
        dp10 = 10.dp,
        dp12 = 12.dp,
        dp14 = 14.dp,
        dp16 = 16.dp,
        dp20 = 20.dp,
        dp24 = 24.dp,
        dp32 = 32.dp,
        dp48 = 48.dp,
        dp56 = 56.dp,
        dp64 = 64.dp,
        dp72 = 72.dp,
        dp80 = 80.dp,
        dp100 = 100.dp,
        dp120 = 120.dp,
        dp128 = 128.dp,
        dp160 = 160.dp,
        dp180 = 180.dp,
    )

    val small = DpDimens(
        dp4 = 4.dp,
        dp8 = 5.dp,
        dp10 = 6.dp,
        dp12 = 7.dp,
        dp14 = 8.dp,
        dp16 = 10.dp,
        dp20 = 13.dp,
        dp24 = 16.dp,
        dp32 = 20.dp,
        dp48 = 32.dp,
        dp56 = 36.dp,
        dp64 = 42.dp,
        dp72 = 48.dp,
        dp80 = 56.dp,
        dp100 = 64.dp,
        dp120 = 72.dp,
        dp128 = 92.dp,
        dp160 = 120.dp,
        dp180 = 160.dp,
    )

    val compactDense = DpDimens(
        dp4 = 4.dp,
        dp8 = 4.dp,
        dp10 = 5.dp,
        dp12 = 6.dp,
        dp14 = 7.dp,
        dp16 = 8.dp,
        dp20 = 10.dp,
        dp24 = 12.dp,
        dp32 = 16.dp,
        dp48 = 24.dp,
        dp56 = 28.dp,
        dp64 = 32.dp,
        dp72 = 36.dp,
        dp80 = 40.dp,
        dp100 = 48.dp,
        dp120 = 56.dp,
        dp128 = 64.dp,
        dp160 = 80.dp,
        dp180 = 100.dp,
    )

    val expanded = DpDimens(
        dp4 = 4.dp,
        dp8 = 8.dp,
        dp10 = 10.dp,
        dp12 = 12.dp,
        dp14 = 14.dp,
        dp16 = 16.dp,
        dp20 = 22.dp,
        dp24 = 28.dp,
        dp32 = 36.dp,
        dp48 = 56.dp,
        dp56 = 64.dp,
        dp64 = 72.dp,
        dp72 = 80.dp,
        dp80 = 96.dp,
        dp100 = 128.dp,
        dp120 = 160.dp,
        dp128 = 180.dp,
        dp160 = 200.dp,
        dp180 = 240.dp,
    )


    val normalSp = SpDimens(
        sp5 = 5.sp,
        sp6 = 6.sp,
        sp8 = 8.sp,
        sp10 = 10.sp,
        sp12 = 12.sp,
        sp14 = 14.sp,
        sp16 = 16.sp,
        sp18 = 18.sp,
        sp20 = 20.sp,
        sp22 = 22.sp,
        sp24 = 24.sp,
        sp28 = 28.sp,
        sp32 = 32.sp,
    )

    val smallSp = SpDimens(
        sp5 = 2.sp,
        sp6 = 4.sp,
        sp8 = 6.sp,
        sp10 = 8.sp,
        sp12 = 10.sp,
        sp14 = 12.sp,
        sp16 = 14.sp,
        sp18 = 16.sp,
        sp20 = 18.sp,
        sp22 = 20.sp,
        sp24 = 22.sp,
        sp28 = 24.sp,
        sp32 = 28.sp,
    )

    val compactDenseSp = SpDimens(
        sp5 = 1.sp,
        sp6 = 2.sp,
        sp8 = 4.sp,
        sp10 = 6.sp,
        sp12 = 8.sp,
        sp14 = 10.sp,
        sp16 = 12.sp,
        sp18 = 14.sp,
        sp20 = 16.sp,
        sp22 = 18.sp,
        sp24 = 20.sp,
        sp28 = 22.sp,
        sp32 = 24.sp,
    )

    val expandedSp = SpDimens(
        sp5 = 5.sp,
        sp6 = 6.sp,
        sp8 = 8.sp,
        sp10 = 10.sp,
        sp12 = 12.sp,
        sp14 = 14.sp,
        sp16 = 16.sp,
        sp18 = 18.sp,
        sp20 = 21.sp,
        sp22 = 23.sp,
        sp24 = 26.sp,
        sp28 = 30.sp,
        sp32 = 34.sp,
    )


}