package com.edfapay.payment_gateway.data.mapper

import com.edfapay.payment_gateway.data.model.*
import com.edfapay.payment_gateway.domain.model.DecimalAmount
import com.edfapay.payment_gateway.domain.model.PaymentResultCode
import kotlinx.serialization.json.*

private fun String?.toPaymentResultCode(): PaymentResultCode {
    return when (this?.trim()?.uppercase()) {
        "SUCCESS" -> PaymentResultCode.SUCCESS
        "FAILURE", "FAILED", "DECLINED" -> PaymentResultCode.FAILURE
        "REDIRECT" -> PaymentResultCode.REDIRECT
        "PENDING" -> PaymentResultCode.PENDING
        null, "" -> PaymentResultCode.UNKNOWN
        else -> PaymentResultCode.UNKNOWN
    }
}

/**
 * Converts a decimal string (e.g., "123.45") to minor units (e.g., 12345) safely,
 * without using Double/Float.
 *
 * If parsing fails, minorUnits becomes null but raw is preserved.
 */
private fun String.toDecimalAmount(scale: Int): DecimalAmount {
    val trimmed = trim()
    val minor = parseMinorUnitsOrNull(trimmed, scale)
    return DecimalAmount(
        raw = trimmed,
        minorUnits = minor,
        scale = scale
    )
}

private fun parseMinorUnitsOrNull(value: String, scale: Int): Long? {
    // Accepts: "123", "123.4", "123.45"
    // Rejects: "abc", "", "-", "12.345" (unless you want rounding)
    val parts = value.split('.')
    if (parts.isEmpty() || parts.size > 2) return null

    val wholePart = parts[0].ifEmpty { "0" }
    val fracPart = if (parts.size == 2) parts[1] else ""

    val negative = wholePart.startsWith("-")
    val wholeDigits = if (negative) wholePart.drop(1) else wholePart

    if (wholeDigits.any { !it.isDigit() }) return null
    if (fracPart.any { !it.isDigit() }) return null
    if (fracPart.length > scale) return null // be strict: no rounding

    val fracPadded = fracPart.padEnd(scale, '0')
    val wholeLong = wholeDigits.toLongOrNull() ?: return null
    val fracLong = if (scale == 0) 0L else fracPadded.toLongOrNull() ?: return null

    val factor = pow10(scale)
    val combined = wholeLong * factor + fracLong
    return if (negative) -combined else combined
}

private fun pow10(scale: Int): Long {
    if (scale < 0) return 1L
    var result = 1L
    repeat(scale) { result *= 10L }
    return result
}


internal fun PaymentResultDto.toJson(): JsonObject = buildJsonObject {
    put("result", result?.let { JsonPrimitive(it) } ?: JsonNull)
    put("action", action?.let { JsonPrimitive(it) } ?: JsonNull)
    put("order_id", orderId?.let { JsonPrimitive(it) } ?: JsonNull)
    put("trans_id", transId?.let { JsonPrimitive(it) } ?: JsonNull)
    put("rrn", rrn?.let { JsonPrimitive(it) } ?: JsonNull)
    put("card_brand", cardBrand?.let { JsonPrimitive(it) } ?: JsonNull)
    put("merchant_name", merchantName?.let { JsonPrimitive(it) } ?: JsonNull)
    put("decline_reason", declineReason?.let { JsonPrimitive(it) } ?: JsonNull)
}


internal fun RefundS2SResponse.toJson(): JsonObject = buildJsonObject {
    put("result", result?.let { JsonPrimitive(it) } ?: JsonNull)
    put("referenceId", referenceId?.let { JsonPrimitive(it) } ?: JsonNull)
    put("paymentId", paymentId?.let { JsonPrimitive(it) } ?: JsonNull)
    put("message", message?.let { JsonPrimitive(it) } ?: JsonNull)
    put("amount", amount?.let { JsonPrimitive(it) } ?: JsonNull)
    put("refundId", refundId?.let { JsonPrimitive(it) } ?: JsonNull)
}

internal fun <T> BaseResponse<T>.toJson(
    dataMapper: (T) -> JsonElement
): JsonObject = buildJsonObject {
    put("code", code?.let { JsonPrimitive(it) } ?: JsonNull)
    put("errorCode", errorCode?.let { JsonPrimitive(it) } ?: JsonNull)
    put("message", message?.let { JsonPrimitive(it) } ?: JsonNull)
    put("data", data?.let(dataMapper) ?: JsonNull)
}

internal fun SaleResponseDto.toJson(): JsonObject {
    return buildJsonObject {
        put("acquirerPaymentId", JsonPrimitive(acquirerPaymentId))
        put("paymentId", JsonPrimitive(paymentId))
        put("redirectUrl", JsonPrimitive(redirectUrl))
        put("result", JsonPrimitive(result))
        put("status", JsonPrimitive(status))
    }
}

internal fun TransactionContentDto.toJson(): JsonObject = buildJsonObject {
    put("transactionId", JsonPrimitive(transactionId))
    put("orderId", JsonPrimitive(orderId))
    put("amount", JsonPrimitive(amount))
    put("currencyCode", JsonPrimitive(currencyCode))
    put("transactionStatus", JsonPrimitive(transactionStatus))
    put("paymentStatus", JsonPrimitive(paymentStatus))
    put("businessUnitId", JsonPrimitive(businessUnitId))
    put("channel", JsonPrimitive(channel))
    put("rrn", rrn?.let { JsonPrimitive(it) } ?: JsonNull)
    put("transactionType", JsonPrimitive(transactionType))
    put("reconciliationStatus", JsonPrimitive(reconciliationStatus))
    put("reconciliationAt", reconciliationAt?.let { JsonPrimitive(it) } ?: JsonNull)
    put("acquirerBank", acquirerBank?.let { JsonPrimitive(it) } ?: JsonNull)
    put("providerTid", providerTid?.let { JsonPrimitive(it) } ?: JsonNull)
    put("holderAccount", holderAccount?.let { JsonPrimitive(it) } ?: JsonNull)
    put("cardScheme", cardScheme?.let { JsonPrimitive(it) } ?: JsonNull)
    put("cardChannel", cardChannel?.let { JsonPrimitive(it) } ?: JsonNull)
    put("cardSequenceNumber", cardSequenceNumber?.let { JsonPrimitive(it) } ?: JsonNull)
    put("pan", pan?.let { JsonPrimitive(it) } ?: JsonNull)
    put("cardExpiration", cardExpiration?.let { JsonPrimitive(it) } ?: JsonNull)
    put("cardHolderName", cardHolderName?.let { JsonPrimitive(it) } ?: JsonNull)
    put("createdAt", createdAt?.let { JsonPrimitive(it) } ?: JsonNull)
    put("finishedAt", finishedAt?.let { JsonPrimitive(it) } ?: JsonNull)
    put("createdBy", createdBy?.let { JsonPrimitive(it) } ?: JsonNull)
    put("createdByName", createdByName?.let { JsonPrimitive(it) } ?: JsonNull)
    put("totalRefundAmount", totalRefundAmount?.let { JsonPrimitive(it) } ?: JsonNull)
    put("refundStatus", refundStatus?.let { JsonPrimitive(it) } ?: JsonNull)
    put("merchantId", merchantId?.let { JsonPrimitive(it) } ?: JsonNull)
    put("recurringToken", recurringToken?.let { JsonPrimitive(it) } ?: JsonNull)
}

internal fun PageDto<TransactionContentDto>.toJson(): PageDto<JsonObject> {
    return PageDto(
        content = content.map { it.toJson() },
        number = number,
        size = size,
        totalElements = totalElements,
        numberOfElements = numberOfElements,
        totalPages = totalPages,
        hasContent = hasContent,
        first = first,
        last = last,
    )
}

internal fun errorMessage(code: String, msg: String): JsonObject {
    val map = mapOf(
        "code" to JsonPrimitive(code),
        "message" to JsonPrimitive(msg),
        "errorCode" to JsonPrimitive(code),
        "data" to JsonPrimitive(JsonNull.content)
    )
    return JsonObject(map)
}