package com.edfapay.payment_gateway.presentation.payment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.edfapay.library.generated.resources.Res
import com.edfapay.library.generated.resources.msg_order_null
import com.edfapay.library.generated.resources.msg_sale_null
import com.edfapay.payment_gateway.data.providers.TransactionProvider
import com.edfapay.payment_gateway.presentation.payment.models.EdfaCardPay
import com.edfapay.payment_gateway.presentation.payment.utils.CardBackState
import com.edfapay.payment_gateway.presentation.payment.utils.formatMoney
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.getString

internal class PaymentViewModel(
    private val provider: TransactionProvider,
) : ViewModel() {
    private val _uiState = MutableStateFlow(PaymentUiState())
    val uiState = _uiState.asStateFlow()


    private val cp = EdfaCardPay.shared()

    init {
        if (cp.order == null) {
            viewModelScope.launch {
                cp.onTransactionFailure?.invoke(getString(Res.string.msg_order_null))
            }
        } else {
            val amount = cp.order?.amount ?: 0.0
            val currency = cp.order?.currency ?: ""
            _uiState.update { data ->
                data.copy(
                    cardData = data.cardData.copy(
                        amount = amount.formatMoney(),
                        currency = currency,
                    )
                )
            }
        }
    }

    fun onStateChange(card: CardBackState) {
        _uiState.update {
            it.copy(
                cardData = card
            )
        }
    }

    fun executeModernSale(onRedirect: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val s = cp.generateSaleRequest(uiState.value.cardData)
            if (s == null) {
                cp.onTransactionFailure?.invoke(getString(Res.string.msg_sale_null))
                return@launch
            }
            provider.sale(s)
            onRedirect()
        }
    }
}
