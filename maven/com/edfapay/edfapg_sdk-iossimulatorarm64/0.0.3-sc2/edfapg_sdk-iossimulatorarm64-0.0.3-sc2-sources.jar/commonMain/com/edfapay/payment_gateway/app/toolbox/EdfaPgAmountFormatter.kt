/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.app.toolbox

/**
 * KMP amount formatter:
 * - Locale: US
 * - No grouping separators
 * - Exactly 2 fraction digits
 * - Minimum 1 integer digit
 */
internal expect class EdfaPgAmountFormatter() {
    fun amountFormat(amount: Double): String
}

