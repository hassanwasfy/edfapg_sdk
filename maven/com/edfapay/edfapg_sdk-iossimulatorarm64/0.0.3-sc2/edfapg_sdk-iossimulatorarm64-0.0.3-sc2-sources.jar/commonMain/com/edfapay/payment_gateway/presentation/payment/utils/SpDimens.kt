package com.edfapay.payment_gateway.presentation.payment.utils

import androidx.compose.ui.unit.TextUnit

internal data class SpDimens(
    val sp5: TextUnit,
    val sp6: TextUnit,
    val sp8: TextUnit,
    val sp10: TextUnit,
    val sp12: TextUnit,
    val sp14: TextUnit,
    val sp16: TextUnit,
    val sp18: TextUnit,
    val sp20: TextUnit,
    val sp22: TextUnit,
    val sp24: TextUnit,
    val sp28: TextUnit,
    val sp32: TextUnit,
)
