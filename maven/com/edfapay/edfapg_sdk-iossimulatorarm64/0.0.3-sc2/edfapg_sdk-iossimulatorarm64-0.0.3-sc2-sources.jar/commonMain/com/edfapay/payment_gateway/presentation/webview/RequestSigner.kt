package com.edfapay.payment_gateway.presentation.webview

import io.ktor.serialization.kotlinx.json.DefaultJson
import kotlinx.serialization.json.Json

inline fun <reified T> sign(
    dto: T,
    secretKey: String,
    json: Json = DefaultJson
): SignedBody {
    val bodyJson = json.encodeToString(dto)
    val signature = Sha256.hex(bodyJson + secretKey)
    return SignedBody(bodyJson, signature)
}

data class SignedBody(
    val bodyJson: String,
    val signature: String
)
