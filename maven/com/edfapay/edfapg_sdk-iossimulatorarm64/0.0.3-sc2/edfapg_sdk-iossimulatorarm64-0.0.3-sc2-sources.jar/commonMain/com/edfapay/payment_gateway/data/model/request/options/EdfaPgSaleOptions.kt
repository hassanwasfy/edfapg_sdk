/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.data.model.request.options

import kotlinx.serialization.Serializable

/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 */
@Serializable
data class EdfaPgSaleOptions(
    val channelId: String? = null,
    val recurringInit: Boolean? = null,
)
