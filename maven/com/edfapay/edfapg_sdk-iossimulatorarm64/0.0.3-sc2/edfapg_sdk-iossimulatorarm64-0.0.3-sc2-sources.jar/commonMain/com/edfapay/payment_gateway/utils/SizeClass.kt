package com.edfapay.payment_gateway.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import com.edfapay.payment_gateway.presentation.payment.utils.Dimens
import com.edfapay.payment_gateway.presentation.payment.utils.DpDimens
import com.edfapay.payment_gateway.presentation.payment.utils.SpDimens

// commonMain
internal enum class WClass { Compact, Medium, Expanded }
internal enum class HClass { Compact, Medium, Expanded }

internal data class SizeClass(val w: WClass, val h: HClass)

@Composable
internal expect fun rememberSizeClass(): SizeClass

internal val LocalAppDp = staticCompositionLocalOf {
    Dimens.normal
}
internal val LocalAppSp = staticCompositionLocalOf {
    Dimens.normalSp
}

// commonMain
@Composable
internal fun getDpDimens(): DpDimens {
    val sc = rememberSizeClass()
//    return when (sc.w) {
//        WClass.Compact -> when (sc.h) {
//            HClass.Compact -> Dimens.compactDense
//            HClass.Medium -> Dimens.small
//            HClass.Expanded -> Dimens.expanded
//        }
//
//        WClass.Medium -> Dimens.normal
//        WClass.Expanded -> Dimens.expanded
//    }
    return Dimens.normal
}

@Composable
internal fun getSpDimens(): SpDimens {
    val sc = rememberSizeClass()
//    return when (sc.w) {
//        WClass.Compact -> when (sc.h) {
//            HClass.Compact -> Dimens.compactDenseSp
//            HClass.Medium -> Dimens.smallSp
//            HClass.Expanded -> Dimens.expandedSp
//        }
//
//        WClass.Medium -> Dimens.normalSp
//        WClass.Expanded -> Dimens.expandedSp
//    }
    return Dimens.normalSp
}

