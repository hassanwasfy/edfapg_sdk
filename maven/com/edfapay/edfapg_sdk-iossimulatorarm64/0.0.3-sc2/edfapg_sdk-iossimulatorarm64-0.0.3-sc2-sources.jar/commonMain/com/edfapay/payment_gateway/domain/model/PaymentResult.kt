package com.edfapay.payment_gateway.domain.model

internal data class PaymentResult(
    val result: PaymentResultCode,
    val action: String,
    val orderId: String,
    val transId: String,
    val rrn: String,
    val cardBrand: String,
    val merchantName: String,
    val declineReason: String
)