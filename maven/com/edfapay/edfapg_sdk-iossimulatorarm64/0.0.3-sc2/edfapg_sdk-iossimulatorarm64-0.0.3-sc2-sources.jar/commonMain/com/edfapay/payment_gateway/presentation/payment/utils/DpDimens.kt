package com.edfapay.payment_gateway.presentation.payment.utils

import androidx.compose.ui.unit.Dp

internal data class DpDimens(
    val dp4: Dp,
    val dp8: Dp,
    val dp10: Dp,
    val dp12: Dp,
    val dp14: Dp,
    val dp16: Dp,
    val dp20: Dp,
    val dp24: Dp,
    val dp32: Dp,
    val dp48: Dp,
    val dp56: Dp,
    val dp64: Dp,
    val dp72: Dp,
    val dp80: Dp,
    val dp100: Dp,
    val dp120: Dp,
    val dp128: Dp,
    val dp160: Dp,
    val dp180: Dp,
)