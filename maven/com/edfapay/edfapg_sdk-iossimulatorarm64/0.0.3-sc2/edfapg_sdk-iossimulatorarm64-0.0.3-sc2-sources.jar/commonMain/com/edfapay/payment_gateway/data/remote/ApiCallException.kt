package com.edfapay.payment_gateway.data.remote

internal class ApiException(
    val code: Int? = null,
    val errorBody: String? = null,
    message: String,
    cause: Throwable? = null
) : Exception(message, cause)
