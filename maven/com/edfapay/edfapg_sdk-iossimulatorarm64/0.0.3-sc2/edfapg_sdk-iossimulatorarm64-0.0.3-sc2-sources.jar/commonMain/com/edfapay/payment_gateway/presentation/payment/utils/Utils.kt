package com.edfapay.payment_gateway.presentation.payment.utils

import androidx.compose.runtime.Composable
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.edfapay.library.generated.resources.*
import org.jetbrains.compose.resources.Font
import kotlin.math.abs
import kotlin.math.roundToLong

@Composable
internal fun poppinsFontFamily() = FontFamily(
    Font(Res.font.poppins, FontWeight.Normal),
    Font(Res.font.poppins_light, FontWeight.Light),
    Font(Res.font.poppins_medium, FontWeight.Medium),
    Font(Res.font.poppins_semibold, FontWeight.SemiBold),
    Font(Res.font.poppins_bold, FontWeight.Bold),
)

internal fun digitsOnly(s: String) = s.filter { it.isDigit() }


internal fun String.isDigitsOnly(): Boolean {
    if (this.isEmpty()) return false
    return this.matches(Regex("^[0-9]*\\.?[0-9]*$"))
}


internal fun formatCardNumber(rawDigits: String): String {
    // group 4 digits: 1234 5678 9012 3456 (supports up to 19 digits)
    return rawDigits.chunked(4).joinToString(" ")
}

internal fun formatExpiry(rawDigits: String): String {
    val d = rawDigits.take(4) // MMYY
    val result = when {
        d.length <= 2 -> d
        else -> d.take(2) + "/" + d.substring(2)
    }
    return result
}

internal enum class CardBrand(val panLen: Int, val cvvLen: Int) { AMEX(15, 4), OTHER(16, 3) }

internal fun detectBrand(panDigits: String): CardBrand {
    // AMEX starts with 34 or 37
    return if (panDigits.startsWith("34") || panDigits.startsWith("37")) CardBrand.AMEX else CardBrand.OTHER
}

internal fun clampMonth(mm: String): String {
    if (mm.length < 2) return mm
    val m = mm.toIntOrNull() ?: return ""
    return when {
        m <= 0 -> "01"
        m > 12 -> "12"
        else -> mm
    }
}


data class CardBackState(
    val cardNumber: String = "",
    val holderName: String = "",
    val expiry: String = "",
    val cvv: String = "",
    val amount: String = "",
    val currency: String = "",
)

/**
 * KMP-safe money formatting: 1,000.50
 * - thousands separator: ','
 * - decimal separator: '.'
 * - always 2 fractional digits
 */
fun Double.formatMoney(): String {
    if (!this.isFinite()) return this.toString()

    val negative = this < 0
    val cents = (abs(this) * 100.0).roundToLong()

    val whole = cents / 100
    val fraction = (cents % 100).toInt()

    val wholeStr = whole.toString().withThousandsSeparator(',')
    val fracStr = fraction.toString().padStart(2, '0')

    val sign = if (negative && cents != 0L) "-" else ""

    return "$sign$wholeStr.$fracStr"
}

private fun String.withThousandsSeparator(sep: Char): String {
    val s = this
    val n = s.length
    if (n <= 3) return s

    val sb = StringBuilder(n + (n - 1) / 3)
    var count = 0
    for (i in n - 1 downTo 0) {
        sb.append(s[i])
        count++
        if (count == 3 && i != 0) {
            sb.append(sep)
            count = 0
        }
    }
    return sb.reverse().toString()
}
