package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class BaseResponse<T>(
    @SerialName("code")
    val code: Int? = null,

    @SerialName("data")
    val data: T? = null,

    @SerialName("errorCode")
    val errorCode: String? = null,

    @SerialName("message")
    val message: String? = null
)
