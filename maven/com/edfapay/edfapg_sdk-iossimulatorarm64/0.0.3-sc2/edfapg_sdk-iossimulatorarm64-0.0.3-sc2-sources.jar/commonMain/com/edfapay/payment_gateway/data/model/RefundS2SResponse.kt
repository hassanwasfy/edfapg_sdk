package com.edfapay.payment_gateway.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class RefundS2SResponse(
    @SerialName("result") val result: String? = null,
    @SerialName("referenceId") val referenceId: String? = null,
    @SerialName("paymentId") val paymentId: String? = null,
    @SerialName("message") val message: String? = null,
    @SerialName("amount") val amount: String? = null,
    @SerialName("refundId") val refundId: String? = null
)

