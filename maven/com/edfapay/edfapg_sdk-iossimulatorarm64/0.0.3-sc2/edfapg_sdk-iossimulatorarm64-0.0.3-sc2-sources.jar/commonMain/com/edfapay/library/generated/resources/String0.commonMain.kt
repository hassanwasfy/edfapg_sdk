@file:OptIn(InternalResourceApi::class)

package com.edfapay.library.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.edfapay.library.generated.resources/"

internal val Res.string.action_capture: StringResource by lazy {
      StringResource("string:action_capture", "action_capture", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 10, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 34),
      ))
    }

internal val Res.string.action_pay: StringResource by lazy {
      StringResource("string:action_pay", "action_pay", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 49, 30),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 45, 22),
      ))
    }

internal val Res.string.action_refund: StringResource by lazy {
      StringResource("string:action_refund", "action_refund", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 80, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 68, 29),
      ))
    }

internal val Res.string.action_void: StringResource by lazy {
      StringResource("string:action_void", "action_void", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 122, 35),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 98, 27),
      ))
    }

internal val Res.string.app_name: StringResource by lazy {
      StringResource("string:app_name", "app_name", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 158, 28),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 126, 28),
      ))
    }

internal val Res.string.hint_card_number: StringResource by lazy {
      StringResource("string:hint_card_number", "hint_card_number", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 187, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 155, 40),
      ))
    }

internal val Res.string.hint_cardholder_name: StringResource by lazy {
      StringResource("string:hint_cardholder_name", "hint_cardholder_name", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 240, 68),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 196, 48),
      ))
    }

internal val Res.string.hint_cvv_cvc: StringResource by lazy {
      StringResource("string:hint_cvv_cvc", "hint_cvv_cvc", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 309, 32),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 245, 32),
      ))
    }

internal val Res.string.hint_expiry_date: StringResource by lazy {
      StringResource("string:hint_expiry_date", "hint_expiry_date", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 342, 60),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 278, 36),
      ))
    }

internal val Res.string.label_card_state_title: StringResource by lazy {
      StringResource("string:label_card_state_title", "label_card_state_title", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 403, 78),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 315, 62),
      ))
    }

internal val Res.string.label_cvv: StringResource by lazy {
      StringResource("string:label_cvv", "label_cvv", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 482, 21),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 378, 21),
      ))
    }

internal val Res.string.label_month_year: StringResource by lazy {
      StringResource("string:label_month_year", "label_month_year", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 504, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 400, 40),
      ))
    }

internal val Res.string.label_optional: StringResource by lazy {
      StringResource("string:label_optional", "label_optional", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 557, 46),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 441, 38),
      ))
    }

internal val Res.string.label_payment: StringResource by lazy {
      StringResource("string:label_payment", "label_payment", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 604, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 480, 33),
      ))
    }

internal val Res.string.label_total_amount: StringResource by lazy {
      StringResource("string:label_total_amount", "label_total_amount", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 642, 66),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 514, 42),
      ))
    }

internal val Res.string.label_total_balance: StringResource by lazy {
      StringResource("string:label_total_balance", "label_total_balance", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 709, 67),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 557, 47),
      ))
    }

internal val Res.string.lbl_card_details: StringResource by lazy {
      StringResource("string:lbl_card_details", "lbl_card_details", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 777, 80),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 605, 56),
      ))
    }

internal val Res.string.lbl_card_ui: StringResource by lazy {
      StringResource("string:lbl_card_ui", "lbl_card_ui", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 858, 71),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 662, 43),
      ))
    }

internal val Res.string.lbl_error_card: StringResource by lazy {
      StringResource("string:lbl_error_card", "lbl_error_card", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 930, 130),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 706, 82),
      ))
    }

internal val Res.string.lbl_error_missing: StringResource by lazy {
      StringResource("string:lbl_error_missing", "lbl_error_missing", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1061, 61),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 789, 53),
      ))
    }

internal val Res.string.lbl_error_order: StringResource by lazy {
      StringResource("string:lbl_error_order", "lbl_error_order", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1123, 71),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 843, 47),
      ))
    }

internal val Res.string.lbl_error_payer: StringResource by lazy {
      StringResource("string:lbl_error_payer", "lbl_error_payer", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1195, 75),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 891, 47),
      ))
    }

internal val Res.string.lbl_transactions: StringResource by lazy {
      StringResource("string:lbl_transactions", "lbl_transactions", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1271, 48),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 939, 40),
      ))
    }

internal val Res.string.log_execute_modern_sale: StringResource by lazy {
      StringResource("string:log_execute_modern_sale", "log_execute_modern_sale", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1320, 107),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 980, 63),
      ))
    }

internal val Res.string.log_will_open: StringResource by lazy {
      StringResource("string:log_will_open", "log_will_open", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1428, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1044, 41),
      ))
    }

internal val Res.string.msg_order_null: StringResource by lazy {
      StringResource("string:msg_order_null", "msg_order_null", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1478, 94),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1086, 50),
      ))
    }

internal val Res.string.msg_sale_null: StringResource by lazy {
      StringResource("string:msg_sale_null", "msg_sale_null", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1573, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1137, 37),
      ))
    }

internal val Res.string.msg_transaction_failed: StringResource by lazy {
      StringResource("string:msg_transaction_failed", "msg_transaction_failed", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1623, 74),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1175, 62),
      ))
    }

internal val Res.string.placeholder_card_number: StringResource by lazy {
      StringResource("string:placeholder_card_number", "placeholder_card_number", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1698, 99),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1238, 99),
      ))
    }

internal val Res.string.placeholder_cvv_3: StringResource by lazy {
      StringResource("string:placeholder_cvv_3", "placeholder_cvv_3", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1798, 37),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1338, 37),
      ))
    }

internal val Res.string.placeholder_cvv_4: StringResource by lazy {
      StringResource("string:placeholder_cvv_4", "placeholder_cvv_4", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1836, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1376, 41),
      ))
    }

internal val Res.string.placeholder_expiry_format: StringResource by lazy {
      StringResource("string:placeholder_expiry_format", "placeholder_expiry_format", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1878, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1418, 41),
      ))
    }

internal val Res.string.value_missing_id_number: StringResource by lazy {
      StringResource("string:value_missing_id_number", "value_missing_id_number", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1920, 71),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1460, 55),
      ))
    }

internal val Res.string.value_missing_id_type: StringResource by lazy {
      StringResource("string:value_missing_id_type", "value_missing_id_type", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1992, 69),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1516, 49),
      ))
    }

internal val Res.string.value_missing_state_name: StringResource by lazy {
      StringResource("string:value_missing_state_name", "value_missing_state_name", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2062, 76),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1566, 56),
      ))
    }

internal val Res.string.value_missing_tax_number: StringResource by lazy {
      StringResource("string:value_missing_tax_number", "value_missing_tax_number", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2139, 80),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1623, 56),
      ))
    }

internal val Res.string.value_missing_token: StringResource by lazy {
      StringResource("string:value_missing_token", "value_missing_token", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2220, 55),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1680, 47),
      ))
    }

internal val Res.string.value_refund_exceed: StringResource by lazy {
      StringResource("string:value_refund_exceed", "value_refund_exceed", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2276, 99),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1728, 79),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("action_capture", Res.string.action_capture)
  map.put("action_pay", Res.string.action_pay)
  map.put("action_refund", Res.string.action_refund)
  map.put("action_void", Res.string.action_void)
  map.put("app_name", Res.string.app_name)
  map.put("hint_card_number", Res.string.hint_card_number)
  map.put("hint_cardholder_name", Res.string.hint_cardholder_name)
  map.put("hint_cvv_cvc", Res.string.hint_cvv_cvc)
  map.put("hint_expiry_date", Res.string.hint_expiry_date)
  map.put("label_card_state_title", Res.string.label_card_state_title)
  map.put("label_cvv", Res.string.label_cvv)
  map.put("label_month_year", Res.string.label_month_year)
  map.put("label_optional", Res.string.label_optional)
  map.put("label_payment", Res.string.label_payment)
  map.put("label_total_amount", Res.string.label_total_amount)
  map.put("label_total_balance", Res.string.label_total_balance)
  map.put("lbl_card_details", Res.string.lbl_card_details)
  map.put("lbl_card_ui", Res.string.lbl_card_ui)
  map.put("lbl_error_card", Res.string.lbl_error_card)
  map.put("lbl_error_missing", Res.string.lbl_error_missing)
  map.put("lbl_error_order", Res.string.lbl_error_order)
  map.put("lbl_error_payer", Res.string.lbl_error_payer)
  map.put("lbl_transactions", Res.string.lbl_transactions)
  map.put("log_execute_modern_sale", Res.string.log_execute_modern_sale)
  map.put("log_will_open", Res.string.log_will_open)
  map.put("msg_order_null", Res.string.msg_order_null)
  map.put("msg_sale_null", Res.string.msg_sale_null)
  map.put("msg_transaction_failed", Res.string.msg_transaction_failed)
  map.put("placeholder_card_number", Res.string.placeholder_card_number)
  map.put("placeholder_cvv_3", Res.string.placeholder_cvv_3)
  map.put("placeholder_cvv_4", Res.string.placeholder_cvv_4)
  map.put("placeholder_expiry_format", Res.string.placeholder_expiry_format)
  map.put("value_missing_id_number", Res.string.value_missing_id_number)
  map.put("value_missing_id_type", Res.string.value_missing_id_type)
  map.put("value_missing_state_name", Res.string.value_missing_state_name)
  map.put("value_missing_tax_number", Res.string.value_missing_tax_number)
  map.put("value_missing_token", Res.string.value_missing_token)
  map.put("value_refund_exceed", Res.string.value_refund_exceed)
}
