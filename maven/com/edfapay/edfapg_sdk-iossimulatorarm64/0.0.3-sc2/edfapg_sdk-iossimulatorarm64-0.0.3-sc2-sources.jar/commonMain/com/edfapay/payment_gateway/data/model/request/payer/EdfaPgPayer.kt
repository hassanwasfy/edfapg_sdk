/*
 * Property of EdfaPg (https://edfapay.com).
 */

package com.edfapay.payment_gateway.data.model.request.payer

import kotlinx.serialization.Serializable


/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 */
@Serializable
data class EdfaPgPayer(
    val firstName: String,
    val lastName: String,
    val address: String,
    val country: String,
    val city: String,
    val zip: String,
    val email: String,
    val phone: String,
    val ip: String,
    val options: EdfaPgPayerOptions? = null
) {


    fun validate(): List<String> {
        val errors = mutableListOf<String>()

        if (firstName.isBlank()) errors.add("firstName is empty")
        if (lastName.isBlank()) errors.add("lastName is empty")
        if (address.isBlank()) errors.add("address is empty")
        if (country.isBlank()) errors.add("country is empty")
        if (city.isBlank()) errors.add("city is empty")
        if (zip.isBlank()) errors.add("zip is empty")
        if (!Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$").matches(email)) {
            errors.add("email is invalid")
        }
        if (phone.isBlank()) errors.add("phone is empty")
        if (!Regex("^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$").matches(
                ip
            )
        ) {
            errors.add("IP address is invalid")
        }

        return errors
    }
}
