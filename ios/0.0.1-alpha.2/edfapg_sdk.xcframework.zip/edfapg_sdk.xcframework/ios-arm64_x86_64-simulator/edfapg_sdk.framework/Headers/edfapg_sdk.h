#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class Edfapg_sdkBillingAddressDto, Edfapg_sdkBillingAddressDtoCompanion, Edfapg_sdkCardBackState, Edfapg_sdkCardDto, Edfapg_sdkCardDtoCompanion, Edfapg_sdkCredentials, Edfapg_sdkCustomerDto, Edfapg_sdkCustomerDtoCompanion, Edfapg_sdkEdfaCardPay, Edfapg_sdkEdfaCardPayCompanion, Edfapg_sdkEdfaPayDesignType, Edfapg_sdkEdfaPayLanguage, Edfapg_sdkEdfaPgCard, Edfapg_sdkEdfaPgCardCompanion, Edfapg_sdkEdfaPgCredential, Edfapg_sdkEdfaPgPayer, Edfapg_sdkEdfaPgPayerCompanion, Edfapg_sdkEdfaPgPayerOptions, Edfapg_sdkEdfaPgPayerOptionsCompanion, Edfapg_sdkEdfaPgSaleOptions, Edfapg_sdkEdfaPgSaleOptionsCompanion, Edfapg_sdkEdfaPgSaleOrder, Edfapg_sdkEdfaPgSaleOrderCompanion, Edfapg_sdkEdfaPgSdk, Edfapg_sdkEdfaPgSdkIsNotInitializedExceptionCompanion, Edfapg_sdkEdfaPgTestCard, Edfapg_sdkExecuteData, Edfapg_sdkExecuteDataCompanion, Edfapg_sdkExtra, Edfapg_sdkExtraCompanion, Edfapg_sdkInvoiceDto, Edfapg_sdkInvoiceDtoCompanion, Edfapg_sdkKMP_LEVEL, Edfapg_sdkKmpLogger, Edfapg_sdkKotlinArray<T>, Edfapg_sdkKotlinByteArray, Edfapg_sdkKotlinByteIterator, Edfapg_sdkKotlinEnum<E>, Edfapg_sdkKotlinEnumCompanion, Edfapg_sdkKotlinException, Edfapg_sdkKotlinIllegalArgumentException, Edfapg_sdkKotlinIllegalStateException, Edfapg_sdkKotlinNothing, Edfapg_sdkKotlinRuntimeException, Edfapg_sdkKotlinThrowable, Edfapg_sdkKotlinx_datetimeDayOfWeek, Edfapg_sdkKotlinx_datetimeDayOfWeekNames, Edfapg_sdkKotlinx_datetimeDayOfWeekNamesCompanion, Edfapg_sdkKotlinx_datetimeLocalDate, Edfapg_sdkKotlinx_datetimeLocalDateCompanion, Edfapg_sdkKotlinx_datetimeLocalDateProgression, Edfapg_sdkKotlinx_datetimeLocalDateProgressionCompanion, Edfapg_sdkKotlinx_datetimeLocalDateRange, Edfapg_sdkKotlinx_datetimeLocalDateRangeCompanion, Edfapg_sdkKotlinx_datetimeMonth, Edfapg_sdkKotlinx_datetimeMonthNames, Edfapg_sdkKotlinx_datetimeMonthNamesCompanion, Edfapg_sdkKotlinx_datetimePadding, Edfapg_sdkKotlinx_serialization_coreSerialKind, Edfapg_sdkKotlinx_serialization_coreSerializersModule, Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode, Edfapg_sdkKotlinx_serialization_jsonJson, Edfapg_sdkKotlinx_serialization_jsonJsonConfiguration, Edfapg_sdkKotlinx_serialization_jsonJsonDefault, Edfapg_sdkKotlinx_serialization_jsonJsonElement, Edfapg_sdkKotlinx_serialization_jsonJsonElementCompanion, Edfapg_sdkLineItemDto, Edfapg_sdkLineItemDtoCompanion, Edfapg_sdkOrder, Edfapg_sdkOrderCompanion, Edfapg_sdkPageDto<T>, Edfapg_sdkPageDtoCompanion, Edfapg_sdkRecurringRequestBody, Edfapg_sdkRecurringRequestBodyCompanion, Edfapg_sdkRefundStatus, Edfapg_sdkSaleRequestDto, Edfapg_sdkSaleRequestDtoCompanion, Edfapg_sdkSha256, Edfapg_sdkSignedBody, Edfapg_sdkTransactionContentDto, Edfapg_sdkTransactionContentDtoCompanion, Edfapg_sdkTransactionFilter, Edfapg_sdkTransactionType, UIViewController;

@protocol Edfapg_sdkKotlinAnnotation, Edfapg_sdkKotlinAppendable, Edfapg_sdkKotlinClosedRange, Edfapg_sdkKotlinCollection, Edfapg_sdkKotlinComparable, Edfapg_sdkKotlinIterable, Edfapg_sdkKotlinIterator, Edfapg_sdkKotlinKAnnotatedElement, Edfapg_sdkKotlinKClass, Edfapg_sdkKotlinKClassifier, Edfapg_sdkKotlinKDeclarationContainer, Edfapg_sdkKotlinOpenEndRange, Edfapg_sdkKotlinx_datetimeDateTimeFormat, Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilder, Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilderWithDate, Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilderWithYearMonth, Edfapg_sdkKotlinx_serialization_coreCompositeDecoder, Edfapg_sdkKotlinx_serialization_coreCompositeEncoder, Edfapg_sdkKotlinx_serialization_coreDecoder, Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy, Edfapg_sdkKotlinx_serialization_coreEncoder, Edfapg_sdkKotlinx_serialization_coreKSerializer, Edfapg_sdkKotlinx_serialization_coreSerialDescriptor, Edfapg_sdkKotlinx_serialization_coreSerialFormat, Edfapg_sdkKotlinx_serialization_coreSerializationStrategy, Edfapg_sdkKotlinx_serialization_coreSerializersModuleCollector, Edfapg_sdkKotlinx_serialization_coreStringFormat, Edfapg_sdkKotlinx_serialization_jsonJsonNamingStrategy, Edfapg_sdkTransactionProvider;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface Edfapg_sdkBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface Edfapg_sdkBase (Edfapg_sdkBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface Edfapg_sdkMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface Edfapg_sdkMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorEdfapg_sdkKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface Edfapg_sdkNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface Edfapg_sdkByte : Edfapg_sdkNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface Edfapg_sdkUByte : Edfapg_sdkNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface Edfapg_sdkShort : Edfapg_sdkNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface Edfapg_sdkUShort : Edfapg_sdkNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface Edfapg_sdkInt : Edfapg_sdkNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface Edfapg_sdkUInt : Edfapg_sdkNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface Edfapg_sdkLong : Edfapg_sdkNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface Edfapg_sdkULong : Edfapg_sdkNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface Edfapg_sdkFloat : Edfapg_sdkNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface Edfapg_sdkDouble : Edfapg_sdkNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface Edfapg_sdkBoolean : Edfapg_sdkNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end


/**
 * The [EdfaPgSdk] credentials holder.
 * It stores and retrieve it automatically after the first successful [init].
 * [EdfaPgCredential] stores values in the [EdfaPgStorage].
 * @throws EdfaPgSdkIsNotInitializedException if [EdfaPgSdk] is not initialized.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgCredential")))
@interface Edfapg_sdkEdfaPgCredential : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The [EdfaPgSdk] credentials holder.
 * It stores and retrieve it automatically after the first successful [init].
 * [EdfaPgCredential] stores values in the [EdfaPgStorage].
 * @throws EdfaPgSdkIsNotInitializedException if [EdfaPgSdk] is not initialized.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)edfaPgCredential __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgCredential *shared __attribute__((swift_name("shared")));
- (NSString *)getPaymentUrl __attribute__((swift_name("getPaymentUrl()")));

/**
 * Initialize the [EdfaPgCredential] values.
 *
 * @param apiKey the [EdfaPgCredential.API_KEY] value.
 * @param paymentUrl the [EdfaPgCredential.PAYMENT_URL] value.
 */
- (void)doInitApiKey:(NSString *)apiKey paymentUrl:(NSString *)paymentUrl __attribute__((swift_name("doInit(apiKey:paymentUrl:)")));

/**
 * Soft check of the [EdfaPgCredential] initialization status.
 * @return the true if all [EdfaPgCredential] values are provided.
 * @throws EdfaPgSdkIsNotInitializedException
 */
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));

/**
 * Hard check of the [EdfaPgCredential] initialization status.
 * @throws EdfaPgSdkIsNotInitializedException
 */
- (void)requireInit __attribute__((swift_name("requireInit()")));
@end


/**
 *
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgSdk")))
@interface Edfapg_sdkEdfaPgSdk : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 *
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)edfaPgSdk __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgSdk *shared __attribute__((swift_name("shared")));

/**
 * Initialize the [EdfaPgSdk] explicitly using the [EdfaPgCredential] values.
 *
 * @param context the app context.
 * @param apiKey the [EdfaPgCredential.API_KEY] value.
 * @param baseUrl the [EdfaPgCredential.PAYMENT_URL] value.
 * @throws EdfaPgSdkIsNotInitializedException
 */
- (void)doInitApiKey:(NSString *)apiKey baseUrl:(NSString *)baseUrl __attribute__((swift_name("doInit(apiKey:baseUrl:)")));
- (id<Edfapg_sdkTransactionProvider>)transactionProvider __attribute__((swift_name("transactionProvider()")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface Edfapg_sdkKotlinThrowable : Edfapg_sdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (Edfapg_sdkKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) Edfapg_sdkKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface Edfapg_sdkKotlinException : Edfapg_sdkKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface Edfapg_sdkKotlinRuntimeException : Edfapg_sdkKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalArgumentException")))
@interface Edfapg_sdkKotlinIllegalArgumentException : Edfapg_sdkKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * The [EdfaPgSdk] not initialized exception. Thrown when [EdfaPgCredential.requireInit] is not satisfied with
 * the [EdfaPgCredential.isInitialized] soft check.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgSdkIsNotInitializedException")))
@interface Edfapg_sdkEdfaPgSdkIsNotInitializedException : Edfapg_sdkKotlinIllegalArgumentException

/**
 * The [EdfaPgSdk] not initialized exception. Thrown when [EdfaPgCredential.requireInit] is not satisfied with
 * the [EdfaPgCredential.isInitialized] soft check.
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * The [EdfaPgSdk] not initialized exception. Thrown when [EdfaPgCredential.requireInit] is not satisfied with
 * the [EdfaPgCredential.isInitialized] soft check.
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) Edfapg_sdkEdfaPgSdkIsNotInitializedExceptionCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgSdkIsNotInitializedException.Companion")))
@interface Edfapg_sdkEdfaPgSdkIsNotInitializedExceptionCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgSdkIsNotInitializedExceptionCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol Edfapg_sdkKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface Edfapg_sdkKotlinEnum<E> : Edfapg_sdkBase <Edfapg_sdkKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPayDesignType")))
@interface Edfapg_sdkEdfaPayDesignType : Edfapg_sdkKotlinEnum<Edfapg_sdkEdfaPayDesignType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) Edfapg_sdkEdfaPayDesignType *one __attribute__((swift_name("one")));
@property (class, readonly) Edfapg_sdkEdfaPayDesignType *two __attribute__((swift_name("two")));
@property (class, readonly) Edfapg_sdkEdfaPayDesignType *three __attribute__((swift_name("three")));
+ (Edfapg_sdkKotlinArray<Edfapg_sdkEdfaPayDesignType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<Edfapg_sdkEdfaPayDesignType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPayLanguage")))
@interface Edfapg_sdkEdfaPayLanguage : Edfapg_sdkKotlinEnum<Edfapg_sdkEdfaPayLanguage *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) Edfapg_sdkEdfaPayLanguage *ar __attribute__((swift_name("ar")));
@property (class, readonly) Edfapg_sdkEdfaPayLanguage *en __attribute__((swift_name("en")));
+ (Edfapg_sdkKotlinArray<Edfapg_sdkEdfaPayLanguage *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<Edfapg_sdkEdfaPayLanguage *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BillingAddressDto")))
@interface Edfapg_sdkBillingAddressDto : Edfapg_sdkBase
- (instancetype)initWithCountry:(NSString *)country state:(NSString *)state city:(NSString *)city address:(NSString *)address zip:(NSString *)zip __attribute__((swift_name("init(country:state:city:address:zip:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkBillingAddressDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkBillingAddressDto *)doCopyCountry:(NSString *)country state:(NSString *)state city:(NSString *)city address:(NSString *)address zip:(NSString *)zip __attribute__((swift_name("doCopy(country:state:city:address:zip:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="address")
*/
@property (readonly) NSString *address __attribute__((swift_name("address")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="city")
*/
@property (readonly) NSString *city __attribute__((swift_name("city")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="country")
*/
@property (readonly) NSString *country __attribute__((swift_name("country")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="state")
*/
@property (readonly) NSString *state __attribute__((swift_name("state")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="zip")
*/
@property (readonly) NSString *zip __attribute__((swift_name("zip")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BillingAddressDto.Companion")))
@interface Edfapg_sdkBillingAddressDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkBillingAddressDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardDto")))
@interface Edfapg_sdkCardDto : Edfapg_sdkBase
- (instancetype)initWithInitiateRequestId:(NSString *)initiateRequestId cardNumber:(NSString *)cardNumber cardHolder:(NSString *)cardHolder cardExpiryMonth:(NSString *)cardExpiryMonth cardExpiryYear:(NSString *)cardExpiryYear cardScheme:(NSString *)cardScheme cardCvv:(NSString *)cardCvv token:(NSString *)token __attribute__((swift_name("init(initiateRequestId:cardNumber:cardHolder:cardExpiryMonth:cardExpiryYear:cardScheme:cardCvv:token:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkCardDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkCardDto *)doCopyInitiateRequestId:(NSString *)initiateRequestId cardNumber:(NSString *)cardNumber cardHolder:(NSString *)cardHolder cardExpiryMonth:(NSString *)cardExpiryMonth cardExpiryYear:(NSString *)cardExpiryYear cardScheme:(NSString *)cardScheme cardCvv:(NSString *)cardCvv token:(NSString *)token __attribute__((swift_name("doCopy(initiateRequestId:cardNumber:cardHolder:cardExpiryMonth:cardExpiryYear:cardScheme:cardCvv:token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardCvv")
*/
@property (readonly) NSString *cardCvv __attribute__((swift_name("cardCvv")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardExpiryMonth")
*/
@property (readonly) NSString *cardExpiryMonth __attribute__((swift_name("cardExpiryMonth")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardExpiryYear")
*/
@property (readonly) NSString *cardExpiryYear __attribute__((swift_name("cardExpiryYear")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardHolder")
*/
@property (readonly) NSString *cardHolder __attribute__((swift_name("cardHolder")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardNumber")
*/
@property (readonly) NSString *cardNumber __attribute__((swift_name("cardNumber")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardScheme")
*/
@property (readonly) NSString *cardScheme __attribute__((swift_name("cardScheme")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="initiateRequestId")
*/
@property (readonly) NSString *initiateRequestId __attribute__((swift_name("initiateRequestId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="token")
*/
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardDto.Companion")))
@interface Edfapg_sdkCardDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkCardDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomerDto")))
@interface Edfapg_sdkCustomerDto : Edfapg_sdkBase
- (instancetype)initWithName:(NSString *)name email:(NSString *)email phone:(NSString *)phone idNumber:(NSString *)idNumber idType:(NSString *)idType taxNumber:(NSString *)taxNumber __attribute__((swift_name("init(name:email:phone:idNumber:idType:taxNumber:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkCustomerDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkCustomerDto *)doCopyName:(NSString *)name email:(NSString *)email phone:(NSString *)phone idNumber:(NSString *)idNumber idType:(NSString *)idType taxNumber:(NSString *)taxNumber __attribute__((swift_name("doCopy(name:email:phone:idNumber:idType:taxNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="email")
*/
@property (readonly) NSString *email __attribute__((swift_name("email")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="idNumber")
*/
@property (readonly) NSString *idNumber __attribute__((swift_name("idNumber")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="idType")
*/
@property (readonly) NSString *idType __attribute__((swift_name("idType")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="name")
*/
@property (readonly) NSString *name __attribute__((swift_name("name")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="phone")
*/
@property (readonly) NSString *phone __attribute__((swift_name("phone")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="taxNumber")
*/
@property (readonly) NSString *taxNumber __attribute__((swift_name("taxNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomerDto.Companion")))
@interface Edfapg_sdkCustomerDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkCustomerDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExecuteData")))
@interface Edfapg_sdkExecuteData : Edfapg_sdkBase
- (instancetype)initWithHtmlContent:(NSString * _Nullable)htmlContent transactionId:(NSString * _Nullable)transactionId orderId:(NSString * _Nullable)orderId transactionStatus:(NSString * _Nullable)transactionStatus paymentStatus:(NSString * _Nullable)paymentStatus message:(NSString * _Nullable)message __attribute__((swift_name("init(htmlContent:transactionId:orderId:transactionStatus:paymentStatus:message:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkExecuteDataCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkExecuteData *)doCopyHtmlContent:(NSString * _Nullable)htmlContent transactionId:(NSString * _Nullable)transactionId orderId:(NSString * _Nullable)orderId transactionStatus:(NSString * _Nullable)transactionStatus paymentStatus:(NSString * _Nullable)paymentStatus message:(NSString * _Nullable)message __attribute__((swift_name("doCopy(htmlContent:transactionId:orderId:transactionStatus:paymentStatus:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable htmlContent __attribute__((swift_name("htmlContent")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@property (readonly) NSString * _Nullable orderId __attribute__((swift_name("orderId")));
@property (readonly) NSString * _Nullable paymentStatus __attribute__((swift_name("paymentStatus")));
@property (readonly) NSString * _Nullable transactionId __attribute__((swift_name("transactionId")));
@property (readonly) NSString * _Nullable transactionStatus __attribute__((swift_name("transactionStatus")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExecuteData.Companion")))
@interface Edfapg_sdkExecuteDataCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkExecuteDataCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InvoiceDto")))
@interface Edfapg_sdkInvoiceDto : Edfapg_sdkBase
- (instancetype)initWithShippingCharges:(double)shippingCharges extraCharges:(double)extraCharges extraDiscount:(double)extraDiscount total:(double)total lineItems:(NSArray<Edfapg_sdkLineItemDto *> *)lineItems __attribute__((swift_name("init(shippingCharges:extraCharges:extraDiscount:total:lineItems:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkInvoiceDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkInvoiceDto *)doCopyShippingCharges:(double)shippingCharges extraCharges:(double)extraCharges extraDiscount:(double)extraDiscount total:(double)total lineItems:(NSArray<Edfapg_sdkLineItemDto *> *)lineItems __attribute__((swift_name("doCopy(shippingCharges:extraCharges:extraDiscount:total:lineItems:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="extraCharges")
*/
@property (readonly) double extraCharges __attribute__((swift_name("extraCharges")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="extraDiscount")
*/
@property (readonly) double extraDiscount __attribute__((swift_name("extraDiscount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="lineItems")
*/
@property (readonly) NSArray<Edfapg_sdkLineItemDto *> *lineItems __attribute__((swift_name("lineItems")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="shippingCharges")
*/
@property (readonly) double shippingCharges __attribute__((swift_name("shippingCharges")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="total")
*/
@property (readonly) double total __attribute__((swift_name("total")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InvoiceDto.Companion")))
@interface Edfapg_sdkInvoiceDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkInvoiceDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LineItemDto")))
@interface Edfapg_sdkLineItemDto : Edfapg_sdkBase
- (instancetype)initWithSku:(NSString *)sku description:(NSString *)description url:(NSString *)url unitCost:(double)unitCost quantity:(int32_t)quantity netTotal:(double)netTotal discountRate:(double)discountRate discountAmount:(double)discountAmount taxRate:(double)taxRate taxTotal:(double)taxTotal total:(double)total __attribute__((swift_name("init(sku:description:url:unitCost:quantity:netTotal:discountRate:discountAmount:taxRate:taxTotal:total:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkLineItemDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkLineItemDto *)doCopySku:(NSString *)sku description:(NSString *)description url:(NSString *)url unitCost:(double)unitCost quantity:(int32_t)quantity netTotal:(double)netTotal discountRate:(double)discountRate discountAmount:(double)discountAmount taxRate:(double)taxRate taxTotal:(double)taxTotal total:(double)total __attribute__((swift_name("doCopy(sku:description:url:unitCost:quantity:netTotal:discountRate:discountAmount:taxRate:taxTotal:total:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="description")
*/
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="discountAmount")
*/
@property (readonly) double discountAmount __attribute__((swift_name("discountAmount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="discountRate")
*/
@property (readonly) double discountRate __attribute__((swift_name("discountRate")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="netTotal")
*/
@property (readonly) double netTotal __attribute__((swift_name("netTotal")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="quantity")
*/
@property (readonly) int32_t quantity __attribute__((swift_name("quantity")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="sku")
*/
@property (readonly) NSString *sku __attribute__((swift_name("sku")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="taxRate")
*/
@property (readonly) double taxRate __attribute__((swift_name("taxRate")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="taxTotal")
*/
@property (readonly) double taxTotal __attribute__((swift_name("taxTotal")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="total")
*/
@property (readonly) double total __attribute__((swift_name("total")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="unitCost")
*/
@property (readonly) double unitCost __attribute__((swift_name("unitCost")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="url")
*/
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LineItemDto.Companion")))
@interface Edfapg_sdkLineItemDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkLineItemDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Order")))
@interface Edfapg_sdkOrder : Edfapg_sdkBase
- (instancetype)initWithNumber:(NSString * _Nullable)number amount:(Edfapg_sdkDouble * _Nullable)amount currency:(NSString * _Nullable)currency description:(NSString * _Nullable)description __attribute__((swift_name("init(number:amount:currency:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkOrderCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkOrder *)doCopyNumber:(NSString * _Nullable)number amount:(Edfapg_sdkDouble * _Nullable)amount currency:(NSString * _Nullable)currency description:(NSString * _Nullable)description __attribute__((swift_name("doCopy(number:amount:currency:description:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="amount")
*/
@property (readonly) Edfapg_sdkDouble * _Nullable amount __attribute__((swift_name("amount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="currency")
*/
@property (readonly) NSString * _Nullable currency __attribute__((swift_name("currency")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="description")
*/
@property (readonly) NSString * _Nullable description_ __attribute__((swift_name("description_")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="number")
*/
@property (readonly) NSString * _Nullable number __attribute__((swift_name("number")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Order.Companion")))
@interface Edfapg_sdkOrderCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkOrderCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PageDto")))
@interface Edfapg_sdkPageDto<T> : Edfapg_sdkBase
- (instancetype)initWithContent:(NSArray<id> *)content number:(int32_t)number size:(int32_t)size totalElements:(int64_t)totalElements numberOfElements:(int32_t)numberOfElements totalPages:(int32_t)totalPages hasContent:(BOOL)hasContent first:(BOOL)first last:(BOOL)last __attribute__((swift_name("init(content:number:size:totalElements:numberOfElements:totalPages:hasContent:first:last:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkPageDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkPageDto<T> *)doCopyContent:(NSArray<id> *)content number:(int32_t)number size:(int32_t)size totalElements:(int64_t)totalElements numberOfElements:(int32_t)numberOfElements totalPages:(int32_t)totalPages hasContent:(BOOL)hasContent first:(BOOL)first last:(BOOL)last __attribute__((swift_name("doCopy(content:number:size:totalElements:numberOfElements:totalPages:hasContent:first:last:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="content")
*/
@property (readonly) NSArray<id> *content __attribute__((swift_name("content")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="first")
*/
@property (readonly) BOOL first __attribute__((swift_name("first")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="hasContent")
*/
@property (readonly) BOOL hasContent __attribute__((swift_name("hasContent")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="last")
*/
@property (readonly) BOOL last __attribute__((swift_name("last")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="number")
*/
@property (readonly) int32_t number __attribute__((swift_name("number")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="numberOfElements")
*/
@property (readonly) int32_t numberOfElements __attribute__((swift_name("numberOfElements")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="size")
*/
@property (readonly) int32_t size __attribute__((swift_name("size")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="totalElements")
*/
@property (readonly) int64_t totalElements __attribute__((swift_name("totalElements")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="totalPages")
*/
@property (readonly) int32_t totalPages __attribute__((swift_name("totalPages")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PageDtoCompanion")))
@interface Edfapg_sdkPageDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkPageDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(Edfapg_sdkKotlinArray<id<Edfapg_sdkKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializerTypeSerial0:(id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)typeSerial0 __attribute__((swift_name("serializer(typeSerial0:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecurringRequestBody")))
@interface Edfapg_sdkRecurringRequestBody : Edfapg_sdkBase
- (instancetype)initWithTransactionId:(NSString * _Nullable)transactionId recurringToken:(NSString * _Nullable)recurringToken amount:(Edfapg_sdkDouble * _Nullable)amount order:(Edfapg_sdkOrder * _Nullable)order __attribute__((swift_name("init(transactionId:recurringToken:amount:order:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkRecurringRequestBodyCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkRecurringRequestBody *)doCopyTransactionId:(NSString * _Nullable)transactionId recurringToken:(NSString * _Nullable)recurringToken amount:(Edfapg_sdkDouble * _Nullable)amount order:(Edfapg_sdkOrder * _Nullable)order __attribute__((swift_name("doCopy(transactionId:recurringToken:amount:order:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="amount")
*/
@property (readonly) Edfapg_sdkDouble * _Nullable amount __attribute__((swift_name("amount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="order")
*/
@property (readonly) Edfapg_sdkOrder * _Nullable order __attribute__((swift_name("order")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="recurringToken")
*/
@property (readonly) NSString * _Nullable recurringToken __attribute__((swift_name("recurringToken")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="transactionId")
*/
@property (readonly) NSString * _Nullable transactionId __attribute__((swift_name("transactionId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecurringRequestBody.Companion")))
@interface Edfapg_sdkRecurringRequestBodyCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkRecurringRequestBodyCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaleRequestDto")))
@interface Edfapg_sdkSaleRequestDto : Edfapg_sdkBase
- (instancetype)initWithOrderId:(NSString *)orderId amount:(double)amount currency:(NSString *)currency paymentMethod:(NSString *)paymentMethod auth:(NSString *)auth recurringInit:(NSString *)recurringInit customer:(Edfapg_sdkCustomerDto *)customer billingAddress:(Edfapg_sdkBillingAddressDto *)billingAddress invoice:(Edfapg_sdkInvoiceDto *)invoice successUrl:(NSString *)successUrl failureUrl:(NSString *)failureUrl hash:(NSString *)hash card:(Edfapg_sdkCardDto *)card __attribute__((swift_name("init(orderId:amount:currency:paymentMethod:auth:recurringInit:customer:billingAddress:invoice:successUrl:failureUrl:hash:card:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkSaleRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkSaleRequestDto *)doCopyOrderId:(NSString *)orderId amount:(double)amount currency:(NSString *)currency paymentMethod:(NSString *)paymentMethod auth:(NSString *)auth recurringInit:(NSString *)recurringInit customer:(Edfapg_sdkCustomerDto *)customer billingAddress:(Edfapg_sdkBillingAddressDto *)billingAddress invoice:(Edfapg_sdkInvoiceDto *)invoice successUrl:(NSString *)successUrl failureUrl:(NSString *)failureUrl hash:(NSString *)hash card:(Edfapg_sdkCardDto *)card __attribute__((swift_name("doCopy(orderId:amount:currency:paymentMethod:auth:recurringInit:customer:billingAddress:invoice:successUrl:failureUrl:hash:card:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="amount")
*/
@property (readonly) double amount __attribute__((swift_name("amount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="auth")
*/
@property (readonly) NSString *auth __attribute__((swift_name("auth")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="billingAddress")
*/
@property (readonly) Edfapg_sdkBillingAddressDto *billingAddress __attribute__((swift_name("billingAddress")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="card")
*/
@property (readonly) Edfapg_sdkCardDto *card __attribute__((swift_name("card")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="currency")
*/
@property (readonly) NSString *currency __attribute__((swift_name("currency")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="customer")
*/
@property (readonly) Edfapg_sdkCustomerDto *customer __attribute__((swift_name("customer")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="failureUrl")
*/
@property (readonly) NSString *failureUrl __attribute__((swift_name("failureUrl")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="hash")
*/
@property (readonly, getter=hash_) NSString *hash __attribute__((swift_name("hash")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="invoice")
*/
@property (readonly) Edfapg_sdkInvoiceDto *invoice __attribute__((swift_name("invoice")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="orderId")
*/
@property (readonly) NSString *orderId __attribute__((swift_name("orderId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="paymentMethod")
*/
@property (readonly) NSString *paymentMethod __attribute__((swift_name("paymentMethod")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="recurringInit")
*/
@property (readonly) NSString *recurringInit __attribute__((swift_name("recurringInit")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="successUrl")
*/
@property (readonly) NSString *successUrl __attribute__((swift_name("successUrl")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SaleRequestDto.Companion")))
@interface Edfapg_sdkSaleRequestDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkSaleRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionContentDto")))
@interface Edfapg_sdkTransactionContentDto : Edfapg_sdkBase
- (instancetype)initWithTransactionId:(NSString * _Nullable)transactionId orderId:(NSString * _Nullable)orderId amount:(NSString * _Nullable)amount currencyCode:(NSString * _Nullable)currencyCode transactionStatus:(NSString * _Nullable)transactionStatus paymentStatus:(NSString * _Nullable)paymentStatus businessUnitId:(NSString * _Nullable)businessUnitId channel:(NSString * _Nullable)channel rrn:(NSString * _Nullable)rrn transactionType:(NSString * _Nullable)transactionType reconciliationStatus:(NSString * _Nullable)reconciliationStatus reconciliationAt:(NSString * _Nullable)reconciliationAt acquirerBank:(NSString * _Nullable)acquirerBank providerTid:(NSString * _Nullable)providerTid holderAccount:(NSString * _Nullable)holderAccount cardScheme:(NSString * _Nullable)cardScheme cardChannel:(NSString * _Nullable)cardChannel cardSequenceNumber:(NSString * _Nullable)cardSequenceNumber pan:(NSString * _Nullable)pan cardExpiration:(NSString * _Nullable)cardExpiration cardHolderName:(NSString * _Nullable)cardHolderName createdAt:(NSString * _Nullable)createdAt finishedAt:(NSString * _Nullable)finishedAt createdBy:(NSString * _Nullable)createdBy createdByName:(NSString * _Nullable)createdByName totalRefundAmount:(NSString * _Nullable)totalRefundAmount refundStatus:(NSString * _Nullable)refundStatus merchantId:(NSString * _Nullable)merchantId recurringToken:(NSString * _Nullable)recurringToken __attribute__((swift_name("init(transactionId:orderId:amount:currencyCode:transactionStatus:paymentStatus:businessUnitId:channel:rrn:transactionType:reconciliationStatus:reconciliationAt:acquirerBank:providerTid:holderAccount:cardScheme:cardChannel:cardSequenceNumber:pan:cardExpiration:cardHolderName:createdAt:finishedAt:createdBy:createdByName:totalRefundAmount:refundStatus:merchantId:recurringToken:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkTransactionContentDtoCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkTransactionContentDto *)doCopyTransactionId:(NSString * _Nullable)transactionId orderId:(NSString * _Nullable)orderId amount:(NSString * _Nullable)amount currencyCode:(NSString * _Nullable)currencyCode transactionStatus:(NSString * _Nullable)transactionStatus paymentStatus:(NSString * _Nullable)paymentStatus businessUnitId:(NSString * _Nullable)businessUnitId channel:(NSString * _Nullable)channel rrn:(NSString * _Nullable)rrn transactionType:(NSString * _Nullable)transactionType reconciliationStatus:(NSString * _Nullable)reconciliationStatus reconciliationAt:(NSString * _Nullable)reconciliationAt acquirerBank:(NSString * _Nullable)acquirerBank providerTid:(NSString * _Nullable)providerTid holderAccount:(NSString * _Nullable)holderAccount cardScheme:(NSString * _Nullable)cardScheme cardChannel:(NSString * _Nullable)cardChannel cardSequenceNumber:(NSString * _Nullable)cardSequenceNumber pan:(NSString * _Nullable)pan cardExpiration:(NSString * _Nullable)cardExpiration cardHolderName:(NSString * _Nullable)cardHolderName createdAt:(NSString * _Nullable)createdAt finishedAt:(NSString * _Nullable)finishedAt createdBy:(NSString * _Nullable)createdBy createdByName:(NSString * _Nullable)createdByName totalRefundAmount:(NSString * _Nullable)totalRefundAmount refundStatus:(NSString * _Nullable)refundStatus merchantId:(NSString * _Nullable)merchantId recurringToken:(NSString * _Nullable)recurringToken __attribute__((swift_name("doCopy(transactionId:orderId:amount:currencyCode:transactionStatus:paymentStatus:businessUnitId:channel:rrn:transactionType:reconciliationStatus:reconciliationAt:acquirerBank:providerTid:holderAccount:cardScheme:cardChannel:cardSequenceNumber:pan:cardExpiration:cardHolderName:createdAt:finishedAt:createdBy:createdByName:totalRefundAmount:refundStatus:merchantId:recurringToken:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="acquirerBank")
*/
@property (readonly) NSString * _Nullable acquirerBank __attribute__((swift_name("acquirerBank")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="amount")
*/
@property (readonly) NSString * _Nullable amount __attribute__((swift_name("amount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="businessUnitId")
*/
@property (readonly) NSString * _Nullable businessUnitId __attribute__((swift_name("businessUnitId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardChannel")
*/
@property (readonly) NSString * _Nullable cardChannel __attribute__((swift_name("cardChannel")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardExpiration")
*/
@property (readonly) NSString * _Nullable cardExpiration __attribute__((swift_name("cardExpiration")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardHolderName")
*/
@property (readonly) NSString * _Nullable cardHolderName __attribute__((swift_name("cardHolderName")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardScheme")
*/
@property (readonly) NSString * _Nullable cardScheme __attribute__((swift_name("cardScheme")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="cardSequenceNumber")
*/
@property (readonly) NSString * _Nullable cardSequenceNumber __attribute__((swift_name("cardSequenceNumber")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="channel")
*/
@property (readonly) NSString * _Nullable channel __attribute__((swift_name("channel")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="createdAt")
*/
@property (readonly) NSString * _Nullable createdAt __attribute__((swift_name("createdAt")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="createdBy")
*/
@property (readonly) NSString * _Nullable createdBy __attribute__((swift_name("createdBy")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="createdByName")
*/
@property (readonly) NSString * _Nullable createdByName __attribute__((swift_name("createdByName")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="currencyCode")
*/
@property (readonly) NSString * _Nullable currencyCode __attribute__((swift_name("currencyCode")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="finishedAt")
*/
@property (readonly) NSString * _Nullable finishedAt __attribute__((swift_name("finishedAt")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="holderAccount")
*/
@property (readonly) NSString * _Nullable holderAccount __attribute__((swift_name("holderAccount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="merchantId")
*/
@property (readonly) NSString * _Nullable merchantId __attribute__((swift_name("merchantId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="orderId")
*/
@property (readonly) NSString * _Nullable orderId __attribute__((swift_name("orderId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="pan")
*/
@property (readonly) NSString * _Nullable pan __attribute__((swift_name("pan")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="paymentStatus")
*/
@property (readonly) NSString * _Nullable paymentStatus __attribute__((swift_name("paymentStatus")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="providerTid")
*/
@property (readonly) NSString * _Nullable providerTid __attribute__((swift_name("providerTid")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="reconciliationAt")
*/
@property (readonly) NSString * _Nullable reconciliationAt __attribute__((swift_name("reconciliationAt")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="reconciliationStatus")
*/
@property (readonly) NSString * _Nullable reconciliationStatus __attribute__((swift_name("reconciliationStatus")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="recurringToken")
*/
@property (readonly) NSString * _Nullable recurringToken __attribute__((swift_name("recurringToken")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="refundStatus")
*/
@property (readonly) NSString * _Nullable refundStatus __attribute__((swift_name("refundStatus")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="rrn")
*/
@property (readonly) NSString * _Nullable rrn __attribute__((swift_name("rrn")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="totalRefundAmount")
*/
@property (readonly) NSString * _Nullable totalRefundAmount __attribute__((swift_name("totalRefundAmount")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="transactionId")
*/
@property (readonly) NSString * _Nullable transactionId __attribute__((swift_name("transactionId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="transactionStatus")
*/
@property (readonly) NSString * _Nullable transactionStatus __attribute__((swift_name("transactionStatus")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="transactionType")
*/
@property (readonly) NSString * _Nullable transactionType __attribute__((swift_name("transactionType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionContentDto.Companion")))
@interface Edfapg_sdkTransactionContentDtoCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkTransactionContentDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Extra")))
@interface Edfapg_sdkExtra : Edfapg_sdkBase
- (instancetype)initWithType:(NSString *)type name:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(type:name:value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkExtraCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkExtra *)doCopyType:(NSString *)type name:(NSString *)name value:(NSString *)value __attribute__((swift_name("doCopy(type:name:value:)")));

/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end


/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Extra.Companion")))
@interface Edfapg_sdkExtraCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkExtraCompanion *shared __attribute__((swift_name("shared")));

/**
 * The required order data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgRecurringSaleAdapter
 * @see IEdfaPgOrder
 */
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgCard")))
@interface Edfapg_sdkEdfaPgCard : Edfapg_sdkBase
- (instancetype)initWithNumber:(NSString *)number expireMonth:(int32_t)expireMonth expireYear:(int32_t)expireYear cvv:(NSString *)cvv __attribute__((swift_name("init(number:expireMonth:expireYear:cvv:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkEdfaPgCardCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkEdfaPgCard *)doCopyNumber:(NSString *)number expireMonth:(int32_t)expireMonth expireYear:(int32_t)expireYear cvv:(NSString *)cvv __attribute__((swift_name("doCopy(number:expireMonth:expireYear:cvv:)")));

/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *cvv __attribute__((swift_name("cvv")));
@property (readonly) int32_t expireMonth __attribute__((swift_name("expireMonth")));
@property (readonly) int32_t expireYear __attribute__((swift_name("expireYear")));
@property (readonly) NSString *number __attribute__((swift_name("number")));
@end


/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgCard.Companion")))
@interface Edfapg_sdkEdfaPgCardCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgCardCompanion *shared __attribute__((swift_name("shared")));

/**
 * The required card data holder.
 * For the test purposes use [EdfaPgTestCard].
 *
 * @property number the credit card number.
 * @property expireMonth the month of expiry of the credit card. Month in the form XX.
 * @property expireYear the year of expiry of the credit card. Year in the form XXXX.
 * @property cvv the CVV/CVC2 credit card verification code. 3-4 symbols.
 */
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * The test environment cards.
 * @see EdfaPgCard
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgTestCard")))
@interface Edfapg_sdkEdfaPgTestCard : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The test environment cards.
 * @see EdfaPgCard
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)edfaPgTestCard __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgTestCard *shared __attribute__((swift_name("shared")));

/**
 * This card number and card expiration date must be used for testing unsuccessful CAPTURE after successful AUTH.
 *
 * Response on successful AUTH request: "action": "SALE", "result": "SUCCESS", "status": "PENDING".
 * Response on unsuccessful CAPTURE request: "action": "CAPTURE", "result": "DECLINED", "status": "PENDING".
 */
@property (readonly) Edfapg_sdkEdfaPgCard *CAPTURE_FAILURE __attribute__((swift_name("CAPTURE_FAILURE")));

/**
 * This card number and card expiration date must be used for testing unsuccessful sale.
 *
 * Response on unsuccessful SALE request: "action": "SALE", "result": "DECLINED", "status": "DECLINED".
 * Response on unsuccessful AUTH request: "action": "SALE", "result": "DECLINED", "status": "DECLINED".
 */
@property (readonly) Edfapg_sdkEdfaPgCard *SALE_FAILURE __attribute__((swift_name("SALE_FAILURE")));

/**
 * This card number and card expiration date must be used for testing successful sale.
 *
 * Response on successful SALE request: "action": "SALE", "result": "SUCCESS", "status": "SETTLED".
 * Response on successful AUTH request: "action": "SALE", "result": "SUCCESS", "status": "PENDING".
 */
@property (readonly) Edfapg_sdkEdfaPgCard *SALE_SUCCESS __attribute__((swift_name("SALE_SUCCESS")));

/**
 * This card number and card expiration date must be used for testing unsuccessful sale after 3DS verification.
 *
 * Response on VERIFY request: "action": "SALE", "result": "REDIRECT", "status": "3DS".
 * After return from ACS: "action": "SALE", "result": "DECLINED", "status": "DECLINED".
 */
@property (readonly) Edfapg_sdkEdfaPgCard *SECURE_3D_FAILURE __attribute__((swift_name("SECURE_3D_FAILURE")));

/**
 * This card number and card expiration date must be used for testing  successful sale after 3DS verification.
 *
 * Response on VERIFY request: "action": "SALE", "result": "REDIRECT", "status": "3DS".
 * After return from ACS: "action": "SALE", "result": "SUCCESS", "status": "SETTLED".
 */
@property (readonly) Edfapg_sdkEdfaPgCard *SECURE_3D_SUCCESS __attribute__((swift_name("SECURE_3D_SUCCESS")));
@end


/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgSaleOptions")))
@interface Edfapg_sdkEdfaPgSaleOptions : Edfapg_sdkBase
- (instancetype)initWithChannelId:(NSString * _Nullable)channelId recurringInit:(Edfapg_sdkBoolean * _Nullable)recurringInit __attribute__((swift_name("init(channelId:recurringInit:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkEdfaPgSaleOptionsCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkEdfaPgSaleOptions *)doCopyChannelId:(NSString * _Nullable)channelId recurringInit:(Edfapg_sdkBoolean * _Nullable)recurringInit __attribute__((swift_name("doCopy(channelId:recurringInit:)")));

/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable channelId __attribute__((swift_name("channelId")));
@property (readonly) Edfapg_sdkBoolean * _Nullable recurringInit __attribute__((swift_name("recurringInit")));
@end


/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgSaleOptions.Companion")))
@interface Edfapg_sdkEdfaPgSaleOptionsCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgSaleOptionsCompanion *shared __attribute__((swift_name("shared")));

/**
 *
 * @property channelId payment channel (Sub-account). String up to 16 characters.
 * @property recurringInit initialization of the transaction with possible following recurring.
 */
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 *
 * @property currency the currency. 3-letter code.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgSaleOrder")))
@interface Edfapg_sdkEdfaPgSaleOrder : Edfapg_sdkBase
- (instancetype)initWithId:(NSString *)id amount:(double)amount currency:(NSString *)currency description:(NSString *)description __attribute__((swift_name("init(id:amount:currency:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkEdfaPgSaleOrderCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkEdfaPgSaleOrder *)doCopyId:(NSString *)id amount:(double)amount currency:(NSString *)currency description:(NSString *)description __attribute__((swift_name("doCopy(id:amount:currency:description:)")));

/**
 *
 * @property currency the currency. 3-letter code.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSString *)formattedAmount __attribute__((swift_name("formattedAmount()")));
- (NSString *)formattedCurrency __attribute__((swift_name("formattedCurrency()")));

/**
 *
 * @property currency the currency. 3-letter code.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 *
 * @property currency the currency. 3-letter code.
 */
- (NSString *)description __attribute__((swift_name("description()")));
- (NSArray<NSString *> *)validate __attribute__((swift_name("validate()")));
@property (readonly) double amount __attribute__((swift_name("amount")));
@property (readonly) NSString *currency __attribute__((swift_name("currency")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@end


/**
 *
 * @property currency the currency. 3-letter code.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgSaleOrder.Companion")))
@interface Edfapg_sdkEdfaPgSaleOrderCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 *
 * @property currency the currency. 3-letter code.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgSaleOrderCompanion *shared __attribute__((swift_name("shared")));

/**
 *
 * @property currency the currency. 3-letter code.
 */
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgPayer")))
@interface Edfapg_sdkEdfaPgPayer : Edfapg_sdkBase
- (instancetype)initWithFirstName:(NSString *)firstName lastName:(NSString *)lastName address:(NSString *)address country:(NSString *)country city:(NSString *)city zip:(NSString *)zip email:(NSString *)email phone:(NSString *)phone ip:(NSString *)ip options:(Edfapg_sdkEdfaPgPayerOptions * _Nullable)options __attribute__((swift_name("init(firstName:lastName:address:country:city:zip:email:phone:ip:options:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkEdfaPgPayerCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkEdfaPgPayer *)doCopyFirstName:(NSString *)firstName lastName:(NSString *)lastName address:(NSString *)address country:(NSString *)country city:(NSString *)city zip:(NSString *)zip email:(NSString *)email phone:(NSString *)phone ip:(NSString *)ip options:(Edfapg_sdkEdfaPgPayerOptions * _Nullable)options __attribute__((swift_name("doCopy(firstName:lastName:address:country:city:zip:email:phone:ip:options:)")));

/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 */
- (NSString *)description __attribute__((swift_name("description()")));
- (NSArray<NSString *> *)validate __attribute__((swift_name("validate()")));
@property (readonly) NSString *address __attribute__((swift_name("address")));
@property (readonly) NSString *city __attribute__((swift_name("city")));
@property (readonly) NSString *country __attribute__((swift_name("country")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *firstName __attribute__((swift_name("firstName")));
@property (readonly) NSString *ip __attribute__((swift_name("ip")));
@property (readonly) NSString *lastName __attribute__((swift_name("lastName")));
@property (readonly) Edfapg_sdkEdfaPgPayerOptions * _Nullable options __attribute__((swift_name("options")));
@property (readonly) NSString *phone __attribute__((swift_name("phone")));
@property (readonly) NSString *zip __attribute__((swift_name("zip")));
@end


/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgPayer.Companion")))
@interface Edfapg_sdkEdfaPgPayerCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgPayerCompanion *shared __attribute__((swift_name("shared")));

/**
 * The required payer data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayerOptions
 *
 * @property firstName customer’s name. String up to 32 characters.
 * @property lastName customer’s surname. String up to 32 characters.
 * @property address customer’s address. String up to 255 characters.
 * @property country customer’s country. 2-letter code.
 * @property city customer’s city. String up to 32 characters.
 * @property zip ZIP-code of the Customer. String up to 32 characters.
 * @property email customer’s email. String up to 256 characters.
 * @property phone customer’s phone. String up to 32 characters.
 * @property ip IP-address of the Customer. XXX.XXX.XXX.XXX.
 * @property options the optional [EdfaPgPayerOptions].
 */
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgPayerOptions")))
@interface Edfapg_sdkEdfaPgPayerOptions : Edfapg_sdkBase
- (instancetype)initWithMiddleName:(NSString * _Nullable)middleName birthdate:(Edfapg_sdkKotlinx_datetimeLocalDate * _Nullable)birthdate address2:(NSString * _Nullable)address2 state:(NSString * _Nullable)state __attribute__((swift_name("init(middleName:birthdate:address2:state:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkEdfaPgPayerOptionsCompanion *companion __attribute__((swift_name("companion")));
- (Edfapg_sdkEdfaPgPayerOptions *)doCopyMiddleName:(NSString * _Nullable)middleName birthdate:(Edfapg_sdkKotlinx_datetimeLocalDate * _Nullable)birthdate address2:(NSString * _Nullable)address2 state:(NSString * _Nullable)state __attribute__((swift_name("doCopy(middleName:birthdate:address2:state:)")));

/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable address2 __attribute__((swift_name("address2")));
@property (readonly) Edfapg_sdkKotlinx_datetimeLocalDate * _Nullable birthdate __attribute__((swift_name("birthdate")));
@property (readonly) NSString * _Nullable middleName __attribute__((swift_name("middleName")));
@property (readonly) NSString * _Nullable state __attribute__((swift_name("state")));
@end


/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaPgPayerOptions.Companion")))
@interface Edfapg_sdkEdfaPgPayerOptionsCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaPgPayerOptionsCompanion *shared __attribute__((swift_name("shared")));

/**
 * The optional payer options data holder.
 * @see com.edfapg.sdk.feature.adapter.EdfaPgSaleAdapter
 * @see EdfaPgPayer
 *
 * @property middleName customer’s middle name. String up to 32 characters.
 * @property birthdate customer’s birthday. Format: yyyy-MM-dd, e.g. 1970-02-17.
 * @property address2 the adjoining road or locality of the сustomer’s address. String up to 255 characters.
 * @property state customer’s state. String up to 32 characters.
 */
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("TransactionProvider")))
@protocol Edfapg_sdkTransactionProvider
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)captureTransactionId:(NSString *)transactionId amount:(double)amount completionHandler:(void (^)(NSDictionary<NSString *, Edfapg_sdkKotlinx_serialization_jsonJsonElement *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("capture(transactionId:amount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeSaleTransactionId:(NSString *)transactionId completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("executeSale(transactionId:completionHandler:)")));

/**
 * Fetches a paginated list of transactions from the payment backend.
 *
 * This method performs a network request and returns a page of raw
 * transaction data mapped to JSON objects. The SDK does not apply
 * any presentation logic, sorting, or filtering beyond the parameters
 * explicitly provided.
 *
 * The host application is responsible for:
 * - Triggering this call (e.g. via a button or user action)
 * - Handling loading and error states
 * - Mapping the returned JSON objects to UI or domain models
 * - Managing pagination and refresh behavior
 *
 * @param pageNumber
 * The page index to fetch (0-based).
 *
 * @param pageSize
 * The maximum number of transactions to return in a single page.
 *
 * @param rrn
 * Optional Retrieval Reference Number filter.
 * When provided, only transactions matching the given RRN are returned.
 * If `null`, no RRN-based filtering is applied.
 *
 * @param status
 * Optional transaction status filter (e.g. SUCCESS, FAILED, APPROVED).
 * The accepted values are backend-defined.
 * If `null`, no status-based filtering is applied.
 *
 * @return
 * A [PageDto] containing:
 * - A list of transactions as [JsonObject]
 * - Pagination metadata (page number, total pages, etc.)
 *
 * Returns `null` if the request fails or the backend returns no data.
 * Host applications should treat a `null` result as a failure case
 * and handle it accordingly.
 *
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)fetchAllPageNumber:(int32_t)pageNumber pageSize:(int32_t)pageSize rrn:(NSString * _Nullable)rrn status:(NSString * _Nullable)status completionHandler:(void (^)(Edfapg_sdkPageDto<NSDictionary<NSString *, Edfapg_sdkKotlinx_serialization_jsonJsonElement *> *> * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("fetchAll(pageNumber:pageSize:rrn:status:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)fetchRedirectHtmlRedirectUrl:(NSString *)redirectUrl completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("fetchRedirectHtml(redirectUrl:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSaleDetailsTransactionId:(NSString *)transactionId completionHandler:(void (^)(NSDictionary<NSString *, Edfapg_sdkKotlinx_serialization_jsonJsonElement *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSaleDetails(transactionId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)recurringRecurringRequestBody:(Edfapg_sdkRecurringRequestBody *)recurringRequestBody completionHandler:(void (^)(NSDictionary<NSString *, Edfapg_sdkKotlinx_serialization_jsonJsonElement *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("recurring(recurringRequestBody:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)refundTransactionId:(NSString *)transactionId amount:(double)amount completionHandler:(void (^)(NSDictionary<NSString *, Edfapg_sdkKotlinx_serialization_jsonJsonElement *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("refund(transactionId:amount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)saleRequest:(Edfapg_sdkSaleRequestDto *)request completionHandler:(void (^)(NSDictionary<NSString *, Edfapg_sdkKotlinx_serialization_jsonJsonElement *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("sale(request:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)voidTransactionId:(NSString *)transactionId completionHandler:(void (^)(NSDictionary<NSString *, Edfapg_sdkKotlinx_serialization_jsonJsonElement *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("void(transactionId:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Credentials")))
@interface Edfapg_sdkCredentials : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)credentials __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkCredentials *shared __attribute__((swift_name("shared")));
- (NSString *)getApiKey __attribute__((swift_name("getApiKey()")));
- (void)setApiKeyApiKey:(NSString *)apiKey __attribute__((swift_name("setApiKey(apiKey:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionFilter")))
@interface Edfapg_sdkTransactionFilter : Edfapg_sdkBase
- (instancetype)initWithPageNumber:(int32_t)pageNumber pageSize:(int32_t)pageSize rrn:(NSString * _Nullable)rrn status:(NSString * _Nullable)status __attribute__((swift_name("init(pageNumber:pageSize:rrn:status:)"))) __attribute__((objc_designated_initializer));
- (Edfapg_sdkTransactionFilter *)doCopyPageNumber:(int32_t)pageNumber pageSize:(int32_t)pageSize rrn:(NSString * _Nullable)rrn status:(NSString * _Nullable)status __attribute__((swift_name("doCopy(pageNumber:pageSize:rrn:status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t pageNumber __attribute__((swift_name("pageNumber")));
@property (readonly) int32_t pageSize __attribute__((swift_name("pageSize")));
@property (readonly) NSString * _Nullable rrn __attribute__((swift_name("rrn")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((objc_subclassing_restricted))
@interface EdfaPayUi : Edfapg_sdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (UIViewController *)createOpenWebView:(void (^)(void))openWebView __attribute__((swift_name("create(openWebView:)")));
@end

__attribute__((objc_subclassing_restricted))
@interface EdfaWebView : Edfapg_sdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (UIViewController *)createOnClose:(void (^)(void))onClose onSuccess:(void (^)(void))onSuccess onFailure:(void (^)(void))onFailure __attribute__((swift_name("create(onClose:onSuccess:onFailure:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaCardPay")))
@interface Edfapg_sdkEdfaCardPay : Edfapg_sdkBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) Edfapg_sdkEdfaCardPayCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)generateSaleRequestCardData:(Edfapg_sdkCardBackState * _Nullable)cardData completionHandler:(void (^)(Edfapg_sdkSaleRequestDto * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("generateSaleRequest(cardData:completionHandler:)")));
- (BOOL)isAuth __attribute__((swift_name("isAuth()")));
- (BOOL)isRecurring __attribute__((swift_name("isRecurring()")));
- (Edfapg_sdkEdfaCardPay *)onTransactionFailureCallback:(void (^)(NSString * _Nullable))callback __attribute__((swift_name("onTransactionFailure(callback:)")));
- (Edfapg_sdkEdfaCardPay *)onTransactionSuccessCallback:(void (^)(id))callback __attribute__((swift_name("onTransactionSuccess(callback:)")));
- (Edfapg_sdkEdfaCardPay *)setAuthAuth:(BOOL)auth __attribute__((swift_name("setAuth(auth:)")));
- (Edfapg_sdkEdfaCardPay *)setCardCard:(Edfapg_sdkEdfaPgCard * _Nullable)card __attribute__((swift_name("setCard(card:)")));
- (Edfapg_sdkEdfaCardPay *)setDebugEnable:(BOOL)enable __attribute__((swift_name("setDebug(enable:)")));
- (Edfapg_sdkEdfaCardPay *)setDesignTypeDesignType:(Edfapg_sdkEdfaPayDesignType *)designType __attribute__((swift_name("setDesignType(designType:)")));
- (Edfapg_sdkEdfaCardPay *)setExtrasExtras:(NSArray<Edfapg_sdkExtra *> *)extras __attribute__((swift_name("setExtras(extras:)")));
- (Edfapg_sdkEdfaCardPay *)setLanguageLanguage:(Edfapg_sdkEdfaPayLanguage *)language __attribute__((swift_name("setLanguage(language:)")));
- (Edfapg_sdkEdfaCardPay *)setOrderOrder:(Edfapg_sdkEdfaPgSaleOrder *)order __attribute__((swift_name("setOrder(order:)")));
- (Edfapg_sdkEdfaCardPay *)setPayerPayer:(Edfapg_sdkEdfaPgPayer *)payer __attribute__((swift_name("setPayer(payer:)")));
- (Edfapg_sdkEdfaCardPay *)setRecurringChannelId:(NSString *)channelId recurring:(BOOL)recurring __attribute__((swift_name("setRecurring(channelId:recurring:)")));
@property (readonly) Edfapg_sdkEdfaPgCard * _Nullable card __attribute__((swift_name("card")));
@property (readonly) Edfapg_sdkEdfaPayDesignType *designType __attribute__((swift_name("designType")));
@property (readonly) BOOL enableDebug __attribute__((swift_name("enableDebug")));
@property (readonly) NSArray<Edfapg_sdkExtra *> * _Nullable extras __attribute__((swift_name("extras")));
@property (readonly) BOOL isCalled __attribute__((swift_name("isCalled")));
@property (readonly) Edfapg_sdkEdfaPayLanguage *language __attribute__((swift_name("language")));
@property (readonly) void (^ _Nullable onTransactionFailure)(NSString * _Nullable) __attribute__((swift_name("onTransactionFailure")));
@property (readonly) void (^ _Nullable onTransactionSuccess)(id) __attribute__((swift_name("onTransactionSuccess")));
@property (readonly) Edfapg_sdkEdfaPgSaleOrder * _Nullable order __attribute__((swift_name("order")));
@property (readonly) Edfapg_sdkEdfaPgPayer * _Nullable payer __attribute__((swift_name("payer")));
@property (readonly) Edfapg_sdkEdfaPgSaleOptions * _Nullable recurring __attribute__((swift_name("recurring")));
@property (readonly) BOOL saleAuth __attribute__((swift_name("saleAuth")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EdfaCardPay.Companion")))
@interface Edfapg_sdkEdfaCardPayCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkEdfaCardPayCompanion *shared __attribute__((swift_name("shared")));
- (Edfapg_sdkEdfaCardPay *)shared __attribute__((swift_name("shared()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardBackState")))
@interface Edfapg_sdkCardBackState : Edfapg_sdkBase
- (instancetype)initWithCardNumber:(NSString *)cardNumber holderName:(NSString *)holderName expiry:(NSString *)expiry cvv:(NSString *)cvv amount:(NSString *)amount currency:(NSString *)currency __attribute__((swift_name("init(cardNumber:holderName:expiry:cvv:amount:currency:)"))) __attribute__((objc_designated_initializer));
- (Edfapg_sdkCardBackState *)doCopyCardNumber:(NSString *)cardNumber holderName:(NSString *)holderName expiry:(NSString *)expiry cvv:(NSString *)cvv amount:(NSString *)amount currency:(NSString *)currency __attribute__((swift_name("doCopy(cardNumber:holderName:expiry:cvv:amount:currency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *amount __attribute__((swift_name("amount")));
@property (readonly) NSString *cardNumber __attribute__((swift_name("cardNumber")));
@property (readonly) NSString *currency __attribute__((swift_name("currency")));
@property (readonly) NSString *cvv __attribute__((swift_name("cvv")));
@property (readonly) NSString *expiry __attribute__((swift_name("expiry")));
@property (readonly) NSString *holderName __attribute__((swift_name("holderName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundStatus")))
@interface Edfapg_sdkRefundStatus : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)refundStatus __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkRefundStatus *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *FULL __attribute__((swift_name("FULL")));
@property (readonly) NSString *NONE __attribute__((swift_name("NONE")));
@property (readonly) NSString *PARTIAL __attribute__((swift_name("PARTIAL")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionType")))
@interface Edfapg_sdkTransactionType : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)transactionType __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkTransactionType *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *AUTHORIZATION __attribute__((swift_name("AUTHORIZATION")));
@property (readonly) NSString *CAPTURE __attribute__((swift_name("CAPTURE")));
@property (readonly) NSString *EXTENSION __attribute__((swift_name("EXTENSION")));
@property (readonly) NSString *PURCHASE __attribute__((swift_name("PURCHASE")));
@property (readonly) NSString *REFUND __attribute__((swift_name("REFUND")));
@property (readonly) NSString *REVERSE __attribute__((swift_name("REVERSE")));
@property (readonly) NSString *VOID __attribute__((swift_name("VOID")));
@end


/**
 * Pure Kotlin SHA-256 (no java.security). Produces lowercase hex.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Sha256")))
@interface Edfapg_sdkSha256 : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Pure Kotlin SHA-256 (no java.security). Produces lowercase hex.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sha256 __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkSha256 *shared __attribute__((swift_name("shared")));
- (Edfapg_sdkKotlinByteArray *)digestMessage:(Edfapg_sdkKotlinByteArray *)message __attribute__((swift_name("digest(message:)")));
- (NSString *)hexBytes:(Edfapg_sdkKotlinByteArray *)bytes __attribute__((swift_name("hex(bytes:)")));
- (NSString *)hexInput:(NSString *)input __attribute__((swift_name("hex(input:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SignedBody")))
@interface Edfapg_sdkSignedBody : Edfapg_sdkBase
- (instancetype)initWithBodyJson:(NSString *)bodyJson signature:(NSString *)signature __attribute__((swift_name("init(bodyJson:signature:)"))) __attribute__((objc_designated_initializer));
- (Edfapg_sdkSignedBody *)doCopyBodyJson:(NSString *)bodyJson signature:(NSString *)signature __attribute__((swift_name("doCopy(bodyJson:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *bodyJson __attribute__((swift_name("bodyJson")));
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KMP_LEVEL")))
@interface Edfapg_sdkKMP_LEVEL : Edfapg_sdkKotlinEnum<Edfapg_sdkKMP_LEVEL *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) Edfapg_sdkKMP_LEVEL *debug __attribute__((swift_name("debug")));
@property (class, readonly) Edfapg_sdkKMP_LEVEL *info __attribute__((swift_name("info")));
@property (class, readonly) Edfapg_sdkKMP_LEVEL *warn __attribute__((swift_name("warn")));
@property (class, readonly) Edfapg_sdkKMP_LEVEL *error __attribute__((swift_name("error")));
+ (Edfapg_sdkKotlinArray<Edfapg_sdkKMP_LEVEL *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<Edfapg_sdkKMP_LEVEL *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KmpLogger")))
@interface Edfapg_sdkKmpLogger : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)kmpLogger __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKmpLogger *shared __attribute__((swift_name("shared")));
- (void)logLevel:(Edfapg_sdkKMP_LEVEL *)level message:(NSString *)message throwable:(Edfapg_sdkKotlinThrowable * _Nullable)throwable __attribute__((swift_name("log(level:message:throwable:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HelpersKt")))
@interface Edfapg_sdkHelpersKt : Edfapg_sdkBase
+ (void)delayAtIOMillis:(int64_t)millis callback:(void (^)(void))callback __attribute__((swift_name("delayAtIO(millis:callback:)")));
+ (void)delayAtMainMillis:(int64_t)millis callback:(void (^)(void))callback __attribute__((swift_name("delayAtMain(millis:callback:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoggerKt")))
@interface Edfapg_sdkLoggerKt : Edfapg_sdkBase
@property (class, readonly) NSString *tag __attribute__((swift_name("tag")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequestSignerKt")))
@interface Edfapg_sdkRequestSignerKt : Edfapg_sdkBase
+ (Edfapg_sdkSignedBody *)signDto:(id _Nullable)dto secretKey:(NSString *)secretKey json:(Edfapg_sdkKotlinx_serialization_jsonJson *)json __attribute__((swift_name("sign(dto:secretKey:json:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UtilsKt")))
@interface Edfapg_sdkUtilsKt : Edfapg_sdkBase

/**
 * KMP-safe money formatting: 1,000.50
 * - thousands separator: ','
 * - decimal separator: '.'
 * - always 2 fractional digits
 */
+ (NSString *)formatMoney:(double)receiver __attribute__((swift_name("formatMoney(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface Edfapg_sdkKotlinArray<T> : Edfapg_sdkBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(Edfapg_sdkInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<Edfapg_sdkKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface Edfapg_sdkKotlinEnumCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol Edfapg_sdkKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<Edfapg_sdkKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<Edfapg_sdkKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol Edfapg_sdkKotlinx_serialization_coreKSerializer <Edfapg_sdkKotlinx_serialization_coreSerializationStrategy, Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/LocalDateSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate")))
@interface Edfapg_sdkKotlinx_datetimeLocalDate : Edfapg_sdkBase <Edfapg_sdkKotlinComparable>
- (instancetype)initWithYear:(int32_t)year month:(int32_t)month day:(int32_t)day __attribute__((swift_name("init(year:month:day:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithYear:(int32_t)year month:(Edfapg_sdkKotlinx_datetimeMonth *)month day_:(int32_t)day __attribute__((swift_name("init(year:month:day_:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkKotlinx_datetimeLocalDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(Edfapg_sdkKotlinx_datetimeLocalDate *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (Edfapg_sdkKotlinx_datetimeLocalDateRange *)rangeToThat:(Edfapg_sdkKotlinx_datetimeLocalDate *)that __attribute__((swift_name("rangeTo(that:)")));
- (Edfapg_sdkKotlinx_datetimeLocalDateRange *)rangeUntilThat:(Edfapg_sdkKotlinx_datetimeLocalDate *)that __attribute__((swift_name("rangeUntil(that:)")));
- (int64_t)toEpochDays __attribute__((swift_name("toEpochDays()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t day __attribute__((swift_name("day")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth"))) __attribute__((deprecated("Use the 'day' property instead")));
@property (readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) Edfapg_sdkKotlinx_datetimeMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t monthNumber __attribute__((swift_name("monthNumber"))) __attribute__((deprecated("Use the 'month' property instead")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface Edfapg_sdkKotlinIllegalStateException : Edfapg_sdkKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface Edfapg_sdkKotlinCancellationException : Edfapg_sdkKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(Edfapg_sdkKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface Edfapg_sdkKotlinx_serialization_jsonJsonElement : Edfapg_sdkBase
@property (class, readonly, getter=companion) Edfapg_sdkKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface Edfapg_sdkKotlinByteArray : Edfapg_sdkBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(Edfapg_sdkByte *(^)(Edfapg_sdkInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (Edfapg_sdkKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol Edfapg_sdkKotlinx_serialization_coreSerialFormat
@required
@property (readonly) Edfapg_sdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol Edfapg_sdkKotlinx_serialization_coreStringFormat <Edfapg_sdkKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface Edfapg_sdkKotlinx_serialization_jsonJson : Edfapg_sdkBase <Edfapg_sdkKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) Edfapg_sdkKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(Edfapg_sdkKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringString:(NSString *)string __attribute__((swift_name("decodeFromString(string:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (Edfapg_sdkKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringValue:(id _Nullable)value __attribute__((swift_name("encodeToString(value:)")));
- (NSString *)encodeToStringSerializer:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (Edfapg_sdkKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) Edfapg_sdkKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) Edfapg_sdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol Edfapg_sdkKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol Edfapg_sdkKotlinx_serialization_coreEncoder
@required
- (id<Edfapg_sdkKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<Edfapg_sdkKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<Edfapg_sdkKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) Edfapg_sdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol Edfapg_sdkKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<Edfapg_sdkKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<Edfapg_sdkKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) Edfapg_sdkKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol Edfapg_sdkKotlinx_serialization_coreDecoder
@required
- (id<Edfapg_sdkKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<Edfapg_sdkKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (Edfapg_sdkKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) Edfapg_sdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonth")))
@interface Edfapg_sdkKotlinx_datetimeMonth : Edfapg_sdkKotlinEnum<Edfapg_sdkKotlinx_datetimeMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *january __attribute__((swift_name("january")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *february __attribute__((swift_name("february")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *march __attribute__((swift_name("march")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *april __attribute__((swift_name("april")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *may __attribute__((swift_name("may")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *june __attribute__((swift_name("june")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *july __attribute__((swift_name("july")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *august __attribute__((swift_name("august")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *september __attribute__((swift_name("september")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *october __attribute__((swift_name("october")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *november __attribute__((swift_name("november")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeMonth *december __attribute__((swift_name("december")));
+ (Edfapg_sdkKotlinArray<Edfapg_sdkKotlinx_datetimeMonth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<Edfapg_sdkKotlinx_datetimeMonth *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate.Companion")))
@interface Edfapg_sdkKotlinx_datetimeLocalDateCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinx_datetimeLocalDateCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_datetimeDateTimeFormat>)FormatBlock:(void (^)(id<Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilderWithDate>))block __attribute__((swift_name("Format(block:)")));
- (Edfapg_sdkKotlinx_datetimeLocalDate *)fromEpochDaysEpochDays:(int32_t)epochDays __attribute__((swift_name("fromEpochDays(epochDays:)")));
- (Edfapg_sdkKotlinx_datetimeLocalDate *)fromEpochDaysEpochDays_:(int64_t)epochDays __attribute__((swift_name("fromEpochDays(epochDays_:)")));
- (Edfapg_sdkKotlinx_datetimeLocalDate *)parseInput:(id)input format:(id<Edfapg_sdkKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("parse(input:format:)")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("KotlinIterable")))
@protocol Edfapg_sdkKotlinIterable
@required
- (id<Edfapg_sdkKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end

__attribute__((swift_name("KotlinCollection")))
@protocol Edfapg_sdkKotlinCollection <Edfapg_sdkKotlinIterable>
@required
- (BOOL)containsElement:(id _Nullable)element __attribute__((swift_name("contains(element:)")));
- (BOOL)containsAllElements:(id)elements __attribute__((swift_name("containsAll(elements:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_datetimeLocalDateProgression")))
@interface Edfapg_sdkKotlinx_datetimeLocalDateProgression : Edfapg_sdkBase <Edfapg_sdkKotlinCollection>
@property (class, readonly, getter=companion) Edfapg_sdkKotlinx_datetimeLocalDateProgressionCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)containsElement:(Edfapg_sdkKotlinx_datetimeLocalDate *)element __attribute__((swift_name("contains(element:)")));
- (BOOL)containsAllElements:(id)elements __attribute__((swift_name("containsAll(elements:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (id<Edfapg_sdkKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) Edfapg_sdkKotlinx_datetimeLocalDate *first __attribute__((swift_name("first")));
@property (readonly) Edfapg_sdkKotlinx_datetimeLocalDate *last __attribute__((swift_name("last")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinClosedRange")))
@protocol Edfapg_sdkKotlinClosedRange
@required
- (BOOL)containsValue:(id)value __attribute__((swift_name("contains(value:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
@property (readonly) id endInclusive __attribute__((swift_name("endInclusive")));
@property (readonly) id start __attribute__((swift_name("start")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.9")
*/
__attribute__((swift_name("KotlinOpenEndRange")))
@protocol Edfapg_sdkKotlinOpenEndRange
@required
- (BOOL)containsValue_:(id)value __attribute__((swift_name("contains(value_:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
@property (readonly) id endExclusive __attribute__((swift_name("endExclusive")));
@property (readonly) id start __attribute__((swift_name("start")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDateRange")))
@interface Edfapg_sdkKotlinx_datetimeLocalDateRange : Edfapg_sdkKotlinx_datetimeLocalDateProgression <Edfapg_sdkKotlinClosedRange, Edfapg_sdkKotlinOpenEndRange>
- (instancetype)initWithStart:(Edfapg_sdkKotlinx_datetimeLocalDate *)start endInclusive:(Edfapg_sdkKotlinx_datetimeLocalDate *)endInclusive __attribute__((swift_name("init(start:endInclusive:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkKotlinx_datetimeLocalDateRangeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)containsElement:(Edfapg_sdkKotlinx_datetimeLocalDate *)element __attribute__((swift_name("contains(element:)")));
- (BOOL)containsValue:(Edfapg_sdkKotlinx_datetimeLocalDate *)element __attribute__((swift_name("contains(value:)")));
- (BOOL)containsValue_:(Edfapg_sdkKotlinx_datetimeLocalDate *)element __attribute__((swift_name("contains(value_:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) Edfapg_sdkKotlinx_datetimeLocalDate *endExclusive __attribute__((swift_name("endExclusive"))) __attribute__((deprecated("This throws an exception if the exclusive end if not inside the platform-specific boundaries for LocalDate. The 'endInclusive' property does not throw and should be preferred.")));
@property (readonly) Edfapg_sdkKotlinx_datetimeLocalDate *endInclusive __attribute__((swift_name("endInclusive")));
@property (readonly) Edfapg_sdkKotlinx_datetimeLocalDate *start __attribute__((swift_name("start")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeek")))
@interface Edfapg_sdkKotlinx_datetimeDayOfWeek : Edfapg_sdkKotlinEnum<Edfapg_sdkKotlinx_datetimeDayOfWeek *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *monday __attribute__((swift_name("monday")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *friday __attribute__((swift_name("friday")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimeDayOfWeek *sunday __attribute__((swift_name("sunday")));
+ (Edfapg_sdkKotlinArray<Edfapg_sdkKotlinx_datetimeDayOfWeek *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<Edfapg_sdkKotlinx_datetimeDayOfWeek *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface Edfapg_sdkKotlinx_serialization_jsonJsonElementCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface Edfapg_sdkKotlinByteIterator : Edfapg_sdkBase <Edfapg_sdkKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (Edfapg_sdkByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface Edfapg_sdkKotlinx_serialization_coreSerializersModule : Edfapg_sdkBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<Edfapg_sdkKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<Edfapg_sdkKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<Edfapg_sdkKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<Edfapg_sdkKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<Edfapg_sdkKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<Edfapg_sdkKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface Edfapg_sdkKotlinx_serialization_jsonJsonDefault : Edfapg_sdkKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface Edfapg_sdkKotlinx_serialization_jsonJsonConfiguration : Edfapg_sdkBase
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowComments __attribute__((swift_name("allowComments")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowTrailingComma __attribute__((swift_name("allowTrailingComma")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode *classDiscriminatorMode __attribute__((swift_name("classDiscriminatorMode")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL decodeEnumsCaseInsensitive __attribute__((swift_name("decodeEnumsCaseInsensitive")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) id<Edfapg_sdkKotlinx_serialization_jsonJsonNamingStrategy> _Nullable namingStrategy __attribute__((swift_name("namingStrategy")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol Edfapg_sdkKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<Edfapg_sdkKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) Edfapg_sdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol Edfapg_sdkKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface Edfapg_sdkKotlinx_serialization_coreSerialKind : Edfapg_sdkBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol Edfapg_sdkKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<Edfapg_sdkKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) Edfapg_sdkKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface Edfapg_sdkKotlinNothing : Edfapg_sdkBase
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormat")))
@protocol Edfapg_sdkKotlinx_datetimeDateTimeFormat
@required
- (NSString *)formatValue:(id _Nullable)value __attribute__((swift_name("format(value:)")));
- (id<Edfapg_sdkKotlinAppendable>)formatToAppendable:(id<Edfapg_sdkKotlinAppendable>)appendable value:(id _Nullable)value __attribute__((swift_name("formatTo(appendable:value:)")));
- (id _Nullable)parseInput:(id)input __attribute__((swift_name("parse(input:)")));
- (id _Nullable)parseOrNullInput:(id)input __attribute__((swift_name("parseOrNull(input:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilder")))
@protocol Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilder
@required
- (void)charsValue:(NSString *)value __attribute__((swift_name("chars(value:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilderWithYearMonth")))
@protocol Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilderWithYearMonth <Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilder>
@required
- (void)monthNameNames:(Edfapg_sdkKotlinx_datetimeMonthNames *)names __attribute__((swift_name("monthName(names:)")));
- (void)monthNumberPadding:(Edfapg_sdkKotlinx_datetimePadding *)padding __attribute__((swift_name("monthNumber(padding:)")));
- (void)yearPadding:(Edfapg_sdkKotlinx_datetimePadding *)padding __attribute__((swift_name("year(padding:)")));
- (void)yearMonthFormat:(id<Edfapg_sdkKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("yearMonth(format:)")));
- (void)yearTwoDigitsBaseYear:(int32_t)baseYear __attribute__((swift_name("yearTwoDigits(baseYear:)")));
@end

__attribute__((swift_name("Kotlinx_datetimeDateTimeFormatBuilderWithDate")))
@protocol Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilderWithDate <Edfapg_sdkKotlinx_datetimeDateTimeFormatBuilderWithYearMonth>
@required
- (void)dateFormat:(id<Edfapg_sdkKotlinx_datetimeDateTimeFormat>)format __attribute__((swift_name("date(format:)")));
- (void)dayPadding:(Edfapg_sdkKotlinx_datetimePadding *)padding __attribute__((swift_name("day(padding:)")));
- (void)dayOfMonthPadding:(Edfapg_sdkKotlinx_datetimePadding *)padding __attribute__((swift_name("dayOfMonth(padding:)"))) __attribute__((deprecated("Use 'day' instead")));
- (void)dayOfWeekNames:(Edfapg_sdkKotlinx_datetimeDayOfWeekNames *)names __attribute__((swift_name("dayOfWeek(names:)")));
- (void)dayOfYearPadding:(Edfapg_sdkKotlinx_datetimePadding *)padding __attribute__((swift_name("dayOfYear(padding:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDateProgression.Companion")))
@interface Edfapg_sdkKotlinx_datetimeLocalDateProgressionCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinx_datetimeLocalDateProgressionCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDateRange.Companion")))
@interface Edfapg_sdkKotlinx_datetimeLocalDateRangeCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinx_datetimeLocalDateRangeCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) Edfapg_sdkKotlinx_datetimeLocalDateRange *EMPTY __attribute__((swift_name("EMPTY")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol Edfapg_sdkKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<Edfapg_sdkKotlinKClass>)kClass provider:(id<Edfapg_sdkKotlinx_serialization_coreKSerializer> (^)(NSArray<id<Edfapg_sdkKotlinx_serialization_coreKSerializer>> *typeArgumentsSerializers))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<Edfapg_sdkKotlinKClass>)kClass serializer:(id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<Edfapg_sdkKotlinKClass>)baseClass actualClass:(id<Edfapg_sdkKotlinKClass>)actualClass actualSerializer:(id<Edfapg_sdkKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<Edfapg_sdkKotlinKClass>)baseClass defaultDeserializerProvider:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable className))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<Edfapg_sdkKotlinKClass>)baseClass defaultDeserializerProvider:(id<Edfapg_sdkKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable className))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<Edfapg_sdkKotlinKClass>)baseClass defaultSerializerProvider:(id<Edfapg_sdkKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id value))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol Edfapg_sdkKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol Edfapg_sdkKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol Edfapg_sdkKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol Edfapg_sdkKotlinKClass <Edfapg_sdkKotlinKDeclarationContainer, Edfapg_sdkKotlinKAnnotatedElement, Edfapg_sdkKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonClassDiscriminatorMode")))
@interface Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode : Edfapg_sdkKotlinEnum<Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode *none __attribute__((swift_name("none")));
@property (class, readonly) Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode *allJsonObjects __attribute__((swift_name("allJsonObjects")));
@property (class, readonly) Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode *polymorphic __attribute__((swift_name("polymorphic")));
+ (Edfapg_sdkKotlinArray<Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<Edfapg_sdkKotlinx_serialization_jsonClassDiscriminatorMode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonNamingStrategy")))
@protocol Edfapg_sdkKotlinx_serialization_jsonJsonNamingStrategy
@required
- (NSString *)serialNameForJsonDescriptor:(id<Edfapg_sdkKotlinx_serialization_coreSerialDescriptor>)descriptor elementIndex:(int32_t)elementIndex serialName:(NSString *)serialName __attribute__((swift_name("serialNameForJson(descriptor:elementIndex:serialName:)")));
@end

__attribute__((swift_name("KotlinAppendable")))
@protocol Edfapg_sdkKotlinAppendable
@required

/**
 * @note annotations
 *   kotlin.IgnorableReturnValue
*/
- (id<Edfapg_sdkKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));

/**
 * @note annotations
 *   kotlin.IgnorableReturnValue
*/
- (id<Edfapg_sdkKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));

/**
 * @note annotations
 *   kotlin.IgnorableReturnValue
*/
- (id<Edfapg_sdkKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimePadding")))
@interface Edfapg_sdkKotlinx_datetimePadding : Edfapg_sdkKotlinEnum<Edfapg_sdkKotlinx_datetimePadding *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) Edfapg_sdkKotlinx_datetimePadding *none __attribute__((swift_name("none")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimePadding *zero __attribute__((swift_name("zero")));
@property (class, readonly) Edfapg_sdkKotlinx_datetimePadding *space __attribute__((swift_name("space")));
+ (Edfapg_sdkKotlinArray<Edfapg_sdkKotlinx_datetimePadding *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<Edfapg_sdkKotlinx_datetimePadding *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeekNames")))
@interface Edfapg_sdkKotlinx_datetimeDayOfWeekNames : Edfapg_sdkBase
- (instancetype)initWithNames:(NSArray<NSString *> *)names __attribute__((swift_name("init(names:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMonday:(NSString *)monday tuesday:(NSString *)tuesday wednesday:(NSString *)wednesday thursday:(NSString *)thursday friday:(NSString *)friday saturday:(NSString *)saturday sunday:(NSString *)sunday __attribute__((swift_name("init(monday:tuesday:wednesday:thursday:friday:saturday:sunday:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkKotlinx_datetimeDayOfWeekNamesCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> *names __attribute__((swift_name("names")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonthNames")))
@interface Edfapg_sdkKotlinx_datetimeMonthNames : Edfapg_sdkBase
- (instancetype)initWithNames:(NSArray<NSString *> *)names __attribute__((swift_name("init(names:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithJanuary:(NSString *)january february:(NSString *)february march:(NSString *)march april:(NSString *)april may:(NSString *)may june:(NSString *)june july:(NSString *)july august:(NSString *)august september:(NSString *)september october:(NSString *)october november:(NSString *)november december:(NSString *)december __attribute__((swift_name("init(january:february:march:april:may:june:july:august:september:october:november:december:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) Edfapg_sdkKotlinx_datetimeMonthNamesCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> *names __attribute__((swift_name("names")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeekNames.Companion")))
@interface Edfapg_sdkKotlinx_datetimeDayOfWeekNamesCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinx_datetimeDayOfWeekNamesCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) Edfapg_sdkKotlinx_datetimeDayOfWeekNames *ENGLISH_ABBREVIATED __attribute__((swift_name("ENGLISH_ABBREVIATED")));
@property (readonly) Edfapg_sdkKotlinx_datetimeDayOfWeekNames *ENGLISH_FULL __attribute__((swift_name("ENGLISH_FULL")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonthNames.Companion")))
@interface Edfapg_sdkKotlinx_datetimeMonthNamesCompanion : Edfapg_sdkBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) Edfapg_sdkKotlinx_datetimeMonthNamesCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) Edfapg_sdkKotlinx_datetimeMonthNames *ENGLISH_ABBREVIATED __attribute__((swift_name("ENGLISH_ABBREVIATED")));
@property (readonly) Edfapg_sdkKotlinx_datetimeMonthNames *ENGLISH_FULL __attribute__((swift_name("ENGLISH_FULL")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
